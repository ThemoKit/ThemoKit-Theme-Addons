<?php do_action( 'htbuilder_footer_content' ); ?>
<?php wp_footer(); ?>
</body>
</html>
