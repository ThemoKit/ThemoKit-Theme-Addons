=== The Plus Addons for Elementor Page Builder Lite ===
Contributors: posimyththemes
Donate link: https://paypal.me/sagarpatel124
Tags: elementor, elementor addons, elementor addon set, the plus adding for elementor, the plus widgets elementor, elementor widgets, elementor free widgets, elementor pro, elementor widget pack, ultimate addons for elementor, unlimited addons for elementor, extra addons for elementor
Requires at least: 3.5
Tested up to: 5.1
Stable tag: 1.1.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

ThePlus Addons is made by experienced designers and developers to fulfil all your needs while development of websites. It's completely responsive, easy to use with tons of options. Which makes this plugin biggest, unique and most advance. Plugin is already used by lots of designers and developers and they have given very positive feedbacks. We keep improving plugin so you have the best available version with latest features as per trends.<br>

####Free Version : 
<br/><br/><table> <tr> <td> <ul><li><a href="http://elementor.theplusaddons.com/widgets/advance-text-block/" rel="nofollow">Advance Text Block</a></li> 
 <li><a href="http://elementor.theplusaddons.com/widgets/buttons/" rel="nofollow">Buttons</a></li>
<li><a href="http://elementor.theplusaddons.com/widgets/pricing-table/" rel="nofollow">Pricing Tables</a></li>
<li><a href="http://elementor.theplusaddons.com/widgets/countdown/" rel="nofollow">Countdown</a></li>
<li><a href="http://elementor.theplusaddons.com/widgets/heading-titles/" rel="nofollow">Heading Title</a></li>  
<li><a href="http://elementor.theplusaddons.com/widgets/infobox/" rel="nofollow">Info Box</a></li>
<li><a href="http://elementor.theplusaddons.com/widgets/social-icon/" rel="nofollow">Social Icon</a></li> 
<li><a href="http://elementor.theplusaddons.com/widgets/heading-animation/" rel="nofollow">Animated Text</a></li> 
 <li><a href="http://elementor.theplusaddons.com/widgets/smooth-scroll/" rel="nofollow">Smooth Scroll</a></li>  
<li><a href="http://elementor.theplusaddons.com/widgets/flipbox/" rel="nofollow">FlipBox</a></li> 
<li><a href="http://elementor.theplusaddons.com/widgets/accordion/" rel="nofollow">Accordions</a></li>
<li><a href="http://elementor.theplusaddons.com/widgets/tabs-tours/" rel="nofollow">Tabs/Tours</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-blogs/blog-styles/" rel="nofollow">Blog Design Styles</a></li>  
<li><a href="http://elementor.theplusaddons.com/plus-blogs/grid-blogs/" rel="nofollow">Blog Grid</a></li> 
<li><a href="http://elementor.theplusaddons.com/plus-blogs/masonry-blogs/" rel="nofollow">Blog Masonry</a></li>
<li><a href="http://elementor.theplusaddons.com/testimonial/#style-two-carousel" rel="nofollow">Testimonials Style 2</a></li>
<li><a href="http://elementor.theplusaddons.com/testimonial/#style-four-normal-carousel" rel="nofollow">Testimonials Style 4</a></li> 
<li><a href="http://elementor.theplusaddons.com/plus-image-gallery/image-grid/" rel="nofollow">Gallery Grid</a></li> 
<li><a href="http://elementor.theplusaddons.com/plus-image-gallery/image-masonry/" rel="nofollow">Gallery Masonry</a></li>
 <li><a href="http://elementor.theplusaddons.com/plus-image-gallery/image-metro/" rel="nofollow">Gallery Metro</a></li> 
<li><a href="http://elementor.theplusaddons.com/widgets/clients/#grid-layout" rel="nofollow">Client Grid</a></li>
 <li><a href="http://elementor.theplusaddons.com/widgets/clients/#masonry-layout" rel="nofollow">Client Masonry</a></li> 
<li><a href="http://elementor.theplusaddons.com/team-member" rel="nofollow">Team Members </a></li> 
< li><a href="http://elementor.theplusaddons.com/widgets/number-counter/" rel="nofollow">Number Counter </a></li>  
 < li><a href="http://elementor.theplusaddons.com/widgets/blockquote/" rel="nofollow">BlockQuote </a></li>< li><a href="http://elementor.theplusaddons.com/widgets/contact-form-7/" rel="nofollow">Contact Form 7</a></li>    </ul> </td> </tr> </table>

*All Above widgets have amazing features but some functionalities are missing which are available in pro version.<br/><br/>

####Paid Version : 
All Widgets of Free version with Full Features and Below Widgets.</br></br>
<ul>  <li><a href="http://elementor.theplusaddons.com/testimonial/#section-style-one" rel="nofollow">Testimonials Style 1</a></li>
 <li><a href="http://elementor.theplusaddons.com/testimonial/#style-three-normal-carousel" rel="nofollow">Testimonials Style 3</a></li>
<li><a href="http://elementor.theplusaddons.com/testimonial/#center-moder-section" rel="nofollow">Testimonials Center Mode</a></li>
 <li><a href="http://elementor.theplusaddons.com/testimonial/#messy-columns-section" rel="nofollow">Testimonials Messy Columns</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/clients/#center-mode-carousel" rel="nofollow">Client Center Mode</a></li> <li><a href="http://elementor.theplusaddons.com/client-load-more-lazy-load/" rel="nofollow">Client Lazy Load</a></li>
 <li><a href="http://elementor.theplusaddons.com/widgets/clients/#carousel-options" rel="nofollow">Client Carousel</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/clients/#css-filters" rel="nofollow">Client CSS Filters</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/clients/#messy-columns" rel="nofollow">Client Messy Columns</a></li> <li><a href="http://elementor.theplusaddons.com/client-load-more-lazy-load/" rel="nofollow">Client Load More</a></li> <li><a href="http://elementor.theplusaddons.com/client-pagination/" rel="nofollow">Client Pagination</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/stylish-list/" rel="nofollow">Stylist List</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/videos/" rel="nofollow">Video</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/before-after-2/" rel="nofollow">Before After</a></li><li><a href="http://elementor.theplusaddons.com/widgets/image-cascading/" rel="nofollow">Image Cascading</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/creative-images/" rel="nofollow">Creative Images</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/device-dynamic/" rel="nofollow">Dynamic Devices</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/switcher/" rel="nofollow">Switcher</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/row-background/" rel="nofollow">Row Background</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/row-background/parallax-background/" rel="nofollow">Parallax Background</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/row-background/segmentation-background/" rel="nofollow">Segment Background</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/row-background/canvas-background/" rel="nofollow">Canvas Background</a></li> <li><a href="http://elementor.theplusaddons.com/widgets/row-background/gallery-background/" rel="nofollow">Gallery Background</a></li>  
<li><a href="http://elementor.theplusaddons.com/plus-blogs/metro-blogs/" rel="nofollow">Blog Metro</a></li> <li><a href="http://elementor.theplusaddons.com/plus-blogs/carousel-blogs/" rel="nofollow">Blog Carousel</a></li> <li><a href="http://elementor.theplusaddons.com/plus-blogs/blog-filter/" rel="nofollow">Blog Filter</a></li> <li><a href="http://elementor.theplusaddons.com/plus-blogs/messy-columns-blogs/" rel="nofollow">Blog Messy Columns</a></li> <li><a href="http://elementor.theplusaddons.com/plus-blogs/blog-stagger-load/" rel="nofollow">Blog Stagger Load</a></li> <li><a href="http://elementor.theplusaddons.com/plus-blogs/lazy-load-blogs/" rel="nofollow">Blog Lazy Load</a></li> <li><a href="http://elementor.theplusaddons.com/plus-blogs/pagination-blogs/" rel="nofollow">Blog Pagination</a></li> <li><a href="http://elementor.theplusaddons.com/plus-blogs/load-more-blogs/" rel="nofollow">Blog Load More</a></li>
</ul>


#Premium Version also have below features :
###Check All 60+ Elements: <a href="http://elementor.theplusaddons.com/widgets/" rel="nofollow">Visit Now</a>
###18+ Page Templates : <a href="http://elementor.theplusaddons.com/plus-templates/" target="_blank">Check Plus Templates</a>
<ul> <li><a href="http://elementor.theplusaddons.com/plus-design/creative-agency/" rel="nofollow">Creative Agency</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/modern-restaurant/" rel="nofollow">Restaurant</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/beauty-saloon/" rel="nofollow">Beauty Salon</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/health/" rel="nofollow">Medical</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/design-studio/" rel="nofollow">Design Studio</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/financial/" rel="nofollow">Business</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/architecture/" rel="nofollow">Architecture</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/digital-agency/" rel="nofollow">Digital Agency</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/gym/" rel="nofollow">GYM</a></li>
<li><a href="http://elementor.theplusaddons.com/plus-design/corporate-agency/" rel="nofollow">Corporate Agency</a></li>
</ul>
###300+ UI Blocks : <a href="http://elementor.theplusaddons.com/plus-blocks/" target="_blank">Check Plus Blocks</a>



<h3>3rd Party Themes Compatibility</h3> We have tested with most popular and Elementor friendly themes. Those are as follows: <ul> <li> <strong>Premium Themes:</strong> <ul> <li><a href="https://themeforest.net/item/avada-responsive-multipurpose-theme/2833226">Avada</a></li> <li><a href="https://themeforest.net/item/the7-responsive-multipurpose-wordpress-theme/5556590">The 7</a></li> <li><a href="https://themeforest.net/item/porto-responsive-wordpress-ecommerce-theme/9207399">Porto</a></li> </ul> </li> <li> <strong>Free Themes:</strong> <ul> <li><a href="https://wordpress.org/themes/oceanwp/" rel="nofollow">OceanWP</a></li> <li><a href="https://wordpress.org/themes/astra/" rel="nofollow">Astra</a></li>  <li><a href="https://wordpress.org/themes/sydney/" rel="nofollow">Sydney</a></li> </ul> </li> <li>We will release detailed test reports soon and more theme testing are coming soon</li> </ul>





#### This plugin is addon of Elementor Page Builder
<a href="https://elementor.com/">Elementor Page Builder</a> plugin must be installed and activated to use our plugin.

<p><a href="http://elementor.theplusaddons.com/pricing" rel="nofollow">Live Demo</a> | <a href="https://posimyth.ticksy.com" rel="nofollow">Support forum(Premium Version)</a> | <a href="https://wordpress.org/support/plugin/the-plus-addons-for-elementor" rel="nofollow">Support Forum (Free Version)</a></p>


<p><strong>If you like this plugin, please give us ⭐️ ⭐️ ⭐️ ⭐️ ⭐️ to encourage for future improvement.</strong></p>


== Installation ==

1. Go to plugins in your dashboard and select 'add new'
2. Search for 'ThePlus Addons for Elementor' and install it
3. Now You will have all options available in your Elementor Panel.
4. Check Setting of plugin to know extra options.
5. You can start building website using brand new addons.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==
= 1.1.1 =
* Compatibility Issue Resolved
* Minor Bug Fixes

= 1.1.0 =
* Minor Bug Fixes
* Post fixed "Lite" in plugin name

= 1.0 =
* Initial Release