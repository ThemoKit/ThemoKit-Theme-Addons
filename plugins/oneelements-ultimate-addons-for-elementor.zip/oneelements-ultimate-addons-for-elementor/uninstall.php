<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following flow
 * of control:
 *
 * - This method should be static
 * - Check if the $_REQUEST content actually is the plugin name
 * - Run an admin referrer check to make sure it goes through authentication
 * - Verify the output of $_GET makes sense
 * - Repeat with other user roles. Best directly by using the links/query string parameters.
 * - Repeat things for multisite. Once for a single site in the network, once sitewide.
 *
 * This file may be updated more in future version of the Boilerplate; however, this is the
 * general skeleton and outline for how the file should work.
 *
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       https://themexclub.com
 * @since      1.0.0
 *
 * @package    One_Elements
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}


//remove custom elementor icons files on uninstallation
function one_elements_rmdir( $dir ) {

	if ( is_dir( $dir ) ) {
		$objects = scandir( $dir );
		foreach ( $objects as $object ) {
			if ( $object != "." && $object != ".." ) {
				if ( is_dir( $dir . "/" . $object ) ) {
					one_elements_rmdir( $dir . "/" . $object );
				} else {
					unlink( $dir . "/" . $object );
				}
			}
		}
		rmdir( $dir );
	}

}

$upload = wp_upload_dir();
$upload_dir  = $upload['basedir'] . '/elementor_icons_files';

$options = get_option( 'ec_icons_fonts' );

if ( !empty( $options ) && is_array($options) ) {

	foreach ( $options as $key => $font ) {

		if ( empty( $font['data'] ) ) {
			continue;
		}

		$font_decode = json_decode($font['data'],true);

		one_elements_rmdir( $upload_dir . '/' . $font_decode['file_name'] );

	}

}
unlink( $upload_dir . '/merged-icons-font.css');
delete_option('ec_icons_fonts');