jQuery( window ).on( 'elementor:init', function() {

    const ControlImageChooseItemView = elementor.modules.controls.Choose.extend({});
    
    elementor.addControlView( 'image_choose', ControlImageChooseItemView );
});

function one_element_chunk(obj, chunkSize) {

    const values = Object.values(obj);

    let final = [],
        counter = 0,
        portion = {};

    for (const key of Object.keys(obj)) {
        if (counter !== 0 && counter % chunkSize === 0) {
            final.push(portion);
            portion = {};
        }
        portion[key] = values[counter];
        counter++
    }

    final.push(portion);

    return final;

}