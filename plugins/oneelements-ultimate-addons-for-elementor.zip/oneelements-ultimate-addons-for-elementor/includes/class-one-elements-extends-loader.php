<?php
namespace OneElements\Includes\Exts;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

require_once ONE_ELEMENTS_INC_PATH . 'extends/class-one-elements-section.php';

one_elements_ext_section()->init();