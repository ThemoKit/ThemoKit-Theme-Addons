<?php
namespace OneElements\Includes\Exts;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;

/**
 * Fired during plugin deactivation
 *
 * @link       https://themexclub.com
 * @since      1.0.0
 *
 * @package    One_Elements
 * @subpackage One_Elements/includes
 */

if ( ! defined( 'WPINC' ) ) die;

if ( ! class_exists( 'ONE_ELEMENTS_Addons_Section' ) ) {

	/**
	 * Define ONE_ELEMENTS_Addons_Section class
	 */
	class ONE_ELEMENTS_Addons_Section {

		/**
		 * [$parallax_sections description]
		 * @var array
		 */
		public $parallax_sections = array();

		/**
		 * A reference to an instance of this class.
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    object
		 */
		private static $instance = null;

		/**
		 * Init Handler
		 */
		public function init() {

			add_action( 'elementor/element/section/section_layout/after_section_end', array( $this, 'after_section_end' ), 10, 2 );

			add_action( 'elementor/frontend/element/before_render', array( $this, 'section_before_render' ) );
			add_action( 'elementor/frontend/section/before_render', array( $this, 'section_before_render' ) );

			add_action( 'elementor/frontend/before_enqueue_scripts', array( $this, 'enqueue_scripts' ), 9 );
		}

		/**
		 * After section_layout callback
		 *
		 * @param  object $obj
		 * @param  array $args
		 * @return void
		 */
		public function after_section_end( $obj, $args ) {

			if ( class_exists( 'ONE_ELEMENTS_Parallax' ) ) {
				return false;
			}

			$obj->start_controls_section(
				'section_parallax',
				array(
					'label' => esc_html__( 'One Parallax', 'one-elements' ),
					'tab'   => Controls_Manager::TAB_LAYOUT,
				)
			);

			$obj->add_control(
				'one_elements_parallax_items_heading',
				array(
					'label'     => esc_html__( 'Layouts', 'one-elements' ),
					'type'      => Controls_Manager::HEADING,
				)
			);

			$repeater = new Repeater();

			$repeater->add_responsive_control(
				'one_elements_parallax_layout_image',
				array(
					'label'   => esc_html__( 'Image', 'one-elements' ),
					'type'    => Controls_Manager::MEDIA,
					'dynamic' => array( 'active' => true ),
					'selectors' => array(
						'{{WRAPPER}} {{CURRENT_ITEM}}.jet-parallax-section__layout .jet-parallax-section__image' => 'background-image: url("{{URL}}") !important;'
					),
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_speed',
				array(
					'label'      => esc_html__( 'Parallax Speed(%)', 'one-elements' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( '%' ),
					'range'      => array(
						'%' => array(
							'min'  => 1,
							'max'  => 100,
						),
					),
					'default' => array(
						'size' => 50,
						'unit' => '%',
					),
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_type',
				array(
					'label'   => esc_html__( 'Parallax Type', 'one-elements' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'scroll',
					'options' => array(
						'none'   => esc_html__( 'None', 'one-elements' ),
						'scroll' => esc_html__( 'Scroll', 'one-elements' ),
						'mouse'  => esc_html__( 'Mouse Move', 'one-elements' ),
						'zoom'   => esc_html__( 'Scrolling Zoom', 'one-elements' ),
					),
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_z_index',
				array(
					'label'    => esc_html__( 'z-Index', 'one-elements' ),
					'type'     => Controls_Manager::NUMBER,
					'min'      => 0,
					'max'      => 99,
					'step'     => 1,
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_bg_x',
				array(
					'label'   => esc_html__( 'Background X Position(%)', 'one-elements' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 50,
					'min'     => -200,
					'max'     => 200,
					'step'    => 1,
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_bg_y',
				array(
					'label'   => esc_html__( 'Background Y Position(%)', 'one-elements' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 50,
					'min'     => -200,
					'max'     => 200,
					'step'    => 1,
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_bg_size',
				array(
					'label'   => esc_html__( 'Background Size', 'one-elements' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'auto',
					'options' => array(
						'auto'    => esc_html__( 'Auto', 'one-elements' ),
						'cover'   => esc_html__( 'Cover', 'one-elements' ),
						'contain' => esc_html__( 'Contain', 'one-elements' ),
						'custom' => esc_html__( 'Custom', 'one-elements' ),
					),
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_bg_size_custom',
				array(
					'label'   => esc_html__( 'Background Width', 'one-elements' ),
					'type'    => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', '%', 'vw' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
						'vw' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'size' => 100,
						'unit' => '%',
					],
					'options' => array(
						'auto'    => esc_html__( 'Auto', 'one-elements' ),
						'cover'   => esc_html__( 'Cover', 'one-elements' ),
						'contain' => esc_html__( 'Contain', 'one-elements' ),
						'custom' => esc_html__( 'Custom', 'one-elements' ),
					),
					'condition' => [
						'one_elements_parallax_layout_bg_size' => 'custom'
					],
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_animation_prop',
				array(
					'label'   => esc_html__( 'Animation Property', 'one-elements' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'transform',
					'options' => array(
						'bgposition'  => esc_html__( 'Background Position', 'one-elements' ),
						'transform'   => esc_html__( 'Transform', 'one-elements' ),
						'transform3d' => esc_html__( 'Transform 3D', 'one-elements' ),
					),
				)
			);

			$repeater->add_control(
				'one_elements_parallax_layout_on',
				array(
					'label'       => __( 'Enable On Device', 'one-elements' ),
					'type'        => Controls_Manager::SELECT2,
					'multiple'    => true,
					'label_block' => 'true',
					'default'     => array(
						'desktop',
						'tablet',
					),
					'options'     => array(
						'desktop' => __( 'Desktop', 'one-elements' ),
						'tablet'  => __( 'Tablet', 'one-elements' ),
						'mobile'  => __( 'Mobile', 'one-elements' ),
					),
				)
			);

			$obj->add_control(
				'one_elements_parallax_layout_list',
				array(
					'type'    => Controls_Manager::REPEATER,
					'fields'  => array_values( $repeater->get_controls() ),
					'default' => array(
						array(
							'one_elements_parallax_layout_image' => array(
								'url' => '',
							),
						)
					),
				)
			);

			$obj->end_controls_section();
		}

		/**
		 * Elementor before section render callback
		 *
		 * @param  object $obj
		 * @return void
		 */
		public function section_before_render( $obj ) {

			$data     = $obj->get_data();
			$type     = isset( $data['elType'] ) ? $data['elType'] : 'section';
			$settings = $data['settings'];

			if ( 'section' === $type ) {

				if ( isset( $settings['one_elements_parallax_layout_list'] ) ) {

					$parallax_layout_list = method_exists( $obj, 'get_settings_for_display' ) ? $obj->get_settings_for_display( 'one_elements_parallax_layout_list' ) : $settings['one_elements_parallax_layout_list'];

					if ( is_array( $parallax_layout_list ) && ! empty( $parallax_layout_list ) ) {

						foreach ( $parallax_layout_list as $key => $layout ) {

							if ( empty( $layout['one_elements_parallax_layout_image']['url'] )
								&& empty( $layout['one_elements_parallax_layout_image_tablet']['url'] )
								&& empty( $layout['one_elements_parallax_layout_image_mobile']['url'] )
							) {
								continue;
							}

							if ( ! in_array( $data['id'], $this->parallax_sections ) ) {
								$this->parallax_sections[ $data['id'] ] = $parallax_layout_list;
							}

						}

					}

				}

			}

		}

		/**
		 * [enqueue_scripts description]
		 *
		 * @return void
		 */
		public function enqueue_scripts() {

			if ( ! empty( $this->parallax_sections ) ) {
				wp_localize_script( 'one-elements', 'oneParallaxSections', $this->parallax_sections );
			}

		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {
			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Returns instance of ONE_ELEMENTS_Addons_Section
 *
 * @return object
 */
function one_elements_ext_section() {
	return ONE_ELEMENTS_Addons_Section::get_instance();
}