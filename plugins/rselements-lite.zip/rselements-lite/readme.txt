﻿=== RS Elements Elementor Addon ===
Plugin Name: RS Elements Elementor Addon
Version: 1.0.1
Author: RSTheme
Author URI: https://rstheme.com/products/wordpress/plugins/elementor/
Contributors: rstheme2017
Tags: elementor, elementor addon, elementor widget, essential widget, elements, rsaddon
Requires at least: 4.7
Tested up to: 5.3
Stable tag: trunk
Requires PHP: 5.4
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

[RSElements Addon](https://rstheme.com/products/wordpress/plugins/elementor/) is a collection of powerful widgets that works perfectly with Elementor page builder. It has 30+ widgets so you can eaily make awesome pages. RSElementor Addon is free for use, most growing addon and comes with dedicated support.

== Description ==

[RSElements Addon](https://rstheme.com/products/wordpress/plugins/elementor/) is a collection of powerful widgets that works perfectly with Elementor page builder. It has 30+ widgets so you can eaily make awesome pages. RSElementor Addon is free for use, most growing addon and comes with dedicated support.

== Demo ==

Chek our <a href="https://rstheme.com/products/wordpress/plugins/elementor/">demo</a>


<h3> 40+ Free Widgets</h3>

1. <a href="https://rstheme.com/products/wordpress/plugins/elementor/heading-style/">Heading</a>
2. <a href="https://rstheme.com/products/wordpress/plugins/elementor/dual-heading-style/">Dual Heading</a>
3. <a href="https://rstheme.com/products/wordpress/plugins/elementor/animated-heading-style/">Animated Heading</a>
4. <a href="https://rstheme.com/products/wordpress/plugins/elementor/button/">Button</a>
5. <a href="https://rstheme.com/products/wordpress/plugins/elementor/call-to-action/">Call To Action</a>
6. <a href="https://rstheme.com/products/wordpress/plugins/elementor/icon-box/">Icon Box</a>
7. <a href="https://rstheme.com/products/wordpress/plugins/elementor/services">Info Box</a>
8. <a href="https://rstheme.com/products/wordpress/plugins/elementor/number/">Number</a>
9. <a href="https://rstheme.com/products/wordpress/plugins/elementor/counter/">Counter</a>
10. <a href="https://rstheme.com/products/wordpress/plugins/elementor/team-grid/">Team Grid</a>
11. <a href="https://rstheme.com/products/wordpress/plugins/elementor/blog/">Blog Grid</a>
12. <a href="https://rstheme.com/products/wordpress/plugins/elementor/portfolio/">Project Grid</a>
13. <a href="https://rstheme.com/products/wordpress/plugins/elementor/flip-box/">Flip Box</a>
14. <a href="https://rstheme.com/products/wordpress/plugins/elementor/video">Video</a>
15. <a href="https://rstheme.com/products/wordpress/plugins/elementor/tooltip/">Tooltip</a>
16. <a href="https://rstheme.com/products/wordpress/plugins/elementor/business-hours/">Business Hour</a>
17. <a href="https://rstheme.com/products/wordpress/plugins/elementor/logo-grid-showcase">Logoshow case</a>
18. <a href="https://rstheme.com/products/wordpress/plugins/elementor/faq">FAQ</a>
19. <a href="https://rstheme.com/products/wordpress/plugins/elementor/progress-bar">Progress Bar</a>
20. <a href="https://rstheme.com/products/wordpress/plugins/elementor/rs-tab/">TAB</a>
21. <a href="https://rstheme.com/products/wordpress/plugins/elementor/rs-static-products">Static Product</a>
22. <a href="https://rstheme.com/products/wordpress/plugins/elementor/price-table">Price Table</a>
23. <a href="https://rstheme.com/products/wordpress/plugins/elementor/contact-form-7">Contact Form 7</a>
24. <a href="https://rstheme.com/products/wordpress/plugins/elementor/contact-boxes">Address Box</a>
25. <a href="https://rstheme.com/products/wordpress/plugins/elementor/testimonial/">Testimonial</a>
26. <a href="https://rstheme.com/products/wordpress/plugins/elementor">Image Widget</a>

<h3> 10+ Premium Widgets</h3>

1. <a href="https://rstheme.com/products/wordpress/plugins/elementor/dual-button/" rel="nofollow">Dual Button</a>
2. <a href="https://rstheme.com/products/wordpress/plugins/elementor/countdown/" rel="nofollow">Countdown</a>
3. <a href="https://rstheme.com/products/wordpress/plugins/elementor/team-slider/" rel="nofollow">Team Slider</a>
4. <a href="https://rstheme.com/products/wordpress/plugins/elementor/blog-slider/" rel="nofollow">Blog Slider</a> 
5. <a href="https://rstheme.com/products/wordpress/plugins/elementor/portfolio-slider/" rel="nofollow">Project Slider</a> 
6. <a href="https://rstheme.com/products/wordpress/plugins/elementor/logo-slider-showcase/" rel="nofollow">Logoshowcase Slider</a> 
7. <a href="https://rstheme.com/products/wordpress/plugins/elementor/progress-pie/">Progress Pie</a>
8. <a href="https://rstheme.com/products/wordpress/plugins/elementor/advanced-tabs/">Advanced Tab</a> 
9. <a href="https://rstheme.com/products/wordpress/plugins/elementor/testimonial-slider/" rel="nofollow">Testimonial Slider</a>
10. <a href="https://rstheme.com/products/wordpress/plugins/elementor/rs-table/">Table</a>
11. <a href="https://rstheme.com/products/wordpress/plugins/elementor/features-list/">Features List</a>
12. <a href="https://rstheme.com/products/wordpress/plugins/elementor/rs-image-hover-effect/">Image Hover</a>


== Screenshots ==


== Installation ==

It's really easy  to install RSElements Lite Addon plugin but before installing this  make sure you've installed [Elementor](https://wordpress.org/plugins/elementor/ "Install Elementor"). **Elementor** is the only dependency.

= Automatic Installation =
1.  Go to `Plugins > Add New` screen in WordPress.
2.  Search for `RSElements Elementor Addon`.
3.  Install and activate the plugin, that's it.


= Manual Installation =
1. Download RS <a href="https://downloads.wordpress.org/plugin/rselements-lite.zip">Elements Elementor Addon</a>.
2. Extract the rselements-lite.zip file. You’ll get plugin files inside rselements-lite directory.
3. Upload the plugin files to the /wp-content/plugins/rselements-lite directory.
4. Activate the plugin through the ‘Plugins’ screen in WordPress.


== Changelog ==

= 1.0.1 =
* Fixed Style
* Added New Elements

= 0.0.1 =

* Initial release