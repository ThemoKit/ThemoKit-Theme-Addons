<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class WL_Product_Upsell_Element extends Widget_Base {

    public function get_name() {
        return 'wl-single-product-upsell';
    }

    public function get_title() {
        return __( 'WL: Product Upsell', 'woolentor' );
    }

    public function get_icon() {
        return 'eicon-product-upsell';
    }

    public function get_categories() {
        return array( 'woolentor-addons' );
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'product_upsell_content',
            [
                'label' => __( 'Upsells', 'woolentor' ),
            ]
        );

            $this->add_responsive_control(
                'columns',
                [
                    'label' => __( 'Columns', 'woolentor' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                    'min' => 1,
                    'max' => 12,
                ]
            );

            $this->add_control(
                'orderby',
                [
                    'label' => __( 'Order By', 'woolentor' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'date',
                    'options' => [
                        'date'          => __( 'Date', 'woolentor' ),
                        'title'         => __( 'Title', 'woolentor' ),
                        'price'         => __( 'Price', 'woolentor' ),
                        'popularity'    => __( 'Popularity', 'woolentor' ),
                        'rating'        => __( 'Rating', 'woolentor' ),
                        'rand'          => __( 'Random', 'woolentor' ),
                        'menu_order'    => __( 'Menu Order', 'woolentor' ),
                    ],
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Order', 'woolentor' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'desc',
                    'options' => [
                        'asc'   => __( 'ASC', 'woolentor' ),
                        'desc'  => __( 'DESC', 'woolentor' ),
                    ],
                ]
            );

            $this->add_control(
                'wl_show_heading',
                [
                    'label' => __( 'Heading', 'woolentor' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'woolentor' ),
                    'label_off' => __( 'Hide', 'woolentor' ),
                    'render_type' => 'ui',
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'prefix_class' => 'wl-show-heading-',
                ]
            );

        $this->end_controls_section();

        // Heading Style
        $this->start_controls_section(
            'heading_style_section',
            array(
                'label' => __( 'Heading', 'woolentor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            )
        );
            $this->add_control(
                'heading_color',
                [
                    'label' => __( 'Color', 'woolentor' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '.woocommerce {{WRAPPER}} h2' => 'color: {{VALUE}}',
                    ],
                    'condition' => [
                        'wl_show_heading!' => '',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'heading_typography',
                    'label' => __( 'Typography', 'woolentor' ),
                    'selector' => '.woocommerce {{WRAPPER}} h2',
                    'condition' => [
                        'wl_show_heading!' => '',
                    ],
                ]
            );

            $this->add_responsive_control(
                'heading_margin',
                [
                    'label' => __( 'Margin', 'woolentor' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '.woocommerce {{WRAPPER}} h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'condition' => [
                        'wl_show_heading!' => '',
                    ],
                ]
            );

        $this->end_controls_section();

    }


    protected function render( $instance = [] ) {

        $settings = $this->get_settings_for_display();
        $product_per_page   = '-1';
        $columns            = 4;
        $orderby            = 'rand';
        $order              = 'desc';
        if ( ! empty( $settings['columns'] ) ) {
            $columns = $settings['columns'];
        }
        if ( ! empty( $settings['orderby'] ) ) {
            $orderby = $settings['orderby'];
        }
        if ( ! empty( $settings['order'] ) ) {
            $order = $settings['order'];
        }
        woocommerce_upsell_display( $product_per_page, $columns, $orderby, $order );

    }

}
Plugin::instance()->widgets_manager->register_widget_type( new WL_Product_Upsell_Element() );
