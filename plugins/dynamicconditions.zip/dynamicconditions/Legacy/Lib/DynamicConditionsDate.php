<?php

namespace Lib;


use DynamicConditions\Lib\Date;

/**
 * @deprecated Will be removed in future updates. Use DynamicTag\Lib\Date instead.
 * @package Lib
 */
class DynamicConditionsDate extends Date {

}
