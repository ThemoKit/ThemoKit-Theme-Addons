=== Mega Addons For Elementor ===
Contributors: qsheeraz, nasir179125
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YNF4H9FJY4HU4
Tags: mega addons for elementor, ultimate addons for elementor, addons for elementor page builder, all in one plugin, elementor extension, multi addons for elementor, imag hover effects, page builder, member profile, info banner, price table, modal popup,
Requires at least: 3.0.1
Tested up to: 5.3
Requires PHP: 7.0
Stable tag: 1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A collection of premium quality addons, Beautifully designed unique elements for Elementor Page Builder.

== Description ==

<blockquote>
    <p>
        <strong>Best Addons Plugin For Elementer Page Builder - WordPress Plugin</strong>
    </p>
</blockquote>
Mega Addons For Elementor ~ The Addon bundle for Elementor With 18 addons. This Addon Bundle provide you functionality for your Elementor Page Builder. Addons for Elementor features professional looking, easy to use yet highly functional extensions that can be used in a Elementor page builder.

<blockquote>
<p><a href="http://elementor.topdigitaltrends.net/" rel="nofollow">Live Demo </a> | <a href="http://www.topdigitaltrends.net/contact/" rel="nofollow">Contact</a> | <a href="https://wordpress.org/support/plugin/ultimate-addons-for-elementor" rel="nofollow">Support forum</a></p>
</blockquote>
<p><strong>If you like this plugin, please give us <a href="https://wordpress.org/support/plugin/ultimate-addons-for-elementor/reviews/#new-post" rel="nofollow">5 star</a> to encourage for future improvement.</strong></p>

<h3>Features</h3>
<ul>
	<li><a href="https://elementor.topdigitaltrends.net/advanced-carousel/">Advanced Carousel</a> Show as carousel</li>
	<li><a href="http://elementor.topdigitaltrends.net/info-banner/">Info Banner</a> Displays the banner information</li>
	<li><a href="http://elementor.topdigitaltrends.net/image-hover-effects/">Image Hove Effects</a> Image Hover Effects</li>
	<li><a href="http://elementor.topdigitaltrends.net/pricing-table/">Price Table</a> Create nice looking price tables</li>
	<li><a href="http://elementor.topdigitaltrends.net/member-profile/">Member Profile</a> Show your awesome team</li>
	<li><a href="http://elementor.topdigitaltrends.net/interactive-banner/">Interactive Banner</a> great hover effects</li>
	<li><a href="http://elementor.topdigitaltrends.net/info-box/">Info Box</a> Add icon box with custom font icon</li>
	<li><a href="http://elementor.topdigitaltrends.net/creative-link/">Creative Link</a> Creative links button</li>
	<li><a href="http://elementor.topdigitaltrends.net/stats-counter/">Stats Counter</a> Your milestones, achievements etc</li>
	<li><a href="http://elementor.topdigitaltrends.net/modal-popup/">Modal Popup</a> Add modal box in your content</li>
	<li><a href="http://elementor.topdigitaltrends.net/timeline/">Timeline</a> Add multiple images and text</li>
	<li><a href="http://elementor.topdigitaltrends.net/countdown/">Countdown</a> Set Countdown timer</li>
	<li><a href="https://elementor.topdigitaltrends.net/advanced-button/">Advanced Button</a> Set Countdown timer</li>
	<li><a href="http://elementor.topdigitaltrends.net/flip-box/">Flip Box</a> Add icon box with custom font icon</li>
	<li><a href="http://elementor.topdigitaltrends.net/info-list/">Info List</a> Text blocks connected together in one list</li>
	<li><a href="http://elementor.topdigitaltrends.net/highlight-box/">HighLight Box</a> Beautiful designed buttons for highlight</li>
	<li><a href="http://elementor.topdigitaltrends.net/accordion/">Accordion</a> Vertically stacked list of items</li>
	<li><a href="http://elementor.topdigitaltrends.net/info-circle/">Info Circle</a> Express info about your work</li>
	<li><a href="http://elementor.topdigitaltrends.net/headings/">Headings</a> Display stylish headings</li>
	<li><a href="http://elementor.topdigitaltrends.net/dual-button/">Dual Button</a> Add a dual button and give some desing</li>
</ul>

<h3>More elements on <a href="http://elementor.topdigitaltrends.net/" rel="nofollow">Premium Version</a></h3>
<ul>
	<li><a href="https://elementor.topdigitaltrends.net/advanced-carousel/">Advanced Carousel</a> Show as carousel (Autoplay On/Off, Link To option.)</li>
	<li><a href="https://elementor.topdigitaltrends.net/flip-book/">Flip Book</a> 3D Page Flip Book</li>
	<li><a href="https://elementor.topdigitaltrends.net/image-hover-effects-popup-demo/">Image Hover Effects Popup Demo</a> Image Hover Effects</li>
	<li><a href="https://elementor.topdigitaltrends.net/advanced-social-icons/">Advanced Social Icons</a> social icons with animated effects</li>
	<li><a href="https://elementor.topdigitaltrends.net/interactive-banner-2/">Interactive Banners 2</a> Display Image With Information</li>
	<li><a href="https://elementor.topdigitaltrends.net/interactive-banner/">Interactive Banners Pro</a> (10+ More) Display Image With Information</li>
	<li><a href="https://elementor.topdigitaltrends.net/image-hover-effects/">Image Hover Effects Pro </a>(15+ More Style) Image Hover Effects</li>
	<li><a href="https://elementor.topdigitaltrends.net/texttyping-effect/">TextTyping Effect</a> Fancy line with animation effects</li>
	<li><a href="https://elementor.topdigitaltrends.net/tooltip-icons/">Tooltip Icons</a> show icons with tooltip</li>
	<li><a href="https://elementor.topdigitaltrends.net/pricing-table/">Pricing Table Pro</a> (3 More Design) Create nice looking price tables</li>
	<li><a href="https://elementor.topdigitaltrends.net/testimonial/">Testimonial</a> show client comments as testimonial</li>
	<li><a href="https://elementor.topdigitaltrends.net/image-swap/">Image Swap</a> Image over image hover effects</li>
	<li><a href="https://elementor.topdigitaltrends.net/before-after-image/">Before After Image</a> Compare the Images</li>
	<li>You can disable unused elements from dashboard to speed up your page loading time.</li>
	<li>We made this plugin by testing on real devices. Mega Addons Supports All Modern Browsers and Mobile Devices. Touch behavior can also be setup as you want.</li>
</ul>

<blockquote>
    <h3>
        <strong>Top Rated Collection Of Plugins and Themes 2019</strong>
    </h3>
</blockquote>
<ul>
	<li><a href="http://www.topdigitaltrends.net/collections/20-best-personal-blog-wordpress-themes-2019/">20 Best Personal Blog WordPress Themes 2019</a></li>
	<li><a href="http://www.topdigitaltrends.net/collections/top-20-wordpress-review-themes-for-e-gadgets-services-apps-games-2019/">Top 10+ Best Review WordPress Themes 2019</a></li>
	<li><a href="http://www.topdigitaltrends.net/collections/10-best-nightclub-wordpress-themes-2019/">10 Best Nightclub WordPress Themes 2019</a></li>
</ul>

== Installation ==

Here are few steps to follow:

1. Upload `ultimate-addons-for-elementor` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. That's it. You're ready to go!

== Frequently Asked Questions ==

= Do I need Elementor plugin to use Mega Addons for Elementor? =

Yes you must have elementor plugin installed and active to use Mega Addons for Elementor.

== Screenshots ==

1. screenshot-1.jpg

2. screenshot-2.jpg

3. screenshot-3.jpg

4. screenshot-4.jpg

5. screenshot-5.jpg


== Changelog ==

= 1.6 - 24/03/2019 =

* Bug Fixed: CSS changes content alignment.
* Minor changes in "Accordion" widget settings.

= 1.5 - 15/03/2019 =

* New Widget: Advanced Carousel
* Bug Fixed: Widgets doesn't show live preivew while editing settings.
* Ino Box: Addition of WP-Editor option for description field and Box shadow and "Link To" options.
* Accordion: Options of Collapseable + animation + mouseover and clickable, plus panel height issue resolved.
* Info List: WP-Editor option for description field.

= 1.4 - 30/11/2018 =

* New Widget: Advanced Button
* Now Pro features Available Include 13+ Widgets.
* You can disable unused elements from dashboard to speed up your page loading time.
* Pro Features: Advanced Carousel 
* Pro Features: 3D Flip Book
* Pro Features: Image Hover Effects Popup
* Pro Features: Advanced Social Icons
* Pro Features: Interactive Banners (10+ More)
* Pro Features: Interactive Banners 2
* Pro Features: Image Hover Effects Pro (15 More Effects)
* Pro Features: TextTyping Effect 
* Pro Features: Tooltip Icons 
* Pro Features: Pricing Table Pro (3 More Design)
* Pro Features: Testimonial 
* Pro Features: Image Swap
* Pro Features: Before After Image

= 1.3 - 30/11/2018 =

* Widget Addition: Info Circle
* Widget Addition: Headings
* Widget Addition: Dual Button
* Minor Bug Fixed

= 1.2 - 12/11/2018 =

* Widget Addition: Info List
* Widget Addition: HighLight Box
* Widget Addition: Accordion

= 1.1 - 29/10/2018 =

* New Element Addition: Timeline
* New Element Addition: Countdown
* New Element Addition: Flip Box
* Minor Bug Fixed

= 1.0.3 - 24/09/2018 =

* New Element Addition: Modal Popup

= 1.0.2 - 24/09/2018 =

* New Element Addition: Stats Counter

= 1.0.1 - 24/09/2018 =

* New Element Addition: Info Box
* New Element Addition: Creative Link

= 1.0 - 21/09/2018 =

* First release.

== Upgrade Notice ==

= 1.1 =