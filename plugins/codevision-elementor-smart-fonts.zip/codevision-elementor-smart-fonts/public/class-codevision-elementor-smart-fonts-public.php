<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.codevision.io
 * @since      1.0.0
 *
 * @package    Codevision_Elementor_Smart_Fonts
 * @subpackage Codevision_Elementor_Smart_Fonts/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Codevision_Elementor_Smart_Fonts
 * @subpackage Codevision_Elementor_Smart_Fonts/public
 * @author     codevision <info@codevision.io>
 */
class Codevision_Elementor_Smart_Fonts_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		$fonts = get_option( 'esf_user_fonts' );

		if ( ! $fonts ) {
			return;
		}

		foreach ( $fonts as $font ) {

			wp_enqueue_style( $font['font_name'], $font['stylesheet'], array(), $this->version, 'all' );
		}

	}

	function elementor_add_font_group( $groups ) {

		$groups['esf'] = __( 'Smart Fonts', 'elementor-smart-fonts' );

		return $groups;
	}

	function elementor_add_fonts( $elementor_fonts ) {
		$fonts = get_option( 'esf_user_fonts' );

		if ( ! $fonts ) {
			return $elementor_fonts;
		}

		foreach ( $fonts as $font ) {
			$elementor_fonts[ $font['font_name'] ] = 'esf';
		}

		return $elementor_fonts;
	}

}
