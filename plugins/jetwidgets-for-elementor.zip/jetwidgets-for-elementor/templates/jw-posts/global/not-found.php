<?php
/**
 * Posts not found template
 */
?>
<h3 class="jw-posts__not-found"><?php esc_html_e( 'Posts not found', 'jetwidgets-for-elementor' ); ?></h3>
