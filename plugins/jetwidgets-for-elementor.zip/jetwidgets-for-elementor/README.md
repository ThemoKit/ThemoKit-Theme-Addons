# JetWidgets For Elementor

Brand new addon for Elementor Page builder. It provides the set of modules to create different kinds of content, adds custom modules to your website and applies attractive styles in the matter of several clicks!

# ChangeLog

## [1.0.6]
* upd: plugin data

## [1.0.5]
* fix: minor bugs

## [1.0.4]
* add: responsive controls to some widgets

## [1.0.3]
* add: vertical mode to carousel widget

## [1.0.2]
* Fixed: compatibility this font-awesome-5 in widget testimonials

## [1.0.1]
* Added: Rating to Testi Widget

## [1.0.0]
* Init
