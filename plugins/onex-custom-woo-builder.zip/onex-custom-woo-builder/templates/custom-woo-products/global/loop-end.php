<?php
/**
 * Products loop end template
 */
?>
</div>
