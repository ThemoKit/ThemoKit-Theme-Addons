<?php
/**
 * Template Library Header Tabs
 */
?>
<script type="text/html" id="tmpl-tci-uet-tabs">
	<div id="tci-uet-modal-tabs-items"></div>
</script>