<?php
/**
 * Templates Modal Container
 */
?>
<script type="text/html" id="tmpl-tci-uet-templates">
	<div id="tci-uet-modal-templates-container"></div>
</script>