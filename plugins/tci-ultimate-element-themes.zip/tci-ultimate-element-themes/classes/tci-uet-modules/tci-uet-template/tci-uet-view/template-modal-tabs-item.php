<?php
/**
 * Template Library Header Tabs
 */
?>
<script type="text/html" id="tmpl-tci-uet-tab-time">
	<label>
		<input type="radio" value="{{ slug }}" name="tci-uet-template-modal-header-tab">
		<span>{{ title }}</span>
	</label>
</script>