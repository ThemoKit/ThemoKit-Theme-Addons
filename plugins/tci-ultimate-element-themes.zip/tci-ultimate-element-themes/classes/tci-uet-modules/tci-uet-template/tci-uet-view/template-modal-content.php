<?php
/**
 * Templates Loader View
 */
?>
<script type="text/html" id="tmpl-tci-uet-content">
	<div class="tci-uet-filters-list"></div>
	<div class="tci-uet-templates-wrap">
		<div class="tci-uet-keywords-list"></div>
		<div class="tci-uet-templates-list"></div>
	</div>
</script>