<?php
/**
 * Templates Loader View
 */
?>
<script type="text/html" id="tmpl-tci-uet-loading">
	<div class="elementor-loader-wrapper">
		<div class="elementor-loader">
			<div class="elementor-loader-box"></div>
			<div class="elementor-loader-box"></div>
			<div class="elementor-loader-box"></div>
			<div class="elementor-loader-box"></div>
		</div>
		<div class="elementor-loading-title"><?php echo __( 'Loading', 'tci-uet' ); ?></div>
	</div>
</script>