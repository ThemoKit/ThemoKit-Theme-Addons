<?php
/**
 * Templates Item Preview
 */
?>
<script type="text/html" id="tmpl-tci-uet-preview">
	<div class="tci-uet-template-item-notice"></div>
	<div class="tci-uet-template-item-preview-iframe">
		<iframe></iframe>
	</div>
</script>
