<?php
/**
 * Template Library Modal Header
 */
?>
<script type="text/html" id="tmpl-tci-uet-header-logo">
	<span class="tci-uet-template-modal-header-logo-icon">
    <img src="<?php echo PREMIUM_ADDONS_URL . 'admin/images/tci-uet-addons-logo.png'; ?>">
</span>
	<span class="tci-uet-template-modal-header-logo-label">
    <?php echo __( 'Premium Templates', 'tci-uet' ); ?>
</span>
</script>

