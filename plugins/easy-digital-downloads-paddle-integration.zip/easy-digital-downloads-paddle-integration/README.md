# Easy Digital Downloads Paddle Integration
Paddle Integration as a payment processor for easy digital downloads

Feel free to test how this works on my website : http://easy-development.com/wordpress-plugins/

# Setup
1. Install the plugin
2. Go to Easy Digital Downloads -> Settings
3. Click Payment Processors
4. Check Paddle.
5. Get your vendor_id and an API key from your Settings Panel from Paddle.
6. Complete the information about the paddle payment gateway, it should be on the same page.
7. The overlay checkout is option, and requires one more step.
8. If you've checked the overlay payment option, go to the receipt page and add the following shortcode : [edd_paddle_integration_popup_shortcode] where you want to see the buy now button.
9. All Done.
