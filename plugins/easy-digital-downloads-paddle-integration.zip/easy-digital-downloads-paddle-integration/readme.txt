=== Plugin Name ===
Contributors: easydevelopment
Donate link: http://easy-development.com
Tags: comments, spam
Requires at least: 3.3.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

EED Paddle.com integration as a payment processor

== Description ==

Easy Digital Downloads Paddle.com integration as a payment processor

== Installation ==

1. Install the plugin
1. Go to Easy Digital Downloads -> Settings
1. Click Payment Processors
1. Check Paddle.
1. Get your vendor_id and an API key from your Settings Panel from Paddle.
1. Complete the information about the paddle payment gateway, it should be on the same page.
1. The overlay checkout is option, and requires one more step.
1. If you've checked the overlay payment option, go to the receipt page and add the following shortcode : [edd_paddle_integration_popup_shortcode] where you want to see the buy now button.
1. All Done.

