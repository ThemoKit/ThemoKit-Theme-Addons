<div class="title">
    {{{ settings.title }}}
</div>