<?php
/**
 * Get some constants ready for paths when your plugin grows
 *
 * @author Param Themes
 *
 * @package Get some constants ready for paths when your plugin grows.
 */?>
<div class="main-h2-heading">
	<?php if (is_plugin_active('pt-elementor-addons-pro/pt-elementor-addons-pro.php')) { ?>
		<h2 class='page-welcome'>PT Elementor <span>Addons Settings</span></h2>
	<?php } else { ?>
		<h2 class='page-welcome'>PT Elementor <span>Addons Settings</span></h2>
	<?php } ?>
</div>

