<?php
/**
 * Templates Loader View
 */
?>
<div class="ma-el-filters-list"></div>
<div class="ma-el-modal-templates-wrap">
	<div class="ma-el-keywords-list"></div>
	<div class="ma-el-templates-list"></div>
</div>