<?php
/**
 * Templates Modal Container
 */
?>
<div id="ma-el-modal-templates-container"></div>