<?php
/**
 * Template Library Modal Header
 */
?>
<span class="ma-el-modal-header-logo-icon">
    <img src="<?php echo MELA_IMAGE_DIR .'icon.png'; ?>">
</span>
<span class="ma-el-modal-header-logo-label">
    <?php echo __('Master Addons', MELA_TD ); ?>
</span>

