=== Info boxes for elementor ===
Contributors: wpafroz
Tags: elementor, elements, addons, elementor addon, elementor widget, page builder, builder, wordpress page builder, elementor infobox
Requires at least: 4.6
Tested up to: 5.2.4
Stable tag: 4.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

Info Boxes For Elementor is an Awesome Elementor widget that works with Elementor page builder.
It's trendy look and details customization features helps you to create Your Services Section's design easily.
With "Info Boxes For Elementor" You can easily change icon color, Fonts color, etc.
So why are you waiting for?
Download "Info Boxes For Elementor" & start making stylish sections on your Website.

== Installation ==
1. Upload `info-boxes-for-elementor.zip` to the `/wp-content/plugins/` directory and exctract
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

is it work with any wordpress theme ?
-- yes it is compatble with any wordpress theme where elemntor pagebuilder installed

== Screenshots ==
1. Overview of few widgets
2. Elements control panel
3. Info box preview

== Changelog ==

= 1.0 =
* Initial release

== A brief Markdown Example ==

Ordered list:

1. Three defferent element 
2. Color changing options
3. Image and font icon support