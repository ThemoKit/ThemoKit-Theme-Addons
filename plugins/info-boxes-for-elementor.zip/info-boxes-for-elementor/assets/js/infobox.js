( function( $ ) {
	
	// Make sure you run this code under Elementor.
	$( window ).on( 'elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/infobox.default', function( $scope, $ ) {
			console.log( $scope );
			// $scope.find('.infobox').hide();
		} );
	} );
	
} )( jQuery );
