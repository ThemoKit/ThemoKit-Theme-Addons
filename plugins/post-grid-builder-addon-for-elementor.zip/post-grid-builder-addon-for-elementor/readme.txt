=== Post Grid Builder Addon for Elementor===
Contributors: latheeshvmv
Tags: postgrid, elementor post grid, page builder, elementor, grid builder, list post, post grid, create grids,post grid elementor, front end filter
Donate link: paypal.me/latheeshvmv
Requires at least: 5.0.0
Tested up to: 5.3
Requires PHP: 5.6
License: GPL-2.0+
Stable tag: 2.0.0
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

Elementor Post Grid by Geeky Owl create Grid layout for posts, pages & custom post types. Create custom pagination.

== Description ==
This is an addon for Elementor page builder. Custom Post Type Supported. This is lite version of Elementor Post Grid Builder.

Lite Version Features :
-  Drag and arrange field types
-  Entrance and hover animation for each field type.
-  Backend ordering and filtering
-  Pagination - Custom Design
-  Custom Post Type Supported
-  Set featured images as background for grid
-  Typography and color options for each field type.
-  Class and ID selector for each field type.
-  3 field type support

Demo: [Click here](https://geekygreenowl.com/elementor-post-grid-by-geeky-green-owl/)

Pro Version
-  Every thing from the lite version.
-  ACF fields Support
-  WooCommerce Support
-  Custom field Support
-  No Footer Credit
-  Front end filtering builder
-  Shortcode Support
-  HTML Fields
-  Display Metadata
-  Advanced ordering and filtering backend
-  Quick Support
-  Debugger
-  Button - ACF 

Buy Pro Version now : [Click here](https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376)

Official Website: [geekygreenowl.com](https://geekygreenowl.com)

== Installation ==
1. Upload the plugin folder after extracting it to the `/wp-content/plugins/(the folder of the extracted plugin)` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the \'Plugins\' screen in WordPress
3. Go to Elementor page builder mode and then select our post grid widget and you will see many options when you drag and drop the widget to the live page. To see the real preview in live mode you must click apply button on top to update the layout and finally hit save in elementor and visit your page to see the changes.

== Changelog ==
= 2.0.0 =
* Initial Release
