<?php
if (!defined('ABSPATH')) {
  exit;
}

$epgae_repeatergrid->add_control(
			'image',
			[
				'label' => esc_html__( 'Placeholder Image', 'epgae' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
        'condition' => [
          'field_type' => 'image',
        ],
			]
		);

$epgae_repeatergrid->add_group_control(
    \Elementor\Group_Control_Image_Size::get_type(),
    [
        'name'      => 'image', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `image_size` and `image_custom_dimension`.
        'default'   => 'large',
        'separator' => 'none',
        'condition' => [
          'field_type' => 'image',
        ],
    ]
);

$epgae_repeatergrid->add_control(
  'field_image_url',
  [
    'label'     => esc_html__('Image Type', 'epgae'),
    'type'      => \Elementor\Controls_Manager::SELECT,
    'default'   => 'featured',
    'options'   => [
      'featured'          => esc_html__('Featured Images', 'epgae'),
      'acf_image'         => esc_html__('ACF Image', 'epgae'),
      'custom_field'      => esc_html__('Custom Field', 'epgae'),
      'woocommerce_image' => esc_html__('WooCommerce  Product Image', 'epgae'),
    ],
    'condition' => [
      'field_type' => 'image',
    ],
  ]
);


$epgae_repeatergrid->add_control(
'epgage_proversion_notice_7',
  [
    'label' => esc_html__( 'Premium Version Required', 'epgae' ),
    'type' => \Elementor\Controls_Manager::RAW_HTML,
    'raw' => __( '<p>To enable this feature premium version of post grid addon is required.</p><a target="_blank" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376"> Click here to check pro version features</a>', 'epgae' ),
    'content_classes' => 'epgae-notice',
    'condition' => [
      'field_image_url' => ['customfieldurlacfdonwload','acf_image', 'custom_field' ,'woocommerce_image'],
    ],
  ]
);
