<?php
if (!defined('ABSPATH')) {
  exit;
}
$epgae_repeatergrid->add_control(
  'field_content_type',
  [
    'label'     => esc_html__('Content type', 'epgae'),
    'type'      => \Elementor\Controls_Manager::SELECT,
    'default'   => 'editor',
    'options'   => [
      'editor'          => esc_html__('Editor Content', 'epgae'),
      'customfield_acf' => esc_html__('ACF Custom Field', 'epgae'),
      'customfield'     => esc_html__('Custom Field', 'epgae'),
    ],
    'condition' => [
      'field_type' => ['content'],
    ],
  ]
);

$epgae_repeatergrid->add_control(
'epgage_proversion_notice_5',
  [
    'label' => esc_html__( 'Premium Version Required', 'epgae' ),
    'type' => \Elementor\Controls_Manager::RAW_HTML,
    'raw' => __( '<p>To enable this feature premium version of post grid addon is required.</p><a target="_blank" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376"> Click here to check pro version features</a>', 'epgae' ),
    'content_classes' => 'epgae-notice',
    'condition' => [
      'field_content_type' => ['customfield_acf','customfield'],
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'trim_content',
  [
    'label'        => esc_html__('Enable Excerpt mode', 'epgae'),
    'type'         => \Elementor\Controls_Manager::SWITCHER,
    'label_on'     => esc_html__('Enable', 'epgae'),
    'label_off'    => esc_html__('Disbale', 'epgae'),
    'return_value' => 'yes',
    'default'      => 'yes',
    'condition'    => [
      'field_type' => ['content'],
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'excerpt_length',
  [
    'label'     => esc_html__('Word Count', 'epgae'),
    'type'      => \Elementor\Controls_Manager::NUMBER,
    'default'   => 30,
    'condition' => [
      'field_type' => ['content'],
    ],
  ]
);
