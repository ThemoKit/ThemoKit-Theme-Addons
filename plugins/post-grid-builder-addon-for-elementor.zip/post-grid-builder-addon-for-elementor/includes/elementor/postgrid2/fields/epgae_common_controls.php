<?php
if (!defined('ABSPATH')) {
  exit;
}

$epgae_repeatergrid->start_controls_tabs(
  'coretab'
);

$epgae_repeatergrid->start_controls_tab(
  'corestyling',
  [
    'label' => esc_html__( 'Styling', 'epgae' ),
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_color',
  [
    'label'     => esc_html__('Color', 'epgae'),
    'type'      => \Elementor\Controls_Manager::COLOR,
    'scheme'    => [
      'type'  => \Elementor\Scheme_Color::get_type(),
      'value' => \Elementor\Scheme_Color::COLOR_1,
    ],
    'default'   => '#54595f',
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'color: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_color_link',
  [
    'label'     => esc_html__('Link Color', 'epgae'),
    'type'      => \Elementor\Controls_Manager::COLOR,
    'scheme'    => [
      'type'  => \Elementor\Scheme_Color::get_type(),
      'value' => \Elementor\Scheme_Color::COLOR_1,
    ],
    'default'   => '#13682e',
    'condition' => [
      'field_type'=> ['metadata','button','metadatasingle'],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner a' => 'color: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_background_color',
  [
    'label'     => esc_html__('Background Color', 'epgae'),
    'type'      => \Elementor\Controls_Manager::COLOR,
    'scheme'    => [
      'type'  => \Elementor\Scheme_Color::get_type(),
      'value' => \Elementor\Scheme_Color::COLOR_1,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'background-color: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_width',
  [
    'label' => esc_html__( 'Width', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'size_units' => [ 'px', '%' ],
    'range' => [
      'px' => [
        'min' => 0,
        'max' => 1000,
        'step' => 5,
      ],
      '%' => [
        'min' => 0,
        'max' => 100,
      ],
    ],
    'default' => [
      'unit' => '%',
      'size' => 100,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'width: {{SIZE}}{{UNIT}};',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_background_z_index',
  [
    'label' => esc_html__( 'z-index', 'epgae' ),
    'type' => \Elementor\Controls_Manager::NUMBER,
    'default' => 1,
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'z-index: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_background_position',
  [
    'label' => esc_html__( 'Position', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SELECT,
    'default' => 'relative',
    'options' => [
      'relative'  => esc_html__( 'Relative', 'epgae' ),
      'absolute' => esc_html__( 'Absolute', 'epgae' ),
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'position: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_background_postion_top',
  [
    'label' => esc_html__( 'Top', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'size_units' => [ 'px', '%' ],
    'range' => [
      'px' => [
        'min' => 0,
        'max' => 1000,
        'step' => 5,
      ],
      '%' => [
        'min' => 0,
        'max' => 100,
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'top: {{SIZE}}{{UNIT}};',
    ],
    'condition' => [
      'epgae_repeater_background_position'=> 'absolute',
    ],
  ]
);
$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_background_postion_left',
  [
    'label' => esc_html__( 'Left', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'size_units' => [ 'px', '%' ],
    'range' => [
      'px' => [
        'min' => 0,
        'max' => 1000,
        'step' => 5,
      ],
      '%' => [
        'min' => 0,
        'max' => 100,
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'left: {{SIZE}}{{UNIT}};',
    ],
    'condition' => [
      'epgae_repeater_background_position'=> 'absolute',
    ],
  ]
);

$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_background_postion_bottom',
  [
    'label' => esc_html__( 'Bottom', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'size_units' => [ 'px', '%' ],
    'range' => [
      'px' => [
        'min' => 0,
        'max' => 1000,
        'step' => 5,
      ],
      '%' => [
        'min' => 0,
        'max' => 100,
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'bottom: {{SIZE}}{{UNIT}};',
    ],
    'condition' => [
      'epgae_repeater_background_position'=> 'absolute',
    ],
  ]
);
$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_background_postion_right',
  [
    'label' => esc_html__( 'Right', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'size_units' => [ 'px', '%' ],
    'range' => [
      'px' => [
        'min' => 0,
        'max' => 1000,
        'step' => 5,
      ],
      '%' => [
        'min' => 0,
        'max' => 100,
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'right: {{SIZE}}{{UNIT}};',
    ],
    'condition' => [
      'epgae_repeater_background_position'=> 'absolute',
    ],
  ]
);



$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_background_margin',
  [
    'label'      => esc_html__('Margin', 'epgae'),
    'type'       => \Elementor\Controls_Manager::DIMENSIONS,
    'size_units' => ['px', '%', 'em'],
    'selectors'  => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
    ],
  ]
);

$epgae_repeatergrid->add_responsive_control(
  'epgae_repeater_background_padding',
  [
    'label'      => esc_html__('Padding', 'epgae'),
    'type'       => \Elementor\Controls_Manager::DIMENSIONS,
    'size_units' => ['px', '%', 'em'],
    'default'    => [
      'top'      => '10',
      'right'    => '10',
      'bottom'   => '10',
      'left'     => '10',
      'isLinked' => true,
    ],
    'selectors'  => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_color_border',
  [
    'label'     => esc_html__('Border Color', 'epgae'),
    'type'      => \Elementor\Controls_Manager::COLOR,
    'scheme'    => [
      'type'  => \Elementor\Scheme_Color::get_type(),
      'value' => \Elementor\Scheme_Color::COLOR_1,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'border-color: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_border_size',
  [
    'label' => esc_html__( 'Border Style', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SELECT,
    'default' => 'solid',
    'options' => [
      'solid'  => esc_html__( 'Solid', 'epgae' ),
      'dotted' => esc_html__( 'Dotted', 'epgae' ),
      'dashed' => esc_html__( 'Dashed', 'epgae' ),
      'double' => esc_html__( 'Double', 'epgae' ),
      'groove' => esc_html__( 'Groove', 'epgae' ),
      'ridge' => esc_html__( 'Ridge', 'epgae' ),
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'border-style: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_background_border_size',
  [
    'label'      => esc_html__('Border Size', 'epgae'),
    'type'       => \Elementor\Controls_Manager::DIMENSIONS,
    'size_units' => ['px', '%', 'em'],
    'default'    => [
      'top'      => '0',
      'right'    => '0',
      'bottom'   => '0',
      'left'     => '0',
      'isLinked' => true,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_background_border_radius',
  [
    'label'      => esc_html__('Border Radius', 'epgae'),
    'type'       => \Elementor\Controls_Manager::DIMENSIONS,
    'size_units' => ['px', '%', 'em'],
    'default'    => [
      'top'      => '0',
      'right'    => '0',
      'bottom'   => '0',
      'left'     => '0',
      'isLinked' => true,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
    ],
  ]
);



$epgae_repeatergrid->add_control(
  'epgae_repeater_font_family_notice_img',
  [
    'label' => esc_html__( 'Note', 'epgae' ),
    'type' => \Elementor\Controls_Manager::RAW_HTML,
    'raw' => esc_html__( 'Use controls below to modify the border parameters of image', 'epgae' ),
    'content_classes' => 'your-class',
    'condition' => [
      'field_type'=> ['image'],
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_color_border_img',
  [
    'label'     => esc_html__('Border Color', 'epgae'),
    'type'      => \Elementor\Controls_Manager::COLOR,
    'scheme'    => [
      'type'  => \Elementor\Scheme_Color::get_type(),
      'value' => \Elementor\Scheme_Color::COLOR_1,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner img' => 'border-color: {{VALUE}}',
    ],
    'condition' => [
      'field_type'=> ['image'],
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_border_size_img',
  [
    'label' => esc_html__( 'Border Style', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SELECT,
    'default' => 'solid',
    'options' => [
      'solid'  => esc_html__( 'Solid', 'epgae' ),
      'dotted' => esc_html__( 'Dotted', 'epgae' ),
      'dashed' => esc_html__( 'Dashed', 'epgae' ),
      'double' => esc_html__( 'Double', 'epgae' ),
      'groove' => esc_html__( 'Groove', 'epgae' ),
      'ridge' => esc_html__( 'Ridge', 'epgae' ),
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner img' => 'border-style: {{VALUE}}',
    ],
    'condition' => [
      'field_type'=> ['image'],
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_background_border_size_img',
  [
    'label'      => esc_html__('Border Size', 'epgae'),
    'type'       => \Elementor\Controls_Manager::DIMENSIONS,
    'size_units' => ['px', '%', 'em'],
    'default'    => [
      'top'      => '0',
      'right'    => '0',
      'bottom'   => '0',
      'left'     => '0',
      'isLinked' => true,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner img' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
    ],
    'condition' => [
      'field_type'=> ['image'],
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_repeater_background_border_radius_img',
  [
    'label'      => esc_html__('Border Radius', 'epgae'),
    'type'       => \Elementor\Controls_Manager::DIMENSIONS,
    'size_units' => ['px', '%', 'em'],
    'default'    => [
      'top'      => '0',
      'right'    => '0',
      'bottom'   => '0',
      'left'     => '0',
      'isLinked' => true,
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}} .epgae-repeater-container-inner img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
    ],
    'condition' => [
      'field_type'=> ['image'],
    ],
  ]
);


$epgae_repeatergrid->add_control(
  'epgae_repeater_alignment',
  [
    'label'   => esc_html__('Text Alignment', 'epgae'),
    'type'    => \Elementor\Controls_Manager::CHOOSE,
    'options' => [
      'left'   => [
        'title' => esc_html__('Left', 'epgae'),
        'icon'  => 'fa fa-align-left',
      ],
      'center' => [
        'title' => esc_html__('Center', 'epgae'),
        'icon'  => 'fa fa-align-center',
      ],
      'right'  => [
        'title' => esc_html__('Right', 'epgae'),
        'icon'  => 'fa fa-align-right',
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'text-align: {{VALUE}}',
    ],
    'default' => 'center',
    'toggle'  => true,
  ]
);



$epgae_repeatergrid->add_control(
  'epgae_repeater_alignment_content',
  [
    'label'   => esc_html__('Content Alignment', 'epgae'),
    'type'    => \Elementor\Controls_Manager::CHOOSE,
    'options' => [
      'left'   => [
        'flex-start' => esc_html__('Left', 'epgae'),
        'icon'  => 'fa fa-align-left',
      ],
      'center' => [
        'title' => esc_html__('Center', 'epgae'),
        'icon'  => 'fa fa-align-center',
      ],
      'flex-end'  => [
        'title' => esc_html__('Right', 'epgae'),
        'icon'  => 'fa fa-align-right',
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'justify-content: {{VALUE}}',
    ],
    'default' => 'center',
    'toggle'  => true,
  ]
);

$epgae_repeatergrid->end_controls_tab();

$epgae_repeatergrid->start_controls_tab(
  'core_typo',
  [
    'label' => esc_html__( 'Typography', 'epgae' ),
  ]
);


$epgae_repeatergrid->add_control(
  'epgae_repeater_more_options',
  [
    'label' => esc_html__( 'Typography', 'epgae' ),
    'type' => \Elementor\Controls_Manager::HEADING,
    'separator' => 'after',
  ]
);


$default = \Elementor\Core\Settings\Manager::get_settings_managers( 'general' )->get_model()->get_settings( 'elementor_default_generic_fonts' );


$epgae_repeatergrid->add_control(
  'epgae_repeater_font_family_notice',
  [
    'label' => esc_html__( 'Note', 'epgae' ),
    'type' => \Elementor\Controls_Manager::RAW_HTML,
    'raw' => esc_html__( 'The font family selection only works in preview and live mode. This is not a bug. Elementor Limitation.', 'epgae' ),
    'content_classes' => 'your-class',
  ]
);


$epgae_repeatergrid->add_control(
  'epgae_repeater_font_family',
  [
    'label' => esc_html__( 'Font Family', 'epgae' ),
    'type' => \Elementor\Controls_Manager::FONT,
    'default' => "'Open Sans', sans-serif",
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'font-family: "{{VALUE}}", '.$default.'',
    ],
  ]
);


$epgae_repeatergrid->add_responsive_control(
  'epgae_font_size',
  [
    'label' => esc_html_x( 'Size', 'Typography Control', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'size_units' => [ 'px', 'em', 'rem', 'vw' ],
    'range' => [
      'px' => [
        'min' => 1,
        'max' => 200,
      ],
      'vw' => [
        'min' => 0.1,
        'max' => 10,
        'step' => 0.1,
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'font-size: {{SIZE}}{{UNIT}}',
    ],
  ]
);

foreach ( array_merge( [ 'normal', 'bold' ], range( 100, 900, 100 ) ) as $weight ) {
  $typo_weight_options[ $weight ] = ucfirst( $weight );
}

$epgae_repeatergrid->add_control(
  'epgae_font_weight',
  [
    'label' => esc_html_x( 'Weight', 'Typography Control', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SELECT,
    'default' => '',
    'options' => $typo_weight_options,
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'font-weight: {{VALUE}}',
    ],
  ]
);


$epgae_repeatergrid->add_control(
  'epgae_font_transform',
  [
    'label' => esc_html_x( 'Transform', 'Typography Control', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SELECT,
    'default' => '',
    'options' => [
      '' => esc_html__( 'Default', 'epgae' ),
      'uppercase' => esc_html_x( 'Uppercase', 'Typography Control', 'epgae' ),
      'lowercase' => esc_html_x( 'Lowercase', 'Typography Control', 'epgae' ),
      'capitalize' => esc_html_x( 'Capitalize', 'Typography Control', 'epgae' ),
      'none' => esc_html_x( 'Normal', 'Typography Control', 'epgae' ),
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'text-transform: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_font_style',
  [
    'label' => esc_html_x( 'Style', 'Typography Control', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SELECT,
    'default' => '',
    'options' => [
      '' => esc_html__( 'Default', 'epgae' ),
      'normal' => esc_html_x( 'Normal', 'Typography Control', 'epgae' ),
      'italic' => esc_html_x( 'Italic', 'Typography Control', 'epgae' ),
      'oblique' => esc_html_x( 'Oblique', 'Typography Control', 'epgae' ),
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'font-style: {{VALUE}}',
    ],
  ]
);


$epgae_repeatergrid->add_control(
  'epgae_font_decoration',
  [
    'label' => esc_html_x( 'Decoration', 'Typography Control', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SELECT,
    'default' => 'None',
    'options' => [
      '' => esc_html__( 'Default', 'epgae' ),
      'underline' => esc_html_x( 'Underline', 'Typography Control', 'epgae' ),
      'overline' => esc_html_x( 'Overline', 'Typography Control', 'epgae' ),
      'line-through' => esc_html_x( 'Line Through', 'Typography Control', 'epgae' ),
      'none' => esc_html_x( 'None', 'Typography Control', 'epgae' ),
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'text-decoration: {{VALUE}}',
    ],
  ]
);

$epgae_repeatergrid->add_responsive_control(
  'epgae_font_lineheight',
  [
    'label' => esc_html_x( 'Line-Height', 'Typography Control', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'desktop_default' => [
      'unit' => 'em',
    ],
    'tablet_default' => [
      'unit' => 'em',
    ],
    'mobile_default' => [
      'unit' => 'em',
    ],
    'range' => [
      'px' => [
        'min' => 1,
      ],
    ],
    'size_units' => [ 'px', 'em' ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'line-height: {{SIZE}}{{UNIT}}',
    ],
  ]
);


$epgae_repeatergrid->add_responsive_control(
  'epgae_font_letterspacing',
  [
    'label' => esc_html_x( 'Letter Spacing', 'Typography Control', 'epgae' ),
    'type' => \Elementor\Controls_Manager::SLIDER,
    'range' => [
      'px' => [
        'min' => -5,
        'max' => 10,
        'step' => 0.1,
      ],
    ],
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}' => 'letter-spacing: {{SIZE}}{{UNIT}}',
    ],
  ]
);


$epgae_repeatergrid->end_controls_tab();

$epgae_repeatergrid->start_controls_tab(
  'core_anim',
  [
    'label' => esc_html__( 'Animations', 'epgae' ),
  ]
);




$epgae_repeatergrid->add_control(
  'more_options_anim',
  [
    'label' => esc_html__( 'Animations', 'epgae' ),
    'type' => \Elementor\Controls_Manager::HEADING,
    'separator' => 'before',
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_title_entrance_animation',
  [
    'label'        => esc_html__('Entrance Animation', 'epgae'),
    'type'         => \Elementor\Controls_Manager::ANIMATION,
    'prefix_class' => 'animated ',
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'epgae_title_hover_animation',
  [
    'label'        => esc_html__('Title Hover Animation', 'epgae'),
    'type'         => \Elementor\Controls_Manager::HOVER_ANIMATION,
    'prefix_class' => 'elementor-animation-',
    'selectors' => [
      '{{WRAPPER}} {{CURRENT_ITEM}}',
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'field_class',
  [
    'label'   => esc_html__('Class', 'epgae'),
    'type'    => \Elementor\Controls_Manager::TEXT,
    'default' => esc_html__('epgae-class-css', 'epgae'),
  ]
);

$epgae_repeatergrid->add_control(
  'field_id',
  [
    'label'   => esc_html__('ID', 'epgae'),
    'type'    => \Elementor\Controls_Manager::TEXT,
    'default' => esc_html__('epgae-class-css', 'epgae'),
  ]
);
$epgae_repeatergrid->end_controls_tab();
$epgae_repeatergrid->end_controls_tabs();
