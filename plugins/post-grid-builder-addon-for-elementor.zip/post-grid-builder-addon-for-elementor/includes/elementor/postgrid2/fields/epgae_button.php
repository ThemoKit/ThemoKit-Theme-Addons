<?php
if (!defined('ABSPATH')) {
  exit;
}

$epgae_repeatergrid->add_control(
  'button_field_type',
  [
    'label'     => esc_html__('Button Field Type', 'epgae'),
    'type'      => \Elementor\Controls_Manager::SELECT,
    'default'   => 'linktopost',
    'options'   => [
      'linktopost'        => esc_html__('Link to post', 'epgae'),
      'customfieldurlacfdonwload' => esc_html__('ACF File | On click Download file', 'epgae'),
      'customfieldurlacf' => esc_html__('ACF | Link to Custom field url', 'epgae'),
      'woocommercecart'   => esc_html__('WooCommerce add to cart button','epgae'),
    ],
    'condition' => [
      'field_type' => 'button',
    ],
  ]
);

$epgae_repeatergrid->add_control(
'epgage_proversion_notice_6',
  [
    'label' => esc_html__( 'Premium Version Required', 'epgae' ),
    'type' => \Elementor\Controls_Manager::RAW_HTML,
    'raw' => __( '<p>To enable this feature premium version of post grid addon is required.</p><a target="_blank" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376"> Click here to check pro version features</a>', 'epgae' ),
    'content_classes' => 'epgae-notice',
    'condition' => [
      'button_field_type' => ['customfieldurlacfdonwload','customfieldurlacf', 'woocommercecart' ],
    ],
  ]
);

$epgae_repeatergrid->add_control(
  'button_field_type_text',
  [
    'label'     => esc_html__('Button Text', 'epgae'),
    'type'      => \Elementor\Controls_Manager::TEXT,
    'default'   => esc_html__('Read More', 'epgae'),
    'condition' => [
      'field_type' => 'button',
    ],
  ]
);
