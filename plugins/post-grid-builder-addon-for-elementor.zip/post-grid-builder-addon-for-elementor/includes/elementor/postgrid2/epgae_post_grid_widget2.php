<?php
/**
 *
 * @since 1.0.0
 */
namespace Elementor;

class Elementor_Epgae_Post_Grid2 extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'epgae_post_grid2';
    }

    /**
     * Get widget title.
     *
     * Retrieve Geekygreenowl widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return esc_html__('Post Grid 2 (new)', 'epgae');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Geekygreenowl widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'fa fa-braille';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Geekygreenowl widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['epgae-category'];
    }

    /**
     * Get list of custom postypes.
     *
     * Retrieve the list of categories the Geekygreenowl widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array custom post type list.
     */
    public function epgae_get_data()
    {
        $epgae_data = new \EPGAECORENS\Epgae();
        return $epgae_data;
    }


    /**
     * Register Geekygreenowl widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {

        $epgae_data                    = $this->epgae_get_data();
        $epgae_custompostype_array     = $epgae_data->epgae_list_of_posttypes();
        $epgae_taxonomy_array          = $epgae_data->epgae_list_of_terms();
        $epgae_taxonomy_tag_array      = $epgae_data->epgae_list_of_tags();
        $epgae_taxonomy_repeat_tax     = $epgae_data->epgae_list_of_taxonomy_repeater_field();
        $epgae_taxonomy_repeat_tax[''] = 'None';
        $epgae_taxonomy_repeat_term    = $epgae_data->epgae_list_of_terms_repeater_field();
        $epgae_post_status_array       = $epgae_data->epgae_list_of_post_status();
        $epgae_image_size_list         = $epgae_data->epgae_ren_func_array_of_image_size();
        $epgae_taxonomy_tax_mata       = $epgae_data->epgae_list_of_taxonomy_repeater_field();

        $this->start_controls_section(
            'epgae_grid_design',
            [
                'label' => esc_html__('Grid Maker', 'epgae'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'epgae_heading_grid_designer',
            [
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => esc_html__('Use sortable drag and drop grid maker to create/arrange the layout for your grid.', 'epgae'),
                'content_classes' => 'epgae-descriptor',
            ]
        );

        $this->add_responsive_control(
            'epgae_layout',
            [
                'label'     => esc_html__('Column Count', 'epgae'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'flex',
                'options'   => [
                    'flex' => esc_html__('1 Colum Layout', 'epgae'),
                    'grid' => esc_html__('2 Colum Layout', 'epgae'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-card-design-mul' => 'display: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'epgae_width_control',
            [
                'label'      => esc_html__('Column 1 Width', 'epgae'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['fr'],
                'range'      => [
                    'fr' => [
                        'min'  => 0,
                        'max'  => 5,
                        'step' => 0.1,
                    ],
                ],
                'default'    => [
                    'unit' => 'fr',
                    'size' => 1,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .epgae-card-design-mul' => 'grid-template-columns: {{SIZE}}{{UNIT}} 1fr;',
                ],
                'condition'  => [
                    'epgae_layout' => ['grid'],
                ],
            ]
        );

        $this->add_control(
            'epgae_align_content_grid_ver',
            [
                'label'     => esc_html__('Vertical Align Content', 'epgae'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::SELECT,
                    'value' => \Elementor\Controls_Manager::SELECT,
                ],

                'options'   => [
                    'flex-start' => esc_html__('Top', 'epgae'),
                    'Center'     => esc_html__('Center', 'epgae'),
                    'flex-end'   => esc_html__('Bottom', 'epgae'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-card-design-mul' => 'align-items: {{VALUE}}',
                ],
                'default'   => 'flex-start',
                'condition' => [
                    'epgae_layout' => ['grid'],
                ],
            ]
        );

        $epgae_repeatergrid = new \Elementor\Repeater();

        $epgae_repeatergrid->add_responsive_control(
            'epgae_layout_inner',
            [
                'label'       => esc_html__('Inner Column Width', 'epgae'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => '100%',
                'options'     => [
                    '100%' => esc_html__('100%', 'epgae'),
                    '75%'  => esc_html__('75%', 'epgae'),
                    '50%'  => esc_html__('50%', 'epgae'),
                    '25%'  => esc_html__('25%', 'epgae'),
                ],
                'description' => __('Setting 50%/50% for 2 adjacent field type will put the content in same row. 25%-75% Supported', 'epgae'),
                'selectors'   => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'flex-basis: {{VALUE}}',
                ],
            ]
        );

        $epgae_repeatergrid->add_control(
            'field_type',
            [
                'label'   => esc_html__('Field Type', 'epgae'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'title',
                'options' => [
                    'title'          => esc_html__('Title', 'epgae'),
                    'content'        => esc_html__('Content', 'epgae'),
                    'button'         => esc_html__('Button', 'epgae'),
                    'image'          => esc_html__('Image', 'epgae'),
                ],
            ]
        );

        $epgae_repeatergrid->add_control(
            'epgae_content_after_placer',
            [
                'label'       => esc_html__('Content After', 'epgae'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'rows'        => 2,
                'placeholder' => esc_html__('Adds the content after field type', 'epgae'),
                'condition'   => [
                    'field_type' => ['content', 'wooprice', 'shortcode', 'metadatasingle'],
                ],
            ]
        );
        //version 1.1.0 Update for content
        // Allows text content to be placed befor content
        $epgae_repeatergrid->add_control(
            'epgae_content_before_placer',
            [
                'label'       => esc_html__('Content Before', 'epgae'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'rows'        => 2,
                'placeholder' => esc_html__('Adds the content before field type', 'epgae'),
                'condition'   => [
                    'field_type' => ['content', 'wooprice', 'shortcode', 'metadatasingle'],
                ],
            ]
        );

        require plugin_dir_path(__FILE__) . 'fields/epgae_button.php';
        require plugin_dir_path(__FILE__) . 'fields/epgae_content.php';
        require plugin_dir_path(__FILE__) . 'fields/epgae_image.php';
        require plugin_dir_path(__FILE__) . 'fields/epgae_common_controls.php';

        $this->start_controls_tabs('epgae_columntabs');

        $this->start_controls_tab(
            'epgae_column_1',
            [
                'label' => esc_html__('Column 1 Content', 'epgae'),
            ]
        );

        $this->add_control(
            'epgae_field_gen',
            [
                'label'       => esc_html__('Grid Layout', 'epgae'),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $epgae_repeatergrid->get_controls(),
                'default'     => [
                    [
                        'field_type' => 'title',
                    ],
                    [
                        'field_type' => 'content',
                    ],
                ],
                'title_field' => '{{{ field_type }}}',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'epgae_column_2',
            [
                'label'     => esc_html__('Column 2 Content', 'epgae'),
                'condition' => [
                    'epgae_layout' => ['grid'],
                ],
            ]
        );

        $this->add_control(
            'epgae_field_gen2',
            [
                'label'       => esc_html__('Grid Layout2', 'epgae'),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $epgae_repeatergrid->get_controls(),
                'default'     => [
                    [
                        'field_type' => 'title',
                    ],
                    [
                        'field_type' => 'content',
                    ],
                ],
                'title_field' => '{{{ field_type }}}',
            ]
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'epgae_grid_sort_and_filter',
            [
                'label' => esc_html__('Sort / Filter Design', 'epgae'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'epgae_enable_sorter',
            [
                'label'        => esc_html__('Enable Frontend Sorting and Filtering', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'epgae'),
                'label_off'    => esc_html__('No', 'epgae'),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->add_control(
		  	'epgage_proversion_notice_1',
		    	[
    				'label' => esc_html__( 'Premium Version Required', 'epgae' ),
    				'type' => \Elementor\Controls_Manager::RAW_HTML,
    				'raw' => __( '<p>To enable this feature premium version of post grid addon is required.</p><a target="_blank" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376"> Click here to check pro version features</a>', 'epgae' ),
    				'content_classes' => 'epgae-notice',
            'condition' => [
              'epgae_enable_sorter' => 'yes',
            ],
		    	]
		    );


        $this->end_controls_section();

        $this->start_controls_section(
            'epgae_grid_designer',
            [
                'label' => esc_html__('Grid Designer', 'epgae'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->start_controls_tabs(
            'epgae_responsive_controller'
        );

        $this->start_controls_tab(
            'epgae_responsive_controller_desktop',
            [
                'label' => esc_html__('Desktop', 'epgae'),
            ]
        );

        $this->add_control(
            'epgae_grid_column_dektop',
            [
                'label'   => esc_html__('Column count in Desktop Devices', 'epgae'),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 12,
                'step'    => 1,
                'default' => 4,
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'epgae_responsive_controller_tablet',
            [
                'label' => esc_html__('Tablets', 'epgae'),
            ]
        );

        $this->add_control(
            'epgae_grid_column_tablet',
            [
                'label'   => esc_html__('Column count in Tablet Devices', 'epgae'),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 12,
                'step'    => 1,
                'default' => 3,
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'epgae_responsive_controller_mobile',
            [
                'label' => esc_html__('Mobile', 'epgae'),
            ]
        );

        $this->add_control(
            'epgae_grid_column_mobile',
            [
                'label'   => esc_html__('Column count in Mobile Devices', 'epgae'),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 12,
                'step'    => 1,
                'default' => 1,
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'epgae_responsive_controller_hr',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'make_block_clickable',
            [
                'label'        => esc_html__('Make grid clickable', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'epgae'),
                'label_off'    => esc_html__('No', 'epgae'),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'epgae_align_content_grid',
            [
                'label'     => esc_html__('Align Content', 'epgae'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::SELECT,
                    'value' => \Elementor\Controls_Manager::SELECT,
                ],

                'options'   => [
                    'flex-start' => esc_html__('Top', 'epgae'),
                    'Center'     => esc_html__('Center', 'epgae'),
                    'flex-end'   => esc_html__('Bottom', 'epgae'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-card-design' => 'align-content: {{VALUE}}',
                ],
                'default'   => 'flex-start',

            ]
        );

        $this->add_control(
            'epgae_grid_column_gap',
            [
                'label'     => esc_html__('Column Gap', 'epgae'),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'value' => \Elementor\Controls_Manager::NUMBER,
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-row' => 'grid-column-gap: {{VALUE}}px',
                ],
                'default'   => 10,

            ]
        );

        $this->add_control(
            'epgae_grid_row_gap',
            [
                'label'     => esc_html__('Row Gap', 'epgae'),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'value' => \Elementor\Controls_Manager::NUMBER,
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-row' => 'grid-row-gap: {{VALUE}}px',
                ],
                'default'   => 10,

            ]
        );

        $this->add_control(
            'epgae_grid_enable_min_hight',
            [
                'label'     => esc_html__('Grid minimum height (px)', 'epgae'),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'value' => \Elementor\Controls_Manager::NUMBER,
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-card-design' => 'min-height: {{VALUE}}px',
                ],
                'default'   => 0,

            ]
        );

        $this->add_control(
            'epgae_features_hr',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'epgae_background_and_border_heading',
            [
                'label' => esc_html__('Background and Border', 'epgae'),
                'type'  => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'epgae_heading_back_in_out',
            [
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => esc_html__('Each individual grid have an outer and inner container.', 'epgae'),
                'content_classes' => 'epgae-descriptor',
            ]
        );

        $this->start_controls_tabs(
            'epgae_background_and_border_heading_tabs'
        );

        $this->start_controls_tab(
            'epgae_innergrid_tab',
            [
                'label' => esc_html__('Inner Grid', 'epgae'),
            ]
        );

        $this->add_control(
            'epgae_make_featured_image_as_background',
            [
                'label'        => esc_html__('Make Featured image as background', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'epgae'),
                'label_off'    => esc_html__('No', 'epgae'),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'epgae_b_top_grad',
            [
                'label'     => esc_html__('Top gradient', 'epgae'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'default'   => 'rgba(0,0,0,0)',
                'condition' => [
                    'epgae_make_featured_image_as_background' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'epgae_b_bottom_grad',
            [
                'label'     => esc_html__('Bottom gradient', 'epgae'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'default'   => 'rgba(192,252,53,0.88)',
                'condition' => [
                    'epgae_make_featured_image_as_background' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'epgae_b_cover',
            [
                'label'     => esc_html__('Background Size', 'epgae'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'cover',
                'options'   => [
                    'auto'    => esc_html__('Auto', 'epgae'),
                    'length'  => esc_html__('Length', 'epgae'),
                    'cover'   => esc_html__('Cover', 'epgae'),
                    'contain' => esc_html__('Contain', 'epgae'),
                    'initial' => esc_html__('Initial', 'epgae'),
                    'inherit' => esc_html__('Inherit', 'epgae'),
                ],
                'condition' => [
                    'epgae_make_featured_image_as_background' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'epgae_b_position',
            [
                'label'     => esc_html__('Background Position', 'epgae'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'center center',
                'options'   => [
                    'left top'        => esc_html__('left top', 'epgae'),
                    'left center'     => esc_html__('left center', 'epgae'),
                    'left bottom'     => esc_html__('left bottom', 'epgae'),
                    'right top'       => esc_html__('right top', 'epgae'),
                    'right center'    => esc_html__('right center', 'epgae'),
                    'right bottom'    => esc_html__('right bottom', 'epgae'),
                    'center top'      => esc_html__('center top', 'epgae'),
                    'center center'   => esc_html__('center center', 'epgae'),
                    'center bottom  ' => esc_html__('center bottom  ', 'epgae'),
                ],
                'condition' => [
                    'epgae_make_featured_image_as_background' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'epgae_b_repeat',
            [
                'label'     => esc_html__('Background Size', 'epgae'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'no-repeat',
                'options'   => [
                    'repeat'    => esc_html__('Repeat', 'epgae'),
                    'repeat-x'  => esc_html__('Repeat-x', 'epgae'),
                    'repeat-y'  => esc_html__('Repeat-y', 'epgae'),
                    'no-repeat' => esc_html__('No-repeat', 'epgae'),
                    'initial'   => esc_html__('Initial', 'epgae'),
                    'inherit'   => esc_html__('Inherit', 'epgae'),
                ],
                'condition' => [
                    'epgae_make_featured_image_as_background' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'epgae_back_featured_image_size',
            [
                'label'     => esc_html__('Select Images Size', 'epgae'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => $epgae_image_size_list,
                'condition' => [
                    'epgae_make_featured_image_as_background' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'Inner_grid_Designer',
            [
                'label' => esc_html__('Background For Grid', 'epgae'),
                'type'  => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'epgae_grid_background',
                'label'    => esc_html__('Grid Background', 'epgae'),
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .epgae-card-design',
            ]
        );

        $this->add_control(
            'epgae_grid_box_border_radius',
            [
                'label'     => esc_html__('Grid border radius (px)', 'epgae'),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'value' => \Elementor\Controls_Manager::NUMBER,
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-card-design' => 'border-radius: {{VALUE}}px',
                ],
                'default'   => 0,

            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'epgae_border_grid_inner',
                'label'    => esc_html__('Grid Box Border', 'epgae'),
                'selector' => '{{WRAPPER}} .epgae-card-design',
            ]
        );

        $this->add_control(
            'epgae_grid_block_padding_full',
            [
                'label'      => esc_html__('Grid padding', 'epgae'),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '0',
                    'left'     => '0',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .epgae-card-design' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'epgae_outgrid_tab',
            [
                'label' => esc_html__('Outer Grid', 'epgae'),
            ]
        );

        $this->add_control(
            'Outer_grid_Designer',
            [
                'label' => esc_html__('Background For Outer Grid', 'epgae'),
                'type'  => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'epgae_grid_background_outer',
                'label'    => esc_html__('Outer Grid Background', 'epgae'),
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .epgae-card-design-outer',
            ]
        );

        $this->add_control(
            'epgae_grid_box_border_radius_outer',
            [
                'label'     => esc_html__('Outer Grid border radius (px)', 'epgae'),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'value' => \Elementor\Controls_Manager::NUMBER,
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-card-design-outer' => 'border-radius: {{VALUE}}px',
                ],
                'default'   => 0,

            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'epgae_border_grid_outer',
                'label'    => esc_html__('Grid Box Border', 'epgae'),
                'selector' => '{{WRAPPER}} .epgae-card-design-outer',
            ]
        );

        $this->add_control(
            'epgae_grid_block_padding_full_outer',
            [
                'label'      => esc_html__('Outer Grid padding', 'epgae'),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '0',
                    'left'     => '0',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .epgae-card-design-outer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'epgae_pagination_customize',
            [
                'label' => esc_html__('Pagination Designer', 'epgae'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_count',
            [
                'label'   => esc_html__('Posts per page', 'epgae'),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'default' => '',
            ]
        );

        $this->add_control(
            'post_enable_pagination',
            [
                'label'        => esc_html__('Disable Pagination', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'epgae'),
                'label_off'    => esc_html__('No', 'epgae'),
                'return_value' => 'true',
                'default'      => 'true',
            ]
        );

        $this->add_control(
            'post_enable_pagination_fixed',
            [
                'label'        => esc_html__('Display only fixed Post Count', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'epgae'),
                'label_off'    => esc_html__('No', 'epgae'),
                'return_value' => 'true',
                'default'      => '',
            ]
        );

        $this->add_control(
            'epgae_enable_pagination_on_top',
            [
                'label'        => esc_html__('Enable pagination on Top', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Enable', 'epgae'),
                'label_off'    => esc_html__('Disable', 'epgae'),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'epgae_enable_pagination_on_bottom',
            [
                'label'        => esc_html__('Enable pagination on Bottom', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Enable', 'epgae'),
                'label_off'    => esc_html__('Disable', 'epgae'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
        $this->add_control(
            'hrmaincontrol',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'pagination_typography',
                'label'    => esc_html__('Pagination Typography', 'epgae'),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .epgae-pagination',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'epgae_paggination_background',
                'label'    => esc_html__('Background', 'epgae'),
                'types'    => ['classic', 'gradient', 'video'],
                'selector' => '{{WRAPPER}} .epgae-pagination',
            ]
        );

        $this->add_control(
            'paggination_text_color',
            [
                'label'     => esc_html__('Pagination Text Color', 'epgae'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'default'   => '#5b5b5b',
                'selectors' => [
                    '{{WRAPPER}} .epgae-pagination .page-numbers' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'paggination_background_color_pagenumber',
            [
                'label'     => esc_html__('Pagination background color for page numbers', 'epgae'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .epgae-pagination .page-numbers' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'hractive',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'paggination_background_color_active',
            [
                'label'     => esc_html__('Pagination background color for active page', 'epgae'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'default'   => '#54595f',
                'selectors' => [
                    '{{WRAPPER}} .epgae-pagination .current ' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'paggination_text_color_active',
            [
                'label'     => esc_html__('Pagination text Color For active page', 'epgae'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .epgae-pagination .current' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'hrbackcol',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'epgae_pagination_margin',
            [
                'label'      => esc_html__('Pagination Block Margin', 'epgae'),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .epgae-pagination' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'epgae_pagination_padding',
            [
                'label'      => esc_html__('Pagination Block Padding', 'epgae'),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default'    => [
                    'top'      => '10',
                    'right'    => '10',
                    'bottom'   => '10',
                    'left'     => '10',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .epgae-pagination' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'hrpagenum',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'epgae_pagination_margin_pagenumber',
            [
                'label'      => esc_html__('Page number Margin', 'epgae'),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default'    => [
                    'top'      => '2',
                    'right'    => '20',
                    'bottom'   => '2',
                    'left'     => '20',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .epgae-pagination .page-numbers' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'epgae_pagination_padding_pagenumber',
            [
                'label'      => esc_html__('Page number Padding', 'epgae'),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default'    => [
                    'top'      => '5',
                    'right'    => '20',
                    'bottom'   => '5',
                    'left'     => '20',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .epgae-pagination .page-numbers' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'paggination_numbers_border_border_radius',
            [
                'label'     => esc_html__('Pagination number border radius', 'epgae'),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'scheme'    => [
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'value' => \Elementor\Controls_Manager::NUMBER,
                ],
                'selectors' => [
                    '{{WRAPPER}} .epgae-pagination .page-numbers' => 'border-radius: {{VALUE}}px',
                ],
                'default'   => 0,

            ]
        );

        $this->end_controls_section();

        //selection of posts
        $this->start_controls_section(
            'content_section_epgae_content',
            [
                'label' => esc_html__('Type, Order and Filtering', 'epgae'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'posttype',
            [
                'label'    => esc_html__('Post Type', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT2,
                'default'  => 'post',
                'multiple' => true,
                'options'  => $epgae_custompostype_array
                ,
            ]
        );

        $this->add_control(
            'post_type_status',
            [
                'label'    => esc_html__('Post Status', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'default'  => 'publish',
                'options'  => $epgae_post_status_array,
            ]
        );

        $this->add_control(
            'password_protected',
            [
                'label'        => esc_html__('Show password Protected Posts', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'epgae'),
                'label_off'    => esc_html__('Hide', 'epgae'),
                'return_value' => 'true',
                'default'      => '',
            ]
        );

        $this->add_control(
            'order',
            [
                'label'    => esc_html__('Order', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT,
                'default'  => 'ASC',
                'multiple' => true,
                'options'  => [
                    'ASC'  => esc_html__('Ascending ', 'epgae'),
                    'DESC' => esc_html__('Descending ', 'epgae'),
                ],
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'    => esc_html__('Order By', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT,
                'multiple' => true,
                'default'  => 'none',
                'options'  => [
                    'none'           => esc_html__('No Order', 'epgae'),
                    'date'           => esc_html__('Date', 'epgae'),
                    'ID'             => esc_html__('Order by Post ID', 'epgae'),
                    'author'         => esc_html__('Order by Author', 'epgae'),
                    'title'          => esc_html__('Order by Title', 'epgae'),
                    'type'           => esc_html__('Order by Post type', 'epgae'),
                    'modified'       => esc_html__('Order by Last Modified', 'epgae'),
                    'parent'         => esc_html__('Order by Post/Page parent', 'epgae'),
                    'rand'           => esc_html__('Random', 'epgae'),
                    'comment_count'  => esc_html__('Order by Comment Count', 'epgae'),
                    'relevance'      => esc_html__('By relevence', 'epgae'),
                    'menu_order'     => esc_html__('Order by Page Order', 'epgae'),
                    'meta_value'     => esc_html__('Order by Meta Value', 'epgae'),
                    'meta_value_num' => esc_html__('Order by Numeric Meta Value ', 'epgae'),
                ],
            ]
        );

        $this->add_control(
        'epgage_proversion_notice_2',
          [
            'label' => esc_html__( 'Premium Version Required', 'epgae' ),
            'type' => \Elementor\Controls_Manager::RAW_HTML,
            'raw' => __( '<p>To enable this feature premium version of post grid addon is required.</p><a target="_blank" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376"> Click here to check pro version features</a>', 'epgae' ),
            'content_classes' => 'epgae-notice',
            'condition' => [
              'orderby' => ['menu_order','meta_value','meta_value_num'],
            ],
          ]
        );

        $this->add_control(
            'oneauthor',
            [
                'label'       => esc_html__('Show Posts for specific Authors', 'epgae'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__('This can be used to show specific posts from an author or multiple authors. Add comma seperated author IDs to display posts.
                                                To exclude any specific author put a negative sign infront of the id', 'epgae'),
                'language'    => 'text',
            ]
        );

        $this->add_control(
            'epgae_post_grid_includer',
            [
                'label'        => __('Enable ACF Relation', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __('Yes', 'epgae'),
                'label_off'    => __('No', 'epgae'),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->add_control(
        'epgage_proversion_notice_3',
          [
            'label' => esc_html__( 'Premium Version Required', 'epgae' ),
            'type' => \Elementor\Controls_Manager::RAW_HTML,
            'raw' => __( '<p>To enable this feature premium version of post grid addon is required.</p><a target="_blank" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376"> Click here to check pro version features</a>', 'epgae' ),
            'content_classes' => 'epgae-notice',
            'condition' => [
              'epgae_post_grid_includer' => ['yes'],
            ],
          ]
        );

        $this->add_control(
            'epgae_cat_terms_select',
            [
                'label'    => esc_html__('Select Category Term', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options'  => $epgae_taxonomy_array,
            ]
        );
        $this->add_control(
            'epgae_exclude_terms',
            [
                'label'    => esc_html__('Exclude Category Term', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options'  => $epgae_taxonomy_array,
            ]
        );

        $this->add_control(
            'epgae_tag_terms_select',
            [
                'label'    => esc_html__('Select Tag Term', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options'  => $epgae_taxonomy_tag_array,
            ]
        );
        $this->add_control(
            'epgae_exclude__tag_terms',
            [
                'label'    => esc_html__('Exclude Tag Term', 'epgae'),
                'type'     => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options'  => $epgae_taxonomy_tag_array,
            ]
        );

        $this->add_control(
            'enable_tax_query',
            [
                'label'        => esc_html__('Enable Tax Query', 'epgae'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'epgae'),
                'label_off'    => esc_html__('No', 'epgae'),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
        'epgage_proversion_notice_4',
          [
            'label' => esc_html__( 'Premium Version Required', 'epgae' ),
            'type' => \Elementor\Controls_Manager::RAW_HTML,
            'raw' => __( '<p>To enable this feature premium version of post grid addon is required.</p><a target="_blank" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376"> Click here to check pro version features</a>', 'epgae' ),
            'content_classes' => 'epgae-notice',
            'condition' => [
              'enable_tax_query' => ['yes'],
            ],
          ]
        );

        $this->end_controls_section();

    }

    /**
     * Render Geekygreenowl widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {

        $settings        = $this->get_settings_for_display();
        $epgae_user_data = new \EPGAECORENS\Epgae();

        //Post Type
        $epgae_u_posttype         = $settings['posttype'];
        $epgae_u_poststatus       = $settings['post_type_status'];
        $epgae_u_postpagingenable = $settings['post_enable_pagination'];
        $epgae_u_paginate_num     = $settings['post_count'];
        $epgae_u_password         = $settings['password_protected'];

        //Ordering
        $epgae_u_order    = $settings['order'];
        $epgae_u_orderby  = $settings['orderby'];

        //Author
        $epgae_u_authorid = $settings['oneauthor'];

        //Category Arg Creator
        $epgae_u_catid        = $settings['epgae_cat_terms_select'];
        $epgae_u_catidexclude = $settings['epgae_exclude_terms'];
        $epgae_u_catid        = $epgae_user_data->epgae_catergory_id_generator($epgae_u_catid, $epgae_u_catidexclude);

        //tag arg creator
        $epgae_u_tagid         = $settings['epgae_tag_terms_select'];
        $epgae_u_tagid_exclude = $settings['epgae_exclude__tag_terms'];


        //the field generrator
        $epgae_field_gen = $settings['epgae_field_gen'];
        $epgae_field_gen = $epgae_user_data->epgae_ren_func_repeater_to_array($epgae_field_gen);

        //Make clickable
        $epgae_make_clickable = $settings['make_block_clickable'];

        //The paginatio parameters
        $epgae_enable_pagination_on_top    = $settings['epgae_enable_pagination_on_top'];
        $epgae_enable_pagination_on_bottom = $settings['epgae_enable_pagination_on_bottom'];

        //Background parameters
        $epgae_b_enable               = $settings['epgae_make_featured_image_as_background'];
        $epgae_b_img_type_size        = $settings['epgae_back_featured_image_size'];
        $epgae_b_top_grad             = $settings['epgae_b_top_grad'];
        $epgae_bottom_grad            = $settings['epgae_b_bottom_grad'];
        $epgae_b_cover                = $settings['epgae_b_cover'];
        $epgae_b_repeat               = $settings['epgae_b_repeat'];
        $post_enable_pagination_fixed = $settings['post_enable_pagination_fixed'];
        $epgae_b_position             = $settings['epgae_b_position'];
        $epgae_allowed                = $epgae_user_data->epgae_html_allowed_html();

        $epgae_args = $epgae_user_data->epgae_args_generator(
            $epgae_u_posttype,
            $epgae_u_poststatus,
            $epgae_u_postpagingenable,
            $epgae_u_paginate_num,
            $epgae_u_password,
            $epgae_u_order,
            $epgae_u_orderby,
            $epgae_u_authorid,
            $epgae_u_catid,
            $epgae_u_tagid,
            $epgae_u_tagid_exclude
        );

        if ($post_enable_pagination_fixed == 'true') {
            unset($epgae_args['nopaging']);
        }
        $epgae_args = array_filter($epgae_args);


        $epgae_query = new \WP_Query($epgae_args);?>

        <div id="epgae-container" class="epgae-container">

          <?php do_action('epgae_action_before_top_pagination_top_hook', 'epgae_action_before_top_pagination');?>


          <?php if ($epgae_enable_pagination_on_top == 'yes'): ?>
          <div id="epgae-pagination-top" class="epgae-pagination epgae-pagination-top" >
                      <?php echo paginate_links($epgae_user_data->epgae_paginate_args($epgae_query)); ?>

          </div>
          <?php endif;?>

          <?php do_action('epgae_action_after_top_pagination_hook_act', 'epgae_action_after_top_pagination');?>

              <div id="epgae-row epgae-row-spec-<?php echo intval(get_queried_object_id()); ?>" class="epgae-row epgae-row-mob-<?php echo intval($settings['epgae_grid_column_mobile']); ?> epgae-row-tab-<?php echo intval($settings['epgae_grid_column_tablet']); ?> epgae-row-desk-<?php echo intval($settings['epgae_grid_column_dektop']); ?>">
                <?php if ($epgae_query->have_posts()): ?>
                <?php while ($epgae_query->have_posts()): $epgae_query->the_post(); ?>
                        <div id="epgae-card-design-outer epgae-grid-outer-<?php echo intval(get_the_id()); ?>" class="epgae-card-design-outer epgae-grid-outer-<?php echo intval(get_the_id()); ?>">
                          <div id="epgae-card-design epgae-grid-<?php echo intval(get_the_id()); ?>" class="epgae-card-design epgae-grid-<?php echo intval(get_the_id()); ?>"
                              <?php
                              if ($epgae_b_enable == 'yes'):
                                $epgae_b_img_id = get_the_ID();
                                $epgae_b_back   = $epgae_user_data->epgae_background_image_genenrator($epgae_b_img_id, $epgae_b_enable, $epgae_b_img_type_size, $epgae_b_cover, $epgae_b_repeat, $epgae_b_top_grad, $epgae_bottom_grad, $epgae_b_position);
                                echo wp_kses($epgae_b_back, $epgae_allowed);
                              endif;
                              ?>>
                                <div id="epgae-card-design-mul" class="epgae-card-design-mul">
                                  <div id="epgae-card-design-mul-inner epgae-card-design-mul-inner-col-1" class="epgae-card-design-mul-inner epgae-card-design-mul-inner-col-1" >
                                  <?php $epgae_user_data->epgae_core_grid_loader($epgae_field_gen, $epgae_make_clickable, $epgae_allowed); ?>
                                  </div>
                                  <?php
                                  $epgae_enable_multi = $settings['epgae_layout'];
                                    if ($epgae_enable_multi == 'grid'):
                                      ?>
                                  <div id="epgae-card-design-mul-inner epgae-card-design-mul-inner-col-2" class="epgae-card-design-mul-inner epgae-card-design-mul-inner-col-2">
                                  <?php
                                    $epgae_field_gen2 = $settings['epgae_field_gen2'];
                                    $epgae_field_gen2 = $epgae_user_data->epgae_ren_func_repeater_to_array($epgae_field_gen2);
                                    $epgae_user_data->epgae_core_grid_loader($epgae_field_gen2, $epgae_make_clickable, $epgae_allowed);
                                  ?>
                                  </div>
                                <?php endif;?>
                              </div>
                        </div><!-- epgae-card-design  Ends-->
                      </div>

                        <?php endwhile;?>
                  <!-- end of the loop -->

                   <!-- pagination here -->

               <?php wp_reset_postdata();?>
      <?php else: ?>
                <p><?php
            esc_html_e('Sorry, no posts matched your criteria.', 'epgae');
        ?></p>
      <?php endif;?>
    </div>

      <?php do_action('epgae_action_before_top_pagination_bottom_hook', 'epgae_action_before_bottom_pagination');?>

      <?php if ($epgae_enable_pagination_on_bottom == 'yes'): ?>
      <div id="epgae-pagination-bottom" class="epgae-pagination epgae-pagination-bottom">
            <?php echo paginate_links($epgae_user_data->epgae_paginate_args($epgae_query)); ?>
      </div>
      <?php endif;?>

      <?php do_action('epgae_action_before_top_pagination_bottom_hook', 'epgae_action_before_bottom_pagination');?>

  </div>
      <?php
}

}
