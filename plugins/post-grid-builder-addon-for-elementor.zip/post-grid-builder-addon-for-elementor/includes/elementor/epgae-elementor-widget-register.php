<?php
if (!defined('ABSPATH'))
  {
    exit;
  }
  final class EPGAE_Elementor_Epgae_Extension {

  	/**
  	 * Plugin Version
  	 *
  	 * @since 1.0.0
  	 *
  	 * @var string The plugin version.
  	 */
  	const EPGAE_VERSION = '1.0.0';

  	/**
  	 * Minimum Elementor Version
  	 *
  	 * @since 1.0.0
  	 *
  	 * @var string Minimum Elementor version required to run the plugin.
  	 */
  	const EPGAE_MINIMUM_ELEMENTOR_VERSION = '2.0.0';

  	/**
  	 * Minimum PHP Version
  	 *
  	 * @since 1.0.0
  	 *
  	 * @var string Minimum PHP version required to run the plugin.
  	 */
  	const EPGAE_MINIMUM_PHP_VERSION = '7.0';

  	/**
  	 * Instance
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access private
  	 * @static
  	 *
  	 */
  	private static $epgae_instance = null;

  	/**
  	 * Instance
  	 *
  	 * Ensures only one instance of the class is loaded or can be loaded.
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 * @static
  	 *
  	 */
  	public static function epgae_instance() {

  		if ( is_null( self::$epgae_instance ) ) {
  			self::$epgae_instance = new self();
  		}
  		return self::$epgae_instance;

  	}

  	/**
  	 * Constructor
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function __construct() {

  		add_action( 'init', [ $this, 'epgae_i18n' ] );
  		add_action( 'plugins_loaded', [ $this, 'epgae_init' ] );

  	}

  	/**
  	 * Load Textdomain
  	 *
  	 * Load plugin localization files.
  	 *
  	 * Fired by `init` action hook.
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function epgae_i18n() {

  		load_plugin_textdomain( 'epgae' );

  	}

  	/**
  	 * Initialize the plugin
  	 *
  	 * Load the plugin only after Elementor (and other plugins) are loaded.
  	 * Checks for basic plugin requirements, if one check fail don't continue,
  	 * if all check have passed load the files required to run the plugin.
  	 *
  	 * Fired by `plugins_loaded` action hook.
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function epgae_init() {

  		// Check if Elementor installed and activated
  		if ( ! did_action( 'elementor/loaded' ) ) {
  			add_action( 'admin_notices', [ $this, 'epgae_admin_notice_missing_main_plugin' ] );
  			return;
  		}

  		// Check for required Elementor version
  		if ( ! version_compare( ELEMENTOR_VERSION, self::EPGAE_MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
  			add_action( 'admin_notices', [ $this, 'epgae_admin_notice_minimum_elementor_version' ] );
  			return;
  		}

  		// Check for required PHP version
  		if ( version_compare( PHP_VERSION, self::EPGAE_MINIMUM_PHP_VERSION, '<' ) ) {
  			add_action( 'admin_notices', [ $this, 'epgae_admin_notice_minimum_php_version' ] );
  			return;
  		}

  		// Add Plugin actions
  		add_action( 'elementor/widgets/widgets_registered', [ $this, 'epgae_init_widgets' ] );
  		add_action( 'elementor/controls/controls_registered', [ $this, 'epgae_init_controls' ] );
      add_action('elementor/frontend/after_register_scripts', [$this, 'epgae_run_script']);
      add_action( 'elementor/frontend/after_enqueue_styles', [$this, 'epgae_run_styles']);
  	}

    public function epgae_run_script()
    {
        wp_register_script('epgae-core-jquery', plugin_dir_url(EPGAE_PLUGIN_FILE) . 'includes/js/epgae-core-jquery.js', ['jquery'], '1.0', false);
        wp_enqueue_script('epgae-core-jquery');
    }

    public function epgae_run_styles()
    {
        wp_register_style('epgae-core-css', plugin_dir_url(EPGAE_PLUGIN_FILE) . '/includes/css/epgae_core.min.css');
        wp_enqueue_style('epgae-core-css');
    }

  	/**
  	 * Admin notice
  	 *
  	 * Warning when the site doesn't have Elementor installed or activated.
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function epgae_admin_notice_missing_main_plugin() {

  		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

  		$epgae_message = sprintf(
  			/* translators: 1: Plugin name 2: Elementor */
  			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'epgae' ),
  			'<strong>' . esc_html__( 'Elementor Post Grid By Greeky Green Owl', 'epgae' ) . '</strong>',
  			'<strong>' . esc_html__( 'Elementor', 'epgae' ) . '</strong>'
  		);

  		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $epgae_message );

  	}

  	/**
  	 * Admin notice
  	 *
  	 * Warning when the site doesn't have a minimum required Elementor version.
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function epgae_admin_notice_minimum_elementor_version() {

  		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

  		$epgae_message = sprintf(
  			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
  			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'epgae' ),
  			'<strong>' . esc_html__( 'Elementor Post Grid by Geeky Green Owl', 'epgae' ) . '</strong>',
  			'<strong>' . esc_html__( 'Elementor', 'epgae' ) . '</strong>',
  			 self::EPGAE_MINIMUM_ELEMENTOR_VERSION
  		);

  		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $epgae_message );

  	}

  	/**
  	 * Admin notice
  	 *
  	 * Warning when the site doesn't have a minimum required PHP version.
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function epgae_admin_notice_minimum_php_version() {

  		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

  		$epgae_message = sprintf(
  			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
  			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'epgae' ),
  			'<strong>' . esc_html__( 'Elementor Post Grid by Geeky Green Owl', 'epgae' ) . '</strong>',
  			'<strong>' . esc_html__( 'PHP', 'epgae' ) . '</strong>',
  			 self::EPGAE_MINIMUM_PHP_VERSION
  		);

  		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $epgae_message );

  	}

  	/**
  	 * Init Widgets
  	 *
  	 * Include widgets files and register them
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function epgae_init_widgets() {
      // //core imager
      require_once __DIR__ . '/class-epgae-image-render.php';
      //
  		// // Include Widget files
      require_once( __DIR__ . '/postgrid2/epgae_post_grid_widget2.php' );
      \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Elementor_Epgae_Post_Grid2() );
  	}

  	/**
  	 * Init Controls
  	 *
  	 * Include controls files and register them
  	 *
  	 * @since 1.0.0
  	 *
  	 * @access public
  	 */
  	public function epgae_init_controls() {
        // NOt required
  	}

  }

  EPGAE_Elementor_Epgae_Extension::epgae_instance();


function epgae_add_elementor_widget_categories($epgae_elements_manager)
{

    $epgae_elements_manager->add_category(
        'epgae-category',
        [
            'title' => esc_html__('Geeky Green Owl Addons', 'epgae'),
            'icon'  => 'fa fa-braille',
        ]
    );

}
add_action('elementor/elements/categories_registered', 'epgae_add_elementor_widget_categories');


// allows to use the grid in single blog contents
function epgae_fix_usage_single_posts(){
  $args = array(
      'public' => true,
  );
  $output   = 'names'; // 'names' or 'objects' (default: 'names')
  $operator = 'and'; // 'and' or 'or' (default: 'and')

  $post_types = get_post_types($args, $output, $operator);
	if ( is_singular( $post_types ) ) {
			global $wp_query;
			$page = ( int ) $wp_query->get( 'page' );
			if ( $page > 1 ) {
					// convert 'page' to 'paged'
					$wp_query->set( 'page', 1 );
					$wp_query->set( 'paged', $page );
			}
			// prevent redirect
			remove_action( 'template_redirect', 'redirect_canonical' );
	}
}
add_action( 'template_redirect', 'epgae_fix_usage_single_posts',0 );
