<?php

// Firecd during plugin activaiotion


// @since 1.0.0
class Epgae_Deactivator {

	public static function epgae_deactivate(){
			//Nothing add since 1.0.0
	}
}
