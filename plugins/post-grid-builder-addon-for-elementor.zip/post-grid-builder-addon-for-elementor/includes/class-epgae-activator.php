<?php

// Firecd during plugin activaiotion


class Epgae_Activator {

	public static function epgae_activate(){
			
	}
}
