<?php
namespace EPGAECORENS {

  if (!defined('ABSPATH')) {
    exit;
  }

  class Epgae
  {

    protected $epgae_version;

    public function __construct()
    {

      if (defined('EPGAE_VERSION')) {
        $this->epgae_version = EPGAE_VERSION;
      } else {
        $this->epgae_version = '1.0.0';
      }

    }

    /*
    ID: EPGAE-1
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class : Returns list of post types
    */
    public function epgae_list_of_posttypes()
    {
      $args = array(
        'public' => true,
      );

      $output   = 'names'; // 'names' or 'objects' (default: 'names')
      $operator = 'and'; // 'and' or 'or' (default: 'and')

      $post_types = get_post_types($args, $output, $operator);
      $post_types = array_map('ucfirst', $post_types);
      return $post_types;
    }

    /*
    ID: EPGAE-2
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class : Returns list of post Taxonomy
    */
    public function epgae_list_of_taxonomy()
    {
      $args = array(
        'public'   => true,
        '_builtin' => true,
      );
      $tax_list = get_taxonomies($args);
      return $tax_list;
    }

    /*
    ID: EPGAE-3
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class : Generates the list of all taxonomy - Used in taxonomy
    */
    public function epgae_list_of_taxonomy_repeater_field()
    {
      $tax_list = get_taxonomies();
      return $tax_list;
    }

    /*
    ID: EPGAE-4
    Since ver 5.1.1
    Modified By : Latheesh V M Villa
    Purpose of the function/class : Generates the list of terms for the all the category
    */
    public function epgae_list_of_terms()
    {
      //$tax = $this->epgae_list_of_taxonomy();
      $terms = get_terms(array('taxonomy' => 'category'));
      $lat = array();
      foreach ($terms as $key => $term) {
        $lat[$term->term_taxonomy_id] = $term->name;
      }
      return $lat;
    }

    /*
    ID: EPGAE-5
    Since ver 5.1.1
    Modified By : Latheesh V M Villa
    Purpose of the function/class : Generates the list of terms for the all the category - Used in repeater
    */
    public function epgae_list_of_terms_repeater_field()
    {
      $tax   = $this->epgae_list_of_taxonomy_repeater_field();
      $terms = get_terms(array('taxonomy' => $tax));
      $lat = array();
      foreach ($terms as $key => $term) {
        $lat[$term->term_taxonomy_id] = $term->name;
      }
      return $lat;
    }

    /*
    ID: EPGAE-6
    Since ver 5.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :Generates the list of terms for the all the the_terms
    */
    public function epgae_list_of_tags()
    {
      $tax   = $this->epgae_list_of_taxonomy();
      $terms = get_tags();
      $lat2 = array();
      foreach ($terms as $key => $term) {
        $lat2[$term->term_taxonomy_id] = $term->name;
      }
      return $lat2;
    }

    /*
    ID: EPGAE-7
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  convert the meta value to array if comma exits other wise string
    */
    public function epgae_mata_value_gen($epgae_u_meta_value)
    {
      $searchString = ',';
      if (strpos($epgae_u_meta_value, $searchString) !== false) {
        $epgae_u_meta_value = explode(",", $epgae_u_meta_value);
      } else {
        $epgae_u_meta_value = $epgae_u_meta_value;
      }
      return $epgae_u_meta_value;
    }



    /*
    ID: EPGAE-8
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Collects ids of all the post types, then getpost to collect the IDs, Then returns the key array
    */
    public function epgae_custom_post_type_keylist()
    {
      $epgae_custompostype_array = $this->epgae_list_of_posttypes();

      $epgae_getposts            = array();
      foreach ($epgae_custompostype_array as $value) {
        $args = array(
          'numberposts' => 1,
          'post_type'   => $value,
        );
        if (!empty(get_posts($args)[0]->ID)) {
          $epgae_getposts[] = get_posts($args)[0]->ID;
        }

      }
      $new_array = array();
      foreach ($epgae_getposts as $value) {
        $new_array[] = get_post_custom($value);
      }

      $result = array();
      foreach ($new_array as $sub) {
        $result = array_merge($result, $sub);
      }
      $result     = array_keys($result);
      $result     = array_unique($result);
      $result     = array_combine($result, $result);
      $result[''] = 'NONE';
      return $result;
    }

    /*
    ID: EPGAE-8
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Collects ids of all the post types, then getpost to collect the IDs, Then returns the key array
    */
    public function epgae_catergory_id_generator($epgae_u_catid, $epgae_u_catidexclude)
    {

      if (is_array($epgae_u_catid)) {
        $epgae_u_catid = implode(", ", $epgae_u_catid);
      } else {
        $epgae_u_catid = '';
      }
      $epgae_u_catidexcluder = array();
      if (is_array($epgae_u_catidexclude)) {
        $epgae_u_catidexclude = array_map('intval', $epgae_u_catidexclude);

        foreach ($epgae_u_catidexclude as $value) {
          $epgae_u_catidexcluder[] = -1 * $value;
        }
      }
      if (is_array($epgae_u_catidexcluder)) {
        $epgae_u_catidexcluder = implode(",", $epgae_u_catidexcluder);
      } else {
        $epgae_u_catidexcluder = '';
      }

      if ($epgae_u_catidexcluder != '') {
        $epgae_cat_exculution = ',' . $epgae_u_catidexcluder;
      } else {
        $epgae_cat_exculution = $epgae_u_catidexcluder;
      }
      $epgae_u_catid2 = $epgae_u_catid . $epgae_cat_exculution;
      return $epgae_u_catid2;
    }

    /*
    ID: EPGAE-9
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Get the post status as list
    */
    public function epgae_list_of_post_status()
    {
      $post_stat = get_post_stati();
      return $post_stat;
    }

    /*
    ID: EPGAE-9
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  This is the main argument generator for the wp query
    */
    public function epgae_args_generator(
      $epgae_u_posttype,
      $epgae_u_poststatus,
      $epgae_u_postpagingenable,
      $epgae_u_paginate_num,
      $epgae_u_password,
      $epgae_u_order,
      $epgae_u_orderby,
      $epgae_u_authorid,
      $epgae_u_catid,
      $epgae_u_tagid,
      $epgae_u_tagid_exclude
    ){
      $paged = (get_query_var('paged')) ? absint(get_query_var('paged')) : 1;

      $arg = array(
        'post_type'      => $epgae_u_posttype,
        'post_status'    => $epgae_u_poststatus, //post_type_status
        'paged'          => $paged,
        'nopaging'       => $epgae_u_postpagingenable, //post_enable_pagination
        'posts_per_page' => $epgae_u_paginate_num, //post_count
        'has_password'   => $epgae_u_password, //password_protected
        'order'          => $epgae_u_order, //order
        'orderby'        => $epgae_u_orderby, //orderby
        'author'         => $epgae_u_authorid,
        'cat'            => $epgae_u_catid,
        'tag__in'        => $epgae_u_tagid,
        'tag__not_in'    => $epgae_u_tagid_exclude,
      );

      return apply_filters('epgae_args_generator_hook', $arg);
    }

    /*
    ID: EPGAE-10
    Apply filter provided - EPGAE AP1
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Renders the title of the post safer
    */
    public function epgae_ren_title()
    {
      $title = the_title_attribute('echo=0');
      return apply_filters('epgae_ren_title_hook', $title);
    }

    /*
    ID: EPGAE-11
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  This returns the url of the image when used
    */
    public function epgae_ren_image($adv_settings,$epgae_img_type, $epgae_img_id, $epgae_img_type_size='')
    {
      switch ($epgae_img_type) {
        case "featured":
        $imageurl_before = get_post_thumbnail_id($epgae_img_id);
        $imageurl_url = wp_get_attachment_url($imageurl_before);
        $extra= array(
          'url'=> $imageurl_url,
          'id'=> $imageurl_before,
        );
        if($adv_settings == 'old'){
          $imageurl = get_the_post_thumbnail_url($epgae_img_id, $epgae_img_type_size);
        }else{
          $imageurl =  \Elementor\Epgae_Featurred_Image_Getter::get_attachment_image_html_generator($imageurl_before, $adv_settings, $image_size_key = 'image', $image_key = null, $extra);
          if(empty($imageurl)){
            $imageurl_before = $adv_settings['image']['id'];
            if(!empty($imageurl_before)){
              $imageurl =  \Elementor\Epgae_Featurred_Image_Getter::get_attachment_image_html_generator($imageurl_before, $adv_settings, $image_size_key = 'image', $image_key = null, $extra);
            }
          }
        }
        return $imageurl;
        break;
      }
    }

    /*
    ID: EPGAE-12
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  This decides the content for the content selector
    */
    public function epgae_ren_content($epgae_cont_id, $epgae_r_content_type, $epgae_r_enable_excerpt, $epgae_excerpt_len)
    {

      switch ($epgae_r_content_type) {
        case "editor":
        $content = get_the_content();
        if ($epgae_r_enable_excerpt == 'yes') {
          $content = wp_trim_words($content, $epgae_excerpt_len, '...');
          return $content;
        } else {
          return $content;
        }
        break;

      }
    }

    /*
    ID: EPGAE-13
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  This decides the content for the button selector
    */
    public function epgae_ren_button($epgae_r_id, $epgae_r_buttonfieldtype)
    {
      switch ($epgae_r_buttonfieldtype) {
        case "linktopost":
        $url = get_permalink();
        return $url;
        break;
      }
    }


    /*
    ID: EPGAE-16
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Function modifed for repeater
    */
    public function epgae_ren_func_repeater_to_array($epgae_field_gen)
    {
      $valuescs = $epgae_field_gen;
      return $valuescs;
    }

    /*
    ID: EPGAE-17
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Converts the image size array to elemenetor selector array
    */
    public function epgae_ren_func_array_of_image_size()
    {
      $result = get_intermediate_image_sizes();
      $result = array_unique($result);
      $result = array_combine($result, $result);
      return $result;
    }

    /*
    ID: EPGAE-18
    Apply filter provided - EPGAE AP3
    Since ver 6.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Pagination arguments
    */
    public function epgae_paginate_args($epgae_query)
    {
      $paged = (get_query_var('paged')) ? absint(get_query_var('paged')) : 1;
      $paged = apply_filters('epgae_paginate_args_paged_hook', $paged);
      $args  = array(
        'format'    => '?paged=%#%',
        'current'   => intval($paged),
        'total'     => intval($epgae_query->max_num_pages),
        'mid_size'  => 2,
        'prev_text' => '<i class="fa fa-arrow-left"></i>',
        'next_text' => '<i class="fa fa-arrow-right"></i>',
      );
      return apply_filters('epgae_paginate_args_hook', $args);
    }

    /*
    ID: EPGAE-19
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  background image generator for row;
    */
    public function epgae_background_image_genenrator($epgae_b_img_id, $epgae_b_enable, $epgae_b_img_type_size, $epgae_b_cover, $epgae_b_repeat, $epgae_b_top_grad, $epgae_bottom_grad, $epgae_b_position)
    {
      $featured_image_url = get_the_post_thumbnail_url($epgae_b_img_id, $epgae_b_img_type_size);

      return 'style="background: linear-gradient(' . esc_attr($epgae_b_top_grad) . ',' . esc_attr($epgae_bottom_grad) . '),url(' . esc_url($featured_image_url) . '); background-size:cover; background-repeat:no-repeat; background-position:' . esc_html($epgae_b_position) . ' "';
    }

    /*
    ID: EPGAE-20
    Since ver 1.0.0
    Modified By : Latheesh V M Villa
    Purpose of the function/class :  Security for the html
    */
    public function epgae_html_allowed_html()
    {

      $allowed_tags = array(
        '&nbsp;'     => array(),
        'a'          => array(
          'class' => array(),
          'href'  => array(),
          'rel'   => array(),
          'title' => array(),
        ),
        'abbr'       => array(
          'title' => array(),
        ),
        'b'          => array(),
        'blockquote' => array(
          'cite' => array(),
        ),
        'cite'       => array(
          'title' => array(),
        ),
        'code'       => array(),
        'del'        => array(
          'datetime' => array(),
          'title'    => array(),
        ),
        'dd'         => array(),
        'div'        => array(
          'class' => array(),
          'title' => array(),
          'style' => array(),
        ),
        'dl'         => array(),
        'dt'         => array(),
        'em'         => array(),
        'h1'         => array(),
        'h2'         => array(),
        'h3'         => array(),
        'h4'         => array(),
        'h5'         => array(),
        'h6'         => array(),
        'i'          => array(),
        'img'        => array(
          'alt'    => array(),
          'class'  => array(),
          'height' => array(),
          'src'    => array(),
          'width'  => array(),
        ),
        'li'         => array(
          'class' => array(),
        ),
        'ol'         => array(
          'class' => array(),
        ),
        'p'          => array(
          'class' => array(),
        ),
        'q'          => array(
          'cite'  => array(),
          'title' => array(),
        ),
        'span'       => array(
          'class' => array(),
          'title' => array(),
          'style' => array(),
        ),
        'strike'     => array(),
        'strong'     => array(),
        'ul'         => array(
          'class' => array(),
        ),
      );

      return $allowed_tags;
    }



    public function epgae_image_css_gen($epgae_img_position, $epgae_img_position_setter, $epgae_img_width, $epgae_img_padding, $epgae_img_margin, $epgae_img_border_radius)
    {
      $epgae_return_array = [
        'width'                      => $epgae_img_width['size'] . $epgae_img_width['unit'],
        'position'                   => $epgae_img_position,
        'top'                        => $epgae_img_position_setter['top'] . $epgae_img_position_setter['unit'],
        'right'                      => $epgae_img_position_setter['right'] . $epgae_img_position_setter['unit'],
        'left'                       => $epgae_img_position_setter['left'] . $epgae_img_position_setter['unit'],
        'bottom'                     => $epgae_img_position_setter['bottom'] . $epgae_img_position_setter['unit'],
        'padding-left'               => $epgae_img_padding['left'] . $epgae_img_padding['unit'],
        'padding-right'              => $epgae_img_padding['right'] . $epgae_img_padding['unit'],
        'padding-top'                => $epgae_img_padding['top'] . $epgae_img_padding['unit'],
        'padding-bottom'             => $epgae_img_padding['bottom'] . $epgae_img_padding['unit'],
        'margin-top'                 => $epgae_img_margin['top'] . $epgae_img_margin['unit'],
        'margin-left'                => $epgae_img_margin['left'] . $epgae_img_margin['unit'],
        'margin-right'               => $epgae_img_margin['right'] . $epgae_img_margin['unit'],
        'margin-bottom'              => $epgae_img_margin['bottom'] . $epgae_img_margin['unit'],
        'border-top-left-radius'     => $epgae_img_border_radius['top'] . $epgae_img_border_radius['unit'],
        'border-top-right-radius'    => $epgae_img_border_radius['left'] . $epgae_img_border_radius['unit'],
        'border-bottom-left-radius'  => $epgae_img_border_radius['bottom'] . $epgae_img_border_radius['unit'],
        'border-bottom-right-radius' => $epgae_img_border_radius['right'] . $epgae_img_border_radius['unit'],
      ];

      $epgae_return_var = '';
      foreach ($epgae_return_array as $key => $value) {
        $epgae_return_var .= $key . ':' . $value . ';';
      }
      return $epgae_return_var;
    }


    public function epgae_core_grid_loader($epgae_field_gen,$epgae_make_clickable,$epgae_allowed){
      foreach (array_column($epgae_field_gen, 'field_type') as $epgae_key => $epgae_value) {
        global $product;
        switch ($epgae_value) {

          case "title":
          if ($epgae_make_clickable == 'yes'):
            echo '<a id="epgae-cl-title-a" class="epgae-cl-title-a" href="' . get_post_permalink() . '">';
          endif;
          echo '<div id="' . esc_attr($epgae_field_gen[$epgae_key]['field_id']) . '" class="' . esc_attr($epgae_field_gen[$epgae_key]['field_class']) . ' epgae-repeater-container elementor-repeater-item-' . $epgae_field_gen[$epgae_key]['_id'] . ' elementor-animation-' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_hover_animation']) . '  animated  ' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_entrance_animation']) . ' ">';
          echo '<div class="epgae-repeater-container-inner">';
          echo esc_html($this->epgae_ren_title()); //the_title_attribute which is safe to use
          echo '</div>';
          echo '</div>';
          if ($epgae_make_clickable == 'yes'):
            echo '</a>';
          endif;
          break;

          case "image":
          $epgae_img_id        = get_the_ID();
          $epgae_img_type      = $epgae_field_gen[$epgae_key]['field_image_url'];
          //$epgae_img_custom    = $epgae_field_gen[$epgae_key]['field_image_acf_or_custom'];
          $adv_settings = $epgae_field_gen[$epgae_key];
          $epgae_img_src      = $this->epgae_ren_image($adv_settings,$epgae_img_type, $epgae_img_id, $epgae_img_type_size='');
          $epgae_alt_gen           = get_the_title(get_the_ID());
          if ($epgae_make_clickable == 'yes'):
            echo '<a class="epgae-cl-image-a" href="' . get_post_permalink() . '">';
          endif;
          if (!empty($epgae_img_src)):
            echo '<div id="' . esc_attr($epgae_field_gen[$epgae_key]['field_id']) . '" class="' . esc_attr($epgae_field_gen[$epgae_key]['field_class']) . ' epgae-repeater-container elementor-repeater-item-' . $epgae_field_gen[$epgae_key]['_id'] . ' elementor-animation-' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_hover_animation']) . '  animated  ' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_entrance_animation']) . ' ">';
            echo '<div class="epgae-repeater-container-inner">';
            echo wp_kses($epgae_img_src, $this->epgae_html_allowed_html());
            echo '</div>';
            echo '</div>';
          endif;
          if ($epgae_make_clickable == 'yes'):
            echo '</a>';
          endif;
          break;

          case "content":
          $epgae_cont_id          = get_the_ID();
          $epgae_r_content_type   = $epgae_field_gen[$epgae_key]['field_content_type'];
          $epgae_r_enable_excerpt = $epgae_field_gen[$epgae_key]['trim_content'];
          $epgae_excerpt_len = $epgae_field_gen[$epgae_key]['excerpt_length'];
          $epgae_c_src       = $this->epgae_ren_content($epgae_cont_id, $epgae_r_content_type, $epgae_r_enable_excerpt, $epgae_excerpt_len);

          if ($epgae_make_clickable == 'yes'):
            echo '<a id="epgae-cl-content-a" class="epgae-cl-content-a" href="' . get_post_permalink() . '">';
          endif;
          if(!empty($epgae_c_src)){
            echo '<div id="' . esc_attr($epgae_field_gen[$epgae_key]['field_id']) . '" class="' . esc_attr($epgae_field_gen[$epgae_key]['field_class']) . ' epgae-repeater-container elementor-repeater-item-' . $epgae_field_gen[$epgae_key]['_id'] . ' elementor-animation-' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_hover_animation']) . '  animated  ' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_entrance_animation']) . ' ">';
            echo '<div class="epgae-repeater-container-inner">';
            echo wp_kses($epgae_field_gen[$epgae_key]['epgae_content_before_placer'],$epgae_allowed);
            echo esc_html($epgae_c_src);
            echo wp_kses($epgae_field_gen[$epgae_key]['epgae_content_after_placer'], $epgae_allowed);
            echo '</div>';
            echo '</div>';
          }
          if ($epgae_make_clickable == 'yes'):
            echo '</a>';
          endif;
          break;

          case "button":
          $epgae_r_id              = get_the_ID();
          $epgae_r_buttonfieldtype = $epgae_field_gen[$epgae_key]['button_field_type'];
          $epgae_r_buttonfieldtext = $epgae_field_gen[$epgae_key]['button_field_type_text'];
            $epgae_c_url   = $this->epgae_ren_button($epgae_r_id, $epgae_r_buttonfieldtype);
            echo '<div id="' . esc_attr($epgae_field_gen[$epgae_key]['field_id']) . '" class="' . esc_attr($epgae_field_gen[$epgae_key]['field_class']) . ' epgae-repeater-container elementor-repeater-item-' . $epgae_field_gen[$epgae_key]['_id'] . ' elementor-animation-' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_hover_animation']) . '  animated  ' . esc_attr($epgae_field_gen[$epgae_key]['epgae_title_entrance_animation']) . ' ">';
            echo '<div class="epgae-repeater-container-inner">';
            echo '<a href="' . esc_url($epgae_c_url) . '" >' . esc_html($epgae_r_buttonfieldtext) . '</a>';
            echo '</div>';
            echo '</div>';
          break;
          default:
          echo "";
        }
      }
    }



    }
  }
