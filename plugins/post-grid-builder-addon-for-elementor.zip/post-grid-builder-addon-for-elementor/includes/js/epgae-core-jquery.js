jQuery(document).ready(function($) {
  if( $('#epgae-container').length ){
    setInterval(function (){
        if( $('#epage_lite_credit').length == 0 || $('#epage_lite_credit').css('display') == 'none' ){
          $( "#epgae-container" ).after( "<div style='display:flex !important;' href='https://geekygreenowl.com/' id='epage_lite_credit'> Powered By <a id='epage_lite_credit'>Geeky Green Owl</a></div>" );
        }
    }, 1000);
  }
});
