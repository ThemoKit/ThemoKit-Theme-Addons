<?php

/**
 *
 * @link              https://geekygreenowl.com
 * @since             6.1.0
 * @package           Epgae
 *
 * @wordpress-plugin
 * Plugin Name:       Post Grid Builder Addon for Elementor
 * Plugin URI:        https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376
 * Description:       Create Grid layout for posts, pages & custom post types. Unlimited design possiblites, supports custom fields as well.
 * Version:           2.0.0
 * Author:            Latheesh V M
 * Author URI:        https://geekygreenowl.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       epgae
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
defined( 'ABSPATH' ) || exit;
define( 'EPGAE_PLUGIN_FILE', __FILE__ );
define( 'EPGAE_VERSION', '2.0.0' );

function epgae_activate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-epgae-activator.php';
	Epgae_Activator::epgae_activate();
}

function epgae_deactivate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-epgae-deactivator.php';
	Epgae_Deactivator::epgae_deactivate();
}

register_activation_hook( __FILE__, 'epgae_activate' );
register_deactivation_hook( __FILE__, 'epgae_deactivate' );

// Core plugin functionality
require plugin_dir_path( __FILE__ ) . 'includes/elementor/epgae-elementor-widget-register.php';
require plugin_dir_path( __FILE__ ) . 'includes/class-epgae.php';
// Elementor Widget Registration


function epgae_run(){
	 $plugin = new EPGAECORENS\Epgae();
}

epgae_run();

add_filter('plugin_action_links_'.plugin_basename(__FILE__), 'epgae_pro_version_link');
function epgae_pro_version_link( $links ) {
	$links[] = '<a target="_blank" style="font-weight:600; color:#ffffff; background:#548801; padding:3px 15px; border-radius:15px;" href="https://codecanyon.net/item/elementor-post-grid-by-geeky-green-owl/23860376">' . __('Get Pro Version') . '</a>';
	return $links;
}
