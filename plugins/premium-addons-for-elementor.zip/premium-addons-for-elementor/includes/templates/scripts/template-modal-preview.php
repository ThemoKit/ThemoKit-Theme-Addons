<?php
/**
 * Templates Item Preview
 */
?>
<div class="premium-template-item-notice"></div>
<div class="premium-template-item-preview-iframe">
    <iframe></iframe>
</div>
