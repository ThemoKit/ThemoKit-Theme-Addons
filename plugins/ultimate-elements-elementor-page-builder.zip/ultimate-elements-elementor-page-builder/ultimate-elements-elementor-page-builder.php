<?php
/*
  Plugin Name: Ultimate Elements - Elementor Page Builder
  Plugin URI: http://wpexpertdeveloper.com/ultimate-elements-elementor-page-builder
  Description: Wide range of UI and feature elements for Elementor page builder.
  Version: 1.0
  Author: Rakhitha Nimesh
  Author URI: http://wpexpertdeveloper.com/
 */


// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;


function ueepb_load_elements() {
    UEEPB_Elements::get_instance()->init();
}

add_action( 'plugins_loaded', 'ueepb_load_elements' ); 



class UEEPB_Elements {

    private static $instance = null;

    public static function get_instance() {
        if ( ! self::$instance )
            self::$instance = new self;
        return self::$instance;
    }

    public function init(){
        global $ueepb;

    	if ( ! defined( 'UEEPB_PLUGIN_DIR' ) ) {
            define( 'UEEPB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
        }

        // Plugin Folder URL
        if ( ! defined( 'UEEPB_PLUGIN_URL' ) ) {
            define( 'UEEPB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
        }

        require_once UEEPB_PLUGIN_DIR.'classes/class-ueepb-template-loader.php';
        require_once UEEPB_PLUGIN_DIR.'classes/class-ueepb-slider-manager.php';

        $ueepb = new stdClass;
        $ueepb->template_loader = new UEEPB_Template_Loader();
        $ueepb->slider_manager = new UEEPB_Slider_Manager();


    	add_action('wp_enqueue_scripts',array( $this,'load_scripts'),9);
        add_action( 'elementor/init', array( $this,'ueepb_add_elementor_category' ) );
        add_action( 'elementor/widgets/widgets_registered', array( $this, 'widgets_registered' ) );
    }

    public function load_scripts(){
          
        wp_register_style('ueepb-front-style', UEEPB_PLUGIN_URL . 'css/ueepb-front.css');
        

        wp_register_script('ueepb-front', UEEPB_PLUGIN_URL.'js/ueepb-front.js', array('jquery'));
       
        wp_register_script('ueepb-jssor-slides-script', UEEPB_PLUGIN_URL.'lib/jssor/jssor.slider.mini.js', array('jquery'));
        
        wp_register_script('ueepb-slider-init', UEEPB_PLUGIN_URL.'js/ueepb-slider-init.js', array('jquery'));
       
        wp_register_style('ueepb-viewer-front', UEEPB_PLUGIN_URL . 'css/ueepb-viewer-front.css');        

        wp_register_style('ueepb-image-viewer-style', UEEPB_PLUGIN_URL . 'lib/viewer-master/viewer.css');
        wp_register_script('ueepb-image-viewer-script', UEEPB_PLUGIN_URL.'lib/viewer-master/viewer.js', array('jquery'));
    }

    public function ueepb_add_elementor_category(){

        \Elementor\Plugin::instance()->elements_manager->add_category(
                'ueepb-media-elements',
                array(
                    'title' => __( 'Ultimate Media', 'ueepb' ),
                    'icon'  => 'fa fa-plug',
                ),
                1
            );
        
    }

    public function widgets_registered($widgets_manager) {
        if(defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')){
            
            require_once plugin_dir_path(__FILE__).'/functions.php';

            $widget_files = array('ueepb-image-slider-element.php',
                'ueepb-image-viewer-element.php');

            foreach ($widget_files as $widget_file_item) {
                $widget_file = plugin_dir_path(__FILE__).'widgets/'.$widget_file_item;
                $template_file = locate_template($widget_file);
                if ( !$template_file || !is_readable( $template_file ) ) {
                    $template_file = plugin_dir_path(__FILE__).'widgets/'.$widget_file_item;
                }

                if ( $template_file && is_readable( $template_file ) ) {
                    require_once $template_file;
                }

                
            }

            $widget = new Elementor\Widget_UEEPB_Image_Slider();
            $widgets_manager->register_widget_type( $widget );

            $widget = new Elementor\Widget_UEEPB_Image_Viewer();
            $widgets_manager->register_widget_type( $widget );
            
        }
    }
}





