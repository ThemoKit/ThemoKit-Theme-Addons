<?php
namespace ElementsKit\Modules\Controls;

defined( 'ABSPATH' ) || exit;

class Icons{

	public static function ekit_icons_pack(){
		add_filter('elementor/icons_manager/additional_tabs', function(){
				return apply_filters( 'elementor/icons_manager/native', [
					'ekiticons' => [
						'name' => 'ekiticons',
						'label' => __( 'ElementsKit - Icons', 'elementskit' ),
						'url' => Init::get_url() . 'assets/css/ekiticons.css',
						'enqueue' => [Init::get_url() . 'assets/css/ekiticons.css'],
						'prefix' => 'icon-',
						'displayPrefix' => 'icon',
						'labelIcon' => 'icon icon-ekit',
						'ver' => '5.9.0',
						'fetchJson' => Init::get_url() . 'assets/js/ekiticons.js',
						'native' => true,
					]
				]);
			}
		);
		
	}
	
	public static function __generate_font(){
		global $wp_filesystem;
		require_once ( ABSPATH . '/wp-admin/includes/file.php' );
		WP_Filesystem();
		//$css_file =  \ElementsKit::widget_dir() . 'init/assets/css/admin-ekiticon.css';
		$css_file =  Init::get_dir() . 'assets/css/ekiticons.css';
		if ( $wp_filesystem->exists( $css_file ) ) {
			$css_source = $wp_filesystem->get_contents( $css_file );
		} 
		
		preg_match_all( "/\.(icon-.*?):\w*?\s*?{/", $css_source, $matches, PREG_SET_ORDER, 0 );
		$iconList = [];
		foreach ( $matches as $match ) {
			//$new_icons[$match[1] ] = str_replace('ekit-wid-con .icon-', '', $match[1]);
			$iconList[] = str_replace('icon-', '', $match[1]);
		}
		$icons = new \stdClass();
		$icons->icons = $iconList;
		$icon_data = json_encode($icons);
		$file = Init::get_dir() . 'assets/js/ekiticons.js';
		global $wp_filesystem;
		require_once ( ABSPATH . '/wp-admin/includes/file.php' );
		WP_Filesystem();
		if ( $wp_filesystem->exists( $file ) ) {
			$content =  $wp_filesystem->put_contents( $file, $icon_data) ;
		} 
		
	}

}
