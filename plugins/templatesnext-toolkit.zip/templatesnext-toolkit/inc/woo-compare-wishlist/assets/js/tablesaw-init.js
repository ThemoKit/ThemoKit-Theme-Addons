;( function( $ ) {
	$( function() {
		$( document ).trigger( 'enhance.tablesaw' );
	} );
} )( jQuery );