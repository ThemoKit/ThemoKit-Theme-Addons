<div id="elements" class="drozd-settings-tabs">
	<div class="drozd-wrapper">
		<div class="content">
			content
		</div>
		<div class="sidebar">
			sidebar
		</div>
	</div>
</div><!-- #elements -->