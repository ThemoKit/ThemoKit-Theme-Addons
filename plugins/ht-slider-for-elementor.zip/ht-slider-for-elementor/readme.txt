=== HT Slider For Elementor ===
Contributors: htplugins
Tags: Slider, Elementor, Widgets, Post type slider, Elementor Addons
Requires at least: 4.4
Tested up to: 5.2.3
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The HT Slider For Elementor Widget is a elementor addons for WordPress.

== Description ==
HT Slider For Elementor is a elementor addons for elementor page bulider. You can create a slider easily drag and drop From Elementor Page bulider addons.

> ## Ultimate Addons for Elementor Page Builder
> Don't forgete to check our Unlimite mega addon for Elementor page Builder.
> [HT Mega – Ultimate Addons for Elementor Page Builder](https://wordpress.org/plugins/ht-mega-for-elementor/)
> Includes 360 Blocke & 15 Landing Pages.

== Features: ==
* Create Slides using Elementors Drag n Drop Addons.
* Custom Styling Options
* Show by id and category wise.
* Mobile and Tablet display options.
* Slider Navigation and paginations custom design options.
* Slider Navigation on/off Option.
* Slider Pagination on/off Option.
* Slider Autoplay on/off Option.

== Need Help? ==
Is there any feature that you want to get in this plugin? 
Needs assistance to use this plugin? 
Feel free to [Contact us](https://hasthemes.com/contact-us/)

== Installation ==
This section describes how to install the HT Slider for Elementor Page Builder Plugins for WordPress get it working.

= 1) Install =

= Install: =
1. Go to the WordPress Dashboard "Add New Plugin" section.
2. Search For "HT Slider For Elementor".
3. Install, then Activate it.

= OR: =
1. Unzip (if it is zipped) and Upload `ht-slider-for-elementor` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==
1. Slider Options in dashboard
2. Elementor Addons slider content Options
3. Elementor Addons slider control Options
4. Elementor Addons slider navigation and pagination button Styling Options
5. Front end View