<?php
/*
 Silence is golden.
*/
?>