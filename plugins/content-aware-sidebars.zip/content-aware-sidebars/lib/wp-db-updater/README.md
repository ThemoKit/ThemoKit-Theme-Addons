# wp-db-updater
Manage database updates in your WordPress plugin or theme
