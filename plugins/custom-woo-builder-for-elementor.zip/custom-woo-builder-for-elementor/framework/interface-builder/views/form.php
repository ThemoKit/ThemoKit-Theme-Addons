<?php
/**
 * Form template.
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
?>
<form class="cx-form <?php echo esc_attr_e( $args['class'] ); ?>" id="<?php echo esc_attr_e( $args['id'] ); ?>" name="<?php echo esc_attr_e( $args['id'] ); ?>" accept-charset="<?php echo esc_attr_e( $args['accept-charset'] ); ?>" action="<?php echo esc_attr_e( $args['action'] ); ?>" autocomplete="<?php echo esc_attr_e( $args['autocomplete'] ); ?>" enctype="<?php echo esc_attr_e( $args['enctype'] ); ?>" method="<?php echo esc_attr_e( $args['method'] ); ?>" target="<?php echo esc_attr_e( $args['target'] ); ?>" <?php echo esc_attr_e( $args['novalidate'] ); ?> >
	<?php
		if ( ! empty( $args['children'] ) ) {
			echo $args['children'];
		}
	?>
</form>
