<?php
/**
 * Single meta template
 */

woocommerce_template_single_meta();
