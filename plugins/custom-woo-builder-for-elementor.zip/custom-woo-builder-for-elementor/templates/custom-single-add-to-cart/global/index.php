<?php
/**
 * Single add to cart template
 */
woocommerce_template_single_add_to_cart();
