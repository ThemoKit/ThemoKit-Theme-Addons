<?php
/**
 * Plugin Name: Piotnet Addons For Elementor
 * Description: Piotnet Addons For Elementor (PAFE) adds many new features for Elementor
 * Plugin URI:  https://pafe.piotnet.com/
 * Version:     2.2.0
 * Author:      Luong Huu Phuoc (Louis Hufer)
 * Author URI:  https://piotnet.com/
 * Text Domain: pafe
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'PAFE_VERSION', '2.2.0' );
define( 'PAFE_PREVIOUS_STABLE_VERSION', '2.1.0' );

define( 'PAFE_DIR', plugin_dir_path(__FILE__));
define( 'PAFE_URL', plugins_url( '/', __FILE__ ) );

final class Piotnet_Addons_For_Elementor {

	const VERSION = '2.2.0';
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';
	const MINIMUM_PHP_VERSION = '5.4';
	const TAB_PAFE = 'tab_pafe';

	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	public function __construct() { 

		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'init' ] );
		register_activation_hook( __FILE__, [ $this, 'plugin_activate'] );
		add_action( 'admin_init', [ $this, 'plugin_redirect'] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_elementor_widget_categories' ] );

		add_filter( 'elementor/init', [ $this, 'add_pafe_tab'], 10,1);
		add_filter( 'elementor/controls/get_available_tabs_controls', [ $this, 'add_pafe_tab'], 10,1);
		
		require_once( __DIR__ . '/inc/features.php' );

		if ( !defined('PAFE_PRO_VERSION') ) {
			add_shortcode('pafe-template', [ $this, 'pafe_template_elementor' ] );

			if ( !defined('ELEMENTOR_PRO_VERSION') ) {
			    add_filter( 'manage_elementor_library_posts_columns', [ $this, 'set_custom_edit_columns' ] );
		    	add_action( 'manage_elementor_library_posts_custom_column', [ $this, 'custom_column' ], 10, 2 );
			}
		}
	} 

	public function i18n() {

		load_plugin_textdomain( 'pafe' );

	}

	public function enqueue() {

		if( get_option( 'pafe-features-image-carousel-multiple-custom-urls', 2 ) == 2 || get_option( 'pafe-features-image-carousel-multiple-custom-urls', 2 ) == 1 ) {
			wp_enqueue_script( 'pafe-image-carousel-multiple-custom-urls', plugin_dir_url( __FILE__ ) . 'assets/js/minify/pafe-image-carousel-multiple-custom-urls.min.js', array('jquery'), '1.0.0' );
		}

		if( get_option( 'pafe-features-before-after-image-comparison-slider', 2 ) == 2 || get_option( 'pafe-features-before-after-image-comparison-slider', 2 ) == 1 ) {
			wp_enqueue_style( 'pafe-before-after-image-comparison-slider', plugin_dir_url( __FILE__ ) . 'assets/css/minify/pafe-before-after-image-comparison-slider.min.css', [], self::VERSION );
			wp_enqueue_script( 'pafe-before-after-image-comparison-slider-scripts', plugin_dir_url( __FILE__ ) . 'assets/js/minify/pafe-before-after-image-comparison-slider.min.js', array('jquery'), '1.0.0' );
		}

		if( get_option( 'pafe-features-switch-content', 2 ) == 2 || get_option( 'pafe-features-switch-content', 2 ) == 1 ) {
			wp_enqueue_style( 'pafe-switch-content', plugin_dir_url( __FILE__ ) . 'assets/css/minify/pafe-switch-content.min.css', [], self::VERSION );
			wp_enqueue_script( 'pafe-switch-content-scripts', plugin_dir_url( __FILE__ ) . 'assets/js/minify/pafe-switch-content.min.js', array('jquery'), self::VERSION );
		}

		if( get_option( 'pafe-features-tooltip', 2 ) == 2 || get_option( 'pafe-features-tooltip', 2 ) == 1 ) {
			wp_enqueue_style( 'pafe-tooltip', plugin_dir_url( __FILE__ ) . 'assets/css/minify/pafe-tooltip.min.css', [], self::VERSION );
			wp_enqueue_script( 'pafe-tooltip-scripts', plugin_dir_url( __FILE__ ) . 'assets/js/minify/pafe-tooltip.min.js', array('jquery'), self::VERSION );
		} 
		  
	}

	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Add Plugin actions
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
		add_action( 'elementor/controls/controls_registered', [ $this, 'init_controls' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue' ] );
		add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), [ $this, 'plugin_action_links' ], 10, 1 );
		add_filter( 'plugin_row_meta', [ $this, 'plugin_row_meta' ], 10, 2 );
		add_action( 'admin_menu', [ $this, 'admin_menu' ], 600 );

	}

	public function add_pafe_tab($tabs){
		if(version_compare(ELEMENTOR_VERSION,'1.5.5')){
			Elementor\Controls_Manager::add_tab(self::TAB_PAFE, __( 'PAFE', 'pafe' ));
		}else{
			$tabs[self::TAB_PAFE] = __( 'PAFE', 'pafe' );
		}    
        return $tabs;
    }

	public function pafe_template_elementor($atts){
	    if(!class_exists('Elementor\Plugin')){
	        return '';
	    }
	    if(!isset($atts['id']) || empty($atts['id'])){
	        return '';
	    }

	    $post_id = $atts['id'];
	    $response = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($post_id);
	    return $response;
	}

	public function set_custom_edit_columns($columns) {
        $columns['pafe-shortcode'] = __( 'Shortcode', 'pafe' );
        return $columns;
    }

    public function custom_column( $column, $post_id ) {
        switch ( $column ) {
            case 'pafe-shortcode' :
                echo '<input class="elementor-shortcode-input" type="text" readonly="" onfocus="this.select()" value="[pafe-template id=' . '&quot;' . $post_id . '&quot;' . ']">'; 
                break;
        }
    }

	public function plugin_activate() {

	    add_option( 'piotnet_addons_for_elementor_do_activation_redirect', true );

	}

	public function plugin_redirect() {

	    if ( get_option( 'piotnet_addons_for_elementor_do_activation_redirect', false ) ) {
	        delete_option( 'piotnet_addons_for_elementor_do_activation_redirect' );
	        wp_redirect( 'admin.php?page=piotnet-addons-for-elementor' );
	    }

	}

	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'pafe' ),
			'<strong>' . esc_html__( 'Piotnet Addons For Elementor', 'pafe' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'pafe' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'pafe' ),
			'<strong>' . esc_html__( 'Piotnet Addons For Elementor', 'pafe' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'pafe' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'pafe' ),
			'<strong>' . esc_html__( 'Piotnet Addons For Elementor', 'pafe' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'pafe' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function plugin_action_links( $links ) { 

		$links[] = '<a href="'. esc_url( get_admin_url(null, 'admin.php?page=piotnet-addons-for-elementor') ) .'">' . esc_html__( 'Settings', 'pafe' ) . '</a>';
		$links[] = '<a href="https://pafe.piotnet.com" target="_blank" class="elementor-plugins-gopro">' . esc_html__( 'Go Pro', 'pafe' ) . '</a>';
		return $links;

	}

	public function plugin_row_meta( $links, $file ) {

		if ( strpos( $file, 'piotnet-addons-for-elementor.php' ) !== false ) {
			$links[] = '<a href="https://pafe.piotnet.com/tutorials" target="_blank">' . esc_html__( 'Video Tutorials', 'pafe' ) . '</a>';
		}
   		return $links;

	}

	public function admin_menu() {

		if ( !defined('PAFE_PRO_VERSION') ) {
			add_menu_page(
				'Piotnet Addons',
				'Piotnet Addons',
				'manage_options',
				'piotnet-addons-for-elementor',
				[ $this, 'admin_page' ],
				'dashicons-pafe-icon'
			);

			add_action( 'admin_init',  [ $this, 'pafe_settings' ] );
		}

	}

	public function pafe_settings() {

		require_once( __DIR__ . '/inc/features.php' );
		$features_free = json_decode( PAFE_FEATURES_FREE, true );
		$features_pro = json_decode( PAFE_FEATURES_PRO, true );
		$features = $features_free + $features_pro;

		foreach ($features as $feature) {
			if ( defined('PAFE_VERSION') && !$feature['pro'] || defined('PAFE_PRO_VERSION') && $feature['pro'] ) {
				register_setting( 'piotnet-addons-for-elementor-features-settings-group', $feature['option'] );
			}
		}

		register_setting( 'piotnet-addons-for-elementor-pro-settings-group', 'piotnet-addons-for-elementor-pro-username' );
		register_setting( 'piotnet-addons-for-elementor-pro-settings-group', 'piotnet-addons-for-elementor-pro-password' );
		
	}

	public function admin_page(){
		
		require_once( __DIR__ . '/inc/admin-page.php' );

	}

	public function admin_enqueue() {
		if ( !defined('PAFE_PRO_VERSION') ) {
			wp_enqueue_style( 'pafe-admin-css', plugin_dir_url( __FILE__ ) . 'assets/css/minify/pafe-admin.min.css', false, '1.3.0' );
			wp_enqueue_script( 'pafe-admin-js', plugin_dir_url( __FILE__ ) . 'assets/js/minify/pafe-admin.min.js', false, '1.2.0' );
		}
	}

	public function add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'pafe-free-widgets',
			[
				'title' => __( 'PAFE Free Widgets', 'pafe' ),
				'icon' => 'fa fa-plug',
			]
		);

	}

	public function init_widgets() {

		if( get_option( 'pafe-features-before-after-image-comparison-slider', 2 ) == 2 || get_option( 'pafe-features-before-after-image-comparison-slider', 2 ) == 1 ) {
			require_once( __DIR__ . '/widgets/pafe-before-after-image-comparison-slider.php' );
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \PAFE_Before_After_Image_Comparison_Slider() );
		}

		if( get_option( 'pafe-features-switch-content', 2 ) == 2 || get_option( 'pafe-features-switch-content', 2 ) == 1 ) {
			require_once( __DIR__ . '/widgets/pafe-switch-content.php' );
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \PAFE_Switch_Content() );
		}
	}

	public function init_controls() { 

		// Include Control files

		if( get_option( 'pafe-features-image-carousel-multiple-custom-urls', 2 ) == 2 || get_option( 'pafe-features-image-carousel-multiple-custom-urls', 2 ) == 1 ) {
			require_once( __DIR__ . '/controls/pafe-image-carousel-multiple-custom-urls.php' );
			new PAFE_Image_Carousel_Multiple_Custom_Urls();
		}

		if( get_option( 'pafe-features-gradient-text', 2 ) == 2 || get_option( 'pafe-features-gradient-text', 2 ) == 1 ) {
			require_once( __DIR__ . '/controls/pafe-gradient-text.php' );
			new PAFE_Gradient_Text();
		}

		if( get_option( 'pafe-features-gradient-button', 2 ) == 2 || get_option( 'pafe-features-gradient-button', 2 ) == 1 ) {
			require_once( __DIR__ . '/controls/pafe-gradient-button.php' );
			new PAFE_Gradient_Button();
		}		

		if( get_option( 'pafe-features-tooltip', 2 ) == 2 || get_option( 'pafe-features-tooltip', 2 ) == 1 ) {
			require_once( __DIR__ . '/controls/pafe-tooltip.php' );
			new PAFE_Tooltip();
		}	

	}

}

Piotnet_Addons_For_Elementor::instance();