<?php // Silence is golden. And we know it very well! :)
