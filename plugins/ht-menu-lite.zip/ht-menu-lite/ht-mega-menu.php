<?php
/**
 * Plugin Name: HT Menu Lite
 * Description: HT Menu for Elementor Page Builder. You can create easily any layout use this plugins.
 * Plugin URI:  http://demo.shrimpthemes.com/1/megamenu/
 * Author:      HasThemes
 * Author URI:  http://hasthemes.com/
 * Version:     1.0.2
 * License:     GPL2
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: htmega-menu
 * Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! defined( 'HTMEGA_MENU_VERSION' ) ) {
    define( 'HTMEGA_MENU_VERSION', '1.0.2' );
}

if ( ! defined( 'HTMEGA_MENU_PL_URL' ) ) {
    define( 'HTMEGA_MENU_PL_URL', plugins_url( '/', __FILE__ ) );
}

if ( ! defined( 'HTMEGA_MENU_PL_PATH' ) ) {
    define( 'HTMEGA_MENU_PL_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'HTMEGA_MENU_PL_ROOT' ) ) {
    define( 'HTMEGA_MENU_PL_ROOT', __FILE__ );
}
// Plugins Name
if ( ! defined( 'HTMEGA_MENU_NAME' ) ) {
    define( 'HTMEGA_MENU_NAME', 'HTMega Menu Lite' );
}

if ( ! function_exists('is_plugin_active')) { include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); }

// Don't allow multiple versions to be active.
if( is_plugin_active('ht-menu/ht-mega-menu.php') ) {
    if ( ! function_exists( 'htmega_menu_deactivate' ) ) {
        function htmega_menu_deactivate() {
            deactivate_plugins( plugin_basename( __FILE__ ) );
        }
    }
    add_action( 'admin_init', 'htmega_menu_deactivate' );

    if ( ! function_exists( 'htmega_menu_lite_notice' ) ) {
        function htmega_menu_lite_notice() {

            echo '<div class="notice notice-warning"><p>' . esc_html__( 'Please deactivate HT Menu Lite before activating HT Menu.', 'htmega-menu' ) . '</p></div>';

            if ( isset( $_GET['activate'] ) ) {
                unset( $_GET['activate'] );
            }
        }
    }
    add_action( 'admin_notices', 'htmega_menu_lite_notice' );
    
    return;
}

if( !class_exists('HTMega_Menu_Elementor') ){
    // Required File
    require_once ( HTMEGA_MENU_PL_PATH.'include/class.mega-menu.php' );
}


// Add settings link on plugin page.
if( !function_exists('htmega_menu_pl_setting_links') ){
    function htmega_menu_pl_setting_links( $links ) {
        $htmega_menu_settings_link = '<a href="admin.php?page=htmegamenu">'.esc_html__( 'Settings', 'htmega-menu' ).'</a>'; 
        $go_pro_link = sprintf('<a href="https://hasthemes.com/ht-mega-menu-for-elementor-page-builder/" target="_blank" style="color: #39b54a; font-weight: bold;">' . esc_html__('Go Pro','htmega-menu') . '</a>');
        array_unshift( $links, $htmega_menu_settings_link, $go_pro_link );
        return $links; 
    } 
    $htmega_menu_plugin_name = plugin_basename(__FILE__); 
    add_filter("plugin_action_links_$htmega_menu_plugin_name", 'htmega_menu_pl_setting_links' );
}

// Plugins After Install
if( !function_exists('htmega_menu_plugin_activate') ){
    register_activation_hook(__FILE__, 'htmega_menu_plugin_activate');
    add_action('admin_init', 'htmega_menu_plugin_redirect_option_page');
    function htmega_menu_plugin_activate() {
        add_option('htmegamenu_do_activation_redirect', true);
    }
    function htmega_menu_plugin_redirect_option_page() {
        if ( get_option('htmegamenu_do_activation_redirect', false) ) {
            delete_option('htmegamenu_do_activation_redirect');
            if( !isset( $_GET['activate-multi'] ) ){
                wp_redirect( admin_url("admin.php?page=htmegamenu") );
            }
        }
    }
}