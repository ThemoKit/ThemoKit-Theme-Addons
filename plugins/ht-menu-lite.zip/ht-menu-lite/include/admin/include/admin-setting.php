<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

if ( ! function_exists('is_plugin_active')){ include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); }

class HTMega_Menu_Admin_Settings {

    private $settings_api;

    function __construct() {
        $this->settings_api = new HTMega_Menu_Settings_API();

        add_action( 'admin_init', array( $this, 'admin_init' ) );
        add_action( 'admin_menu', array( $this, 'admin_menu' ), 220 );
        add_action( 'wsa_form_bottom_htmegamenu_general_tabs', array( $this, 'htmega_menu_html_general_tabs' ) );
        add_action( 'wsa_form_bottom_htmegamenu_template_tabs', array( $this, 'htmega_menu_html_template_library_tabs' ) );
        add_action( 'wsa_form_bottom_htmegamenu_plugins_tabs', array( $this, 'htmega_menu_html_plugins_library_tabs' ) );
    }

    function admin_init() {

        //set the settings
        $this->settings_api->set_sections( $this->htmega_menu_admin_get_settings_sections() );
        $this->settings_api->set_fields( $this->htmega_menu_admin_fields_settings() );

        //initialize settings
        $this->settings_api->admin_init();
    }

    // Plugins menu Register
    function admin_menu() {
        add_menu_page( 
            __( 'HT Menu', 'htmega-menu' ),
            __( 'HT Menu', 'htmega-menu' ),
            'manage_options',
            'htmegamenu',
            array ( $this, 'plugin_page' ),
            'dashicons-welcome-widgets-menus',
            100
        );
    }

    // Options page Section register
    function htmega_menu_admin_get_settings_sections() {
        $sections = array(
            
            array(
                'id'    => 'htmegamenu_general_tabs',
                'title' => esc_html__( 'General', 'htmega-menu' )
            ),

            array(
                'id'    => 'htmegamenu_template_tabs',
                'title' => esc_html__( 'Template', 'htmega-menu' )
            ),

            array(
                'id'    => 'htmegamenu_style_tabs',
                'title' => esc_html__( 'Style', 'htmega-menu' )
            ),

            array(
                'id'    => 'htmegamenu_plugins_tabs',
                'title' => esc_html__( 'Our Plugins', 'htmega-menu' )
            ),

        );
        return $sections;
    }

    // Options page field register
    protected function htmega_menu_admin_fields_settings() {

        $settings_fields = array(

            'htmegamenu_general_tabs' => array(),
            
            'htmegamenu_template_tabs' => array(),

            'htmegamenu_style_tabs' => array(

                array(
                    'name'  => 'menu_items_color',
                    'label' => __( 'Menu Items Color', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Menu Items color.', 'htmega-menu' ),
                    'type' => 'color',
                ),

                array(
                    'name'  => 'menu_items_hover_color',
                    'label' => __( 'Menu Items Hover Color', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Menu Items Hover color.', 'htmega-menu' ),
                    'type' => 'color',
                ),

                array(
                    'name'  => 'sub_menu_width',
                    'label' => __( 'Sub Menu Width', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Sub Menu Width.', 'htmega-menu' ),
                    'min'               => 0,
                    'max'               => 1000,
                    'step'              => '1',
                    'type'              => 'number',
                    'sanitize_callback' => 'floatval'
                ),

                array(
                    'name'  => 'sub_menu_bg_color',
                    'label' => __( 'Sub Menu Background Color', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Menu Background Color.', 'htmega-menu' ),
                    'type' => 'color',
                ),

                array(
                    'name'  => 'sub_menu_items_color',
                    'label' => __( 'Sub Menu Items Color', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Sub Menu Items Color.', 'htmega-menu' ),
                    'type' => 'color',
                ),

                array(
                    'name'  => 'sub_menu_items_hover_color',
                    'label' => __( 'Sub Menu Items Hover Color', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Sub Menu Items Hover Color.', 'htmega-menu' ),
                    'type' => 'color',
                ),

                array(
                    'name'  => 'mega_menu_width',
                    'label' => __( 'Mega Menu Width', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Mega Menu Width.', 'htmega-menu' ),
                    'min'               => 0,
                    'max'               => 1500,
                    'step'              => '1',
                    'type'              => 'number',
                    'sanitize_callback' => 'floatval'
                ),

                array(
                    'name'  => 'mega_menu_bg_color',
                    'label' => __( 'Mega Menu Background Color', 'htmega-menu' ),
                    'desc' => wp_kses_post( 'Mega Menu Background Color.', 'htmega-menu' ),
                    'type' => 'color',
                ),

            ),

            'htmegamenu_plugins_tabs' => array(),


        );
        
        return array_merge( $settings_fields );
    }


    function plugin_page() {

        echo '<div class="wrap">';
            echo '<h2>'.esc_html__( 'HT Menu Settings','htmega-menu' ).'</h2>';
            $this->save_message();
            $this->settings_api->show_navigation();
            $this->settings_api->show_forms();
        echo '</div>';

    }
    function save_message() {
        if( isset($_GET['settings-updated']) ) { ?>
            <div class="updated notice is-dismissible"> 
                <p><strong><?php esc_html_e('Successfully Settings Saved.', 'htmega-menu') ?></strong></p>
            </div>
            <?php
        }
    }

    // General tab
    function htmega_menu_html_general_tabs(){
        ob_start();
        ?>
            <div class="htmegamenu-general-tabs">

                <div class="htmegamenu-document-section">
                    <div class="htmegamenu-column">
                        <a href="https://hasthemes.com/blog-category/ht-mega-menu/" target="_blank">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/video-tutorial.jpg" alt="<?php esc_attr_e( 'Video Tutorial', 'htmega-menu' ); ?>">
                        </a>
                    </div>
                    <div class="htmegamenu-column">
                        <a href="https://hasthemes.com/ht-mega-menu-for-elementor-page-builder-documentation/" target="_blank">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/online-documentation.jpg" alt="<?php esc_attr_e( 'Online Documentation', 'htmega-menu' ); ?>">
                        </a>
                    </div>
                    <div class="htmegamenu-column">
                        <a href="https://hasthemes.com/contact-us/" target="_blank">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/genral-contact-us.jpg" alt="<?php esc_attr_e( 'Contact Us', 'htmega-menu' ); ?>">
                        </a>
                    </div>
                </div>

                <div class="menudifferent-pro-free">
                    <h3 class="htmegamenu-section-title"><?php echo esc_html__( 'HT Menu Free VS HT Menu Pro.', 'htmega-menu' ); ?></h3>

                    <div class="htmegamenu-admin-row">
                        <div class="features-list-area">
                            <h3><?php echo esc_html__( 'HT Menu Free', 'htmega-menu' ); ?></h3>
                            <ul>
                                <li><?php echo esc_html__( 'Menu Template Option', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Individual Menu Width Control Option', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Sub Menu Position', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( '5 Menu Layouts', 'htmega-menu' ); ?></li>
                                <li class="htdel"><del><?php echo esc_html__( 'Menu Icon Picker', 'htmega-menu' ); ?></del></li>
                                <li class="htdel"><del><?php echo esc_html__( 'Menu Icon Color', 'htmega-menu' ); ?></del></li>
                                <li class="htdel"><del><?php echo esc_html__( 'Menu Badge', 'htmega-menu' ); ?></del></li>
                                <li class="htdel"><del><?php echo esc_html__( 'Menu Badge Color', 'htmega-menu' ); ?></del></li>
                                <li class="htdel"><del><?php echo esc_html__( 'Menu Badge Background Color', 'htmega-menu' ); ?></del></li>
                            </ul>
                            <a class="button button-primary" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                        <div class="features-list-area">
                            <h3><?php echo esc_html__( 'HT Menu Pro', 'htmega-menu' ); ?></h3>
                            <ul>
                                <li><?php echo esc_html__( 'Menu Template Option', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Individual Menu Width Control Option', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Sub Menu Position', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( '10 Menu Layouts', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Menu Icon Picker', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Menu Icon Color', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Menu Badge', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Menu Badge Color', 'htmega-menu' ); ?></li>
                                <li><?php echo esc_html__( 'Menu Badge Background Color', 'htmega-menu' ); ?></li>
                            </ul>
                            <a class="button button-primary" href="https://hasthemes.com/ht-mega-menu-for-elementor-page-builder/" target="_blank"><?php echo esc_html__( 'Buy Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                </div>

            </div>
        <?php
        echo ob_get_clean();
    }

    // Template Library
    function htmega_menu_html_template_library_tabs() {
        ob_start();
        ?>
        <div class="htmegamenu-plugins-laibrary">
            <h3><?php echo esc_html__( 'Elementor Template Library', 'htmega-menu' ); ?></h3>
            <p><?php echo esc_html__( 'Use Our Readymade Elementor templates and build your mega menu easily.', 'htmega-menu' ); ?></p>
            <div class="htmegamenu-plugins-area">
                <div class="htmegamenu-plugins-row">
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/menu_layout_1.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout One', 'htmega-menu' ); ?></h3>
                            <a href="https://freethemescloud.com/download/ht-mega-menu-layout-one/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Download', 'htmega-menu' ); ?></a>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/menu_layout_2.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Two', 'htmega-menu' ); ?></h3>
                            <a href="https://freethemescloud.com/download/ht-mega-menu-layout-two/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Download', 'htmega-menu' ); ?></a>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/menu_layout_3.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Three', 'htmega-menu' ); ?></h3>
                            <a href="https://freethemescloud.com/download/ht-mega-menu-layout-three/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Download', 'htmega-menu' ); ?></a>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/menu_layout_4.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Four', 'htmega-menu' ); ?></h3>
                            <a href="https://freethemescloud.com/download/ht-mega-menu-layout-four/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Download', 'htmega-menu' ); ?></a>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/menu_layout_5.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Five', 'htmega-menu' ); ?></h3>
                            <a href="https://freethemescloud.com/download/ht-mega-menu-layout-five/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Download', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>/include/admin/assets/images/menu_layout_6.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Six', 'htmega-menu' ); ?> <span><?php echo esc_html__( '( Pro )','htmega-menu' ); ?></span></h3>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>/include/admin/assets/images/menu_layout_7.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Seven', 'htmega-menu' ); ?> <span><?php echo esc_html__( '( Pro )','htmega-menu' ); ?></span></h3>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>/include/admin/assets/images/menu_layout_8.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Eight', 'htmega-menu' ); ?> <span><?php echo esc_html__( '( Pro )','htmega-menu' ); ?></span></h3>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>/include/admin/assets/images/menu_layout_9.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Nine', 'htmega-menu' ); ?> <span><?php echo esc_html__( '( Pro )','htmega-menu' ); ?></span></h3>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>/include/admin/assets/images/menu_layout_10.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Menu Layout Ten', 'htmega-menu' ); ?> <span><?php echo esc_html__( '( Pro )','htmega-menu' ); ?></span></h3>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php
        echo ob_get_clean();
    }

    // Plugins Library
    function htmega_menu_html_plugins_library_tabs() {
        ob_start();
        ?>
        <div class="htmegamenu-plugins-laibrary">
            <p><?php echo esc_html__( 'Use Our plugins.', 'htmega-menu' ); ?></p>
            <div class="htmegamenu-plugins-area">
                <h3><?php esc_html_e( 'Premium Plugins', 'htmega-menu' ); ?></h3>
                <div class="htmegamenu-plugins-row">
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/preview_woolentor-pro.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WooLentor - WooCommerce Page Builder and WooCommerce Elementor Addon', 'htmega-menu' ); ?></h3>
                            <a href="http://demo.wphash.com/woolentor/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Preview', 'htmega-menu' ); ?></a>
                            <a href="https://hasthemes.com/plugins/woolentor-pro-woocommerce-page-builder/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Buy Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>/include/admin/assets/images/htbuilder_preview.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Builder Pro - WordPress Theme Builder for Elementor', 'htmega-menu' ); ?></h3>
                            <a href="https://hasthemes.com/plugins/ht-builder-wordpress-theme-builder-for-elementor/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Buy Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/hasbarpro-preview.jpg" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HashBar Pro - WordPress Notification Bar plugin', 'htmega-menu' ); ?></h3>
                            <a href="http://demo.wphash.com/hashbar/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Preview', 'htmega-menu' ); ?></a>
                            <a href="https://hasthemes.com/wordpress-notification-bar-plugin/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Buy Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>
                    
                    <div class="htmegamenu-single-plugins"><img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/htscript-preview.png" alt="">
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Script Pro - Insert Header & Footer Code', 'htmega-menu' ); ?></h3>
                            <a href="https://hasthemes.com/plugins/insert-headers-and-footers-code-ht-script/" class="htmegamenu-button" target="_blank"><?php echo esc_html__( 'Buy Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                </div>

                <h3><?php esc_html_e( 'Free Plugins', 'htmega-menu' ); ?></h3>
                <div class="htmegamenu-plugins-row">

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/htmega-addon-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Mega – absolute addons for elementor page builder', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/woolentor-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WooLentor – WooCommerce elementor addons + builder', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/hashbar-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Hashbar – WordPress notification bar', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/portfolio-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Portfolio – wordpress portfolio plugin for elementor', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/contactform-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'Contact form 7 widget for elementor page builder', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/htwpbakery-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Mega – absolute addons for wpbakery page builder', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/slider-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT slider for elementor', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/instagram-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WP Instagram – wordpress instagram feed / widget plugin', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/wpmagazine-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WP News – wordpress news / magazine plugin', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/htteam-member-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WP Team – wordpress team member plugin', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/wpform-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WPforms widget for elementor page builder', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/htevent-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Event – wordpress event manager plugin for elementor', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/politic-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Politic – political wordpress plugin', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/htservice-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'HT Service – roofing service wordpress plugin', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/education-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WP education – education wordpress plugin for elementor', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/film-studio-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WP Film studio – wordpress movie maker/production plugin', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                    <div class="htmegamenu-single-plugins htfree-plugins">
                        <div class="htmegamenu-img">
                            <img src="<?php echo HTMEGA_MENU_PL_URL; ?>include/admin/assets/images/insurance-icon.png" alt="">
                        </div>
                        <div class="htmegamenu-plugins-content">
                            <h3><?php echo esc_html__( 'WP Insurance – WordPress Insurance Service Plugin', 'htmega-menu' ); ?></h3>
                            <a class="htmegamenu-button" href="<?php echo esc_url( admin_url() ); ?>plugin-install.php" target="_blank"><?php echo esc_html__( 'Install Now', 'htmega-menu' ); ?></a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <?php
        echo ob_get_clean();
    }
    

}

new HTMega_Menu_Admin_Settings();