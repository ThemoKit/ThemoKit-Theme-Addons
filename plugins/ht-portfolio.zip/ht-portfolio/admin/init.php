<?php
    require_once HTPORTFOLIO_ADDONS_PL_PATH.'admin/admin-init.php';
    require_once HTPORTFOLIO_ADDONS_PL_PATH.'admin/htportfolio_custom-post-type.php';
    require_once HTPORTFOLIO_ADDONS_PL_PATH.'admin/htportfolio_custom-metabox.php';
   	require_once HTPORTFOLIO_ADDONS_PL_PATH.'admin/class.settings-api.php';
	require_once HTPORTFOLIO_ADDONS_PL_PATH.'admin/plugin-options.php';
    
?>