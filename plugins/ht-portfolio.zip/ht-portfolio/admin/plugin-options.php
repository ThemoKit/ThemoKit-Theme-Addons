<?php
/**
 * WordPress settings API demo class
 *
 * @author Tareq Hasan
 */
if ( !class_exists('HTPortfolio_Settings_API_Options' ) ):
class HTPortfolio_Settings_API_Options {

    private $settings_api;

    function __construct() {
        $this->settings_api = new HTPortfolio_Settings_API;

        add_action( 'admin_init', array($this, 'admin_init') );
        add_action( 'admin_menu', array($this, 'admin_menu') );
    }

    function admin_init() {

        //set the settings
        $this->settings_api->set_sections( $this->get_settings_sections() );
        $this->settings_api->set_fields( $this->htportfolio_get_settings_fields() );

        //initialize settings
        $this->settings_api->admin_init();
    }

    function admin_menu() {
        add_submenu_page( 'htportfolio_menu', 'Settings', 'Settings', 'manage_options', 'htportfolio_options', array($this, 'htportfolio_options_page') );
    }

    function get_settings_sections() {
        $sections = array(
            array(
                'id'    => 'htportfolio_settings',
                'title' => __( 'Portfolio Options', 'htportfolio' )
            ),
            array(
                'id'    => 'htportfolio_pro_themes',
                'title' => __( 'Pro Theme using this plugins.', 'htportfolio' ),
            )
        );

        return $sections;
    }

    /**
     * Returns all the settings fields
     *
     * @return array settings fields
     */
    function htportfolio_get_settings_fields() {
        $htportfolio_settings_fields = array(
            'htportfolio_settings' => array(
                array(
                    'name'              => 'htportfolio_related_title_text',
                    'label'             => __( 'Related Portfolio', 'htportfolio' ),
                    'desc'              => __( 'Text input description', 'htportfolio' ),
                    'placeholder'       => __( 'Related Portfolio', 'htportfolio' ),
                    'type'              => 'text',
                    'default'           => 'Related Portfolio',
                    'sanitize_callback' => 'sanitize_text_field'
                ),
                array(
                    'name'    => 'htportfolio_desc_text',
                    'label'   => __( 'Description Text Show/Hide', 'htportfolio' ),
                    'desc'    => __( 'Dropdown Options', 'htportfolio' ),
                    'type'    => 'select',
                    'default' => 'yes',
                    'options' => array(
                        'yes' => 'Show',
                        'no'  => 'Hide'
                    )
                ),
                array(
                    'name'    => 'htportfolio_thumbimage_show',
                    'label'   => __( 'Featured Image Show/Hide', 'htportfolio' ),
                    'desc'    => __( 'Dropdown Options', 'htportfolio' ),
                    'type'    => 'select',
                    'default' => 'yes',
                    'options' => array(
                        'yes' => 'Show',
                        'no'  => 'Hide'
                    )
                ),
                array(
                    'name'    => 'htportfolio_title_text',
                    'label'   => __( 'Portfolio Title Show/Hide', 'htportfolio' ),
                    'desc'    => __( 'Dropdown Options', 'htportfolio' ),
                    'type'    => 'select',
                    'default' => 'yes',
                    'options' => array(
                        'yes' => 'Show',
                        'no'  => 'Hide'
                    )
                ),
                array(
                    'name'    => 'htportfolio_info_show',
                    'label'   => __( 'Portfolio Info Show/Hide', 'htportfolio' ),
                    'desc'    => __( 'Dropdown Options', 'htportfolio' ),
                    'type'    => 'select',
                    'default' => 'yes',
                    'options' => array(
                        'yes' => 'Show',
                        'no'  => 'Hide'
                    )
                ),
                array(
                    'name'    => 'htportfolio_related_post_show',
                    'label'   => __( 'Related Post Show/Hide', 'htportfolio' ),
                    'desc'    => __( 'Dropdown Options', 'htportfolio' ),
                    'type'    => 'select',
                    'default' => 'yes',
                    'options' => array(
                        'yes' => 'Show',
                        'no'  => 'Hide'
                    )
                ),
            ),

        );

        return $htportfolio_settings_fields;
    }

    function htportfolio_options_page() {
        echo '<div class="wrap">';

        $this->settings_api->show_navigation();

        echo '<h2 class="nav-tab-wrapper"><a href="#htportfolio_settings" class="nav-tab" id="settings-tab">Settings</a><a href="#htportfolio_pro_themes" class="nav-tab nav-tab-active" id="pro_themes-tab">Pro Themes</a></h2>';

        $this->settings_api->show_forms();

        echo '</div>';
    }

    /**
     * Get all the pages
     *
     * @return array page names with key value pairs
     */
    function get_pages() {
        $pages = get_pages();
        $pages_options = array();
        if ( $pages ) {
            foreach ($pages as $page) {
                $pages_options[$page->ID] = $page->post_title;
            }
        }

        return $pages_options;
    }

}
endif;

new HTPortfolio_Settings_API_Options();