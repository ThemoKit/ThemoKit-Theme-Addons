<?php
    // HTPortfolio options menu
    if ( ! function_exists( 'htportfolio_add_adminbar_menu' ) ) {
        function htportfolio_add_adminbar_menu() {
            $menu = 'add_menu_' . 'page';
            $menu( 
                'htportfolio_panel', 
                esc_html__( 'HT Portfolio', 'htportfolio' ), 
                'read', 
                'htportfolio_menu', 
                NULL, 
                'dashicons-images-alt2', 
                40 
            );
        }
    }
    add_action( 'admin_menu', 'htportfolio_add_adminbar_menu' );

if(!function_exists('htportfolio_pagination')){
    function htportfolio_pagination(){
        ?>
        <div class="htportfolio-pagination"> <?php
            the_posts_pagination(array(
                'prev_text'          => '<i class="fa fa-angle-left"></i>',
                'next_text'          => '<i class="fa fa-angle-right"></i>',
                'type'               => 'list'
            )); ?>
        </div>
        <?php
    }
}

if( !function_exists('htportfolio_post_count_on_archive') ){
    function htportfolio_post_count_on_archive( $query ) {
        if(is_archive()){
            $per_pages = (int)htportfolio_get_option( 'htportfolio_posts_per_page', 'htportfolio_settings' );

            if ( $query->is_archive( 'htportfolio' ) ) {
                $query->set( 'posts_per_page', $per_pages); /*set this your preferred count*/
            }
        }
    }
    add_action( 'pre_get_posts', 'htportfolio_post_count_on_archive' );
}