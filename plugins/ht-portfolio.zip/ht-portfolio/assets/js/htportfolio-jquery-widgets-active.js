(function($){
"use strict";

})(jQuery);