﻿=== HT Portfolio - WordPress Portfolio Plugin for Elementor ===
Contributors: htplugins, devitemsllc
Tags: Portfolio, Masonary Portfolio, Portfolio Gallery, Gallery, Filterable Portfolio.
Requires at least: 3.1
Tested up to: 5.2.3
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

HT Portfolio - WordPress Portfolio Plugin for Elementor 

== Description ==
HT Portfolio - Is a handy tool that comes to assist you bring ease and perfection. We presume that you are bogged down with handling lots of other stuffs and you need to have e tool that will make your works easier than ever. We are here with HT Portfolio - WordPress Portfolio Plugin for Elementor Plugin for you.

HT Portfolio is an excellent Elementor Plugin with tons of beautiful features. It has Masonary Portfolio, Filterable Portfolio, Portfolio Gallery, Easy Portfolio, Category based Portfolio items and Portfolio Settings. You can show the Numbering, Title, Category, Icon, Category-wise Portfolio or even you can hide them.

However, setting multiple columns has also been a piece of cake through HT Portfolio. You can create multiple columns like 1 Column, 2 Column, 3 Column and 4 Column etc. using this plugin.

In addition, you don’t need to have any coding knowledge to work with this plugin. Clean design and smart code will strengthen your website. This Bootstrap 4 based elementor plugin has Portfolio Detail page, Onclick Lightbox on The Gallery, Video Option, Font Awesome Icon, Unlimited Color Options, Featured Image Support etc.

Furthermore, HT Portfolio is 100% Responsive and has mobile-ready layout as well as cross-browser compatibility. Install HT Portfolio elementor plugins right now and enjoy a hassle-free smooth website management. We are here to support you too with the best of our experience and dedication.

A theme using HT Portfolio Plugin : [Live Demo](http://demo.shrimpthemes.com/5/vargas/)

== Features: ==
* Masonary Portfolio.
* Filterable Portfolio.
* Portfolio Gallery.
* Easy Portfolio/Gallery Option Page.
* Category Based Portfolio Item.
* Portfolio Settings.
* Multiple Column Layout.
* Numbering – Show Numbering System.
* Title,Catogory,Icon – Show/Hide Option.
* Catogory Selection Wise Portfolio Show/Hide Option.
* Show/Hide Filters.
* Unlimited Filter Colors.
* Portfolio Masonry Gallery.
* Link Portfolio Gallery.
* Spacing or Without Spacing – Show Portfolio Gallery With and Without Spacing.
* Portfolio Gallery Images Order Buttons Like Ascending, Descending & Shuffle.
* Set Multiple Column Layouts Like 1 Column, 2 Column, 3 Column, 4 Column.
* Onclick Lightbox On The Gallery.
* Video Option Portfolio/Gallery.
* Easily Customizable Portfolio.
* Portfolio Details Page.
* Fully Responsive and Mobile Ready.
* Clean Design & Code.
* No Coding Required.
* Bootstrap Framework Based.
* FontAwesome Icon.
* Image Icon Support.
* Fetured Image Support.
* Customize the Number of Columns.
* Cross-browser Compatibility.
* Build With HTML5 & CSS3.
* Unlimited Color Options.

== Need Help? ==
Is there any feature that you want to get in this plugin? 
Needs assistance to use this plugin? 
Feel free to [Contact us](https://htplugins.com/contact-us/)

== <a href="https://wordpress.org/plugins/elementor/">Elementor</a> page builder is required to use addons in this plugin. ==

HT Portfolio - WordPress Portfolio Plugin for Elementor has the following third-party resources:

1. CMB2:
Source: [cmb2](https://wordpress.org/plugins/cmb2/)


== Installation ==
This section describes how to install the HT Portfolio - WordPress Portfolio Plugin for Elementor and get it working.

= 1) Install =

= Modern Way: =
1. Go to the WordPress Dashboard "Add New Plugin" section.
2. Search For "HT Portfolio ".
3. Install, then Activate it.

= Old Way: =
1. Unzip (if it is zipped) and Upload `ht-portfolio` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

= 2) Configure =
1. After install and activate the plugin you will get a notice to install CMB2 Plugin ( If allready install it then do not show notice. ).
2. To install the plugin click on the "Button" Install CMB2.
3. After install and activate the both plugin you will get a Dashboard Menu(HT Portfolio).