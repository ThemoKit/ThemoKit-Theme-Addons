<?php
/**
 * Plugin Name: HT Portfolio
 * Description: The Portfolio For WP Widget Elementor is a elementor addons for WordPress. 
 * Plugin URI: https://htplugins.com/
 * Version: 1.0.2
 * Author: HT Plugins
 * Author URI: https://profiles.wordpress.org/htplugins/
 * License:  GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: htportfolio
*/


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'HTPORTFOLIO_VERSION', '1.0.0' );
define( 'HTPORTFOLIO_ADDONS_PL_URL', plugins_url( '/', __FILE__ ) );
define( 'HTPORTFOLIO_ADDONS_PL_PATH', plugin_dir_path( __FILE__ ) );
define( 'HTPORTFOLIO_ADDONS_PL_ROOT', __FILE__ );

// Required File
require_once HTPORTFOLIO_ADDONS_PL_PATH.'includes/helper-function.php';
require_once HTPORTFOLIO_ADDONS_PL_PATH.'init.php';
require_once HTPORTFOLIO_ADDONS_PL_PATH.'admin/init.php';


// Portfolio Single page
add_filter('single_template', 'htportfolio_single_portfolio_template_modify');

function htportfolio_single_portfolio_template_modify($single) {

    global $post;

    /* Checks for single template by post type */
    if ( $post->post_type == 'ht_portfolios' ) {
        if ( file_exists( HTPORTFOLIO_ADDONS_PL_PATH . '/includes/single-ht_portfolios.php' ) ) {
            return HTPORTFOLIO_ADDONS_PL_PATH . '/includes/single-ht_portfolios.php';
        }
    }
    return $single;
}

/**
 * Get the value of a settings field
 *
 * @param string $option settings field name
 * @param string $section the section name this field belongs to
 * @param string $default default text if it's not found
 *
 * @return mixed
 */
function htportfolio_get_option( $option, $section, $default = '' ) {

    $options = get_option( $section );

    if ( isset( $options[$option] ) ) {
        return $options[$option];
    }

    return $default;
}

// Check Plugins is Installed or not
function htportfolio_is_plugins_active( $pl_file_path = NULL ){
    $installed_plugins_list = get_plugins();
    return isset( $installed_plugins_list[$pl_file_path] );
}
// This notice for Elementor is not installed or activated or both.
function htportfolio_check_elementor_status(){
    $elementor = 'elementor/elementor.php';
    if( htportfolio_is_plugins_active($elementor) ) {
        if( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }
        $activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $elementor . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $elementor );
        $message = __( '<strong>HT Portfolio Addons for Elementor</strong> Requires Elementor plugin to be active. Please activate Elementor to continue.', 'htportfolio' );
        $button_text = __( 'Activate Elementor', 'htportfolio' );
    } else {
        if( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }
        $activation_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );
        $message = sprintf( __( '<strong>htportfolio Addons for Elementor</strong> requires %1$s"Elementor"%2$s plugin to be installed and activated. Please install Elementor to continue.', 'htportfolio' ), '<strong>', '</strong>' );
        $button_text = __( 'Install Elementor', 'htportfolio' );
    }
    $button = '<p><a href="' . $activation_url . '" class="button-primary">' . $button_text . '</a></p>';
    printf( '<div class="error"><p>%1$s</p>%2$s</div>', __( $message ), $button );
}

if( ! did_action( 'elementor/loaded' ) ) {
    add_action( 'admin_init', 'htportfolio_check_elementor_status' );
}
// This notice for Cmb2 is not installed or activated or both.
function htportfolio_check_cmb2_status(){
    $cmb2 = 'cmb2/init.php';

    if( htportfolio_is_plugins_active($cmb2) ) {
        if( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }
        $activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $cmb2 . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $cmb2 );
        $message = __( '<strong>HT Portfolio Plugin</strong> Requires Cmb2 plugin to be active. Please activate Cmb2 to continue.', 'htportfolio' );
        $button_text = __( 'Activate CMB2', 'htportfolio' );
    } else {
        if( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }
        $activation_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=cmb2' ), 'install-plugin_cmb2' );
        $message = sprintf( __( '<strong>htportfolio Addons for Cmb2</strong> requires %1$s"Cmb2"%2$s plugin to be installed and activated. Please install Cmb2 to continue.', 'htportfolio' ), '<strong>', '</strong>' );
        $button_text = __( 'Install Cmb2', 'htportfolio' );
    }
    $button = '<p><a href="' . $activation_url . '" class="button-primary">' . $button_text . '</a></p>';
    printf( '<div class="error"><p>%1$s</p>%2$s</div>', __( $message ), $button );
}


if( ! defined( 'CMB2_LOADED' )) {
    add_action( 'admin_init', 'htportfolio_check_cmb2_status' );
}

/*
 * Display tabs related to gallery in admin when user
 * viewing/editing gallery/category.
 */
function htportfolio_gallery_tabs() {
    if ( ! is_admin() ) {
        return;
    }
    $admin_tabs = apply_filters(
        'htportfolio_gallery_tabs_info',
        array(

            10 => array(
                "link" => "edit.php?post_type=htportfolio_gallery",
                "name" => __( "Gallery", "htportfolio" ),
                "id"   => "edit-htportfolio_gallery",
            ),

            20 => array(
                "link" => "edit-tags.php?taxonomy=htportfolio_gallery_cat&post_type=htportfolio_gallery",
                "name" => __( "Categories", "htportfolio" ),
                "id"   => "edit-htportfolio_gallery_cat",
            ),

        )
    );
    ksort( $admin_tabs );
    $tabs = array();
    foreach ( $admin_tabs as $key => $value ) {
        array_push( $tabs, $key );
    }
    $pages = apply_filters(
        'htportfolio_gallery_admin_tabs_on_pages',
        array( 'edit-htportfolio_gallery', 'edit-htportfolio_gallery_cat', 'edit-gallery_tag', 'htportfolio_gallery' )
    );
    $admin_tabs_on_page = array();
    foreach ( $pages as $page ) {
        $admin_tabs_on_page[ $page ] = $tabs;
    }
    $current_page_id = get_current_screen()->id;
    $current_user    = wp_get_current_user();
    if ( ! in_array( 'administrator', $current_user->roles ) ) {
        return;
    }
    if ( ! empty( $admin_tabs_on_page[ $current_page_id ] ) && count( $admin_tabs_on_page[ $current_page_id ] ) ) {
        echo '<h2 class="nav-tab-wrapper lp-nav-tab-wrapper">';
        foreach ( $admin_tabs_on_page[ $current_page_id ] as $admin_tab_id ) {

            $class = ( $admin_tabs[ $admin_tab_id ]["id"] == $current_page_id ) ? "nav-tab nav-tab-active" : "nav-tab";
            echo '<a href="' . admin_url( $admin_tabs[ $admin_tab_id ]["link"] ) . '" class="' . $class . ' nav-tab-' . $admin_tabs[ $admin_tab_id ]["id"] . '">' . $admin_tabs[ $admin_tab_id ]["name"] . '</a>';
        }
        echo '</h2>';
    }
}

if(isset($_GET['post_type']) && $_GET['post_type'] == 'htportfolio_gallery'){
    add_action( 'all_admin_notices', 'htportfolio_gallery_tabs' );
}



/*
 * Display tabs related to Portfolio in admin when user
 * viewing/editing Portfolio/category.
 */
function ht_portfolios_tabs() {
    if ( ! is_admin() ) {
        return;
    }
    $admin_tabs = apply_filters(
        'ht_portfolios_tabs_info',
        array(

            10 => array(
                "link" => "edit.php?post_type=ht_portfolios",
                "name" => __( "Portfolio", "htportfolio" ),
                "id"   => "edit-ht_portfolios",
            ),

            20 => array(
                "link" => "edit-tags.php?taxonomy=ht_portfolios_cat&post_type=ht_portfolios",
                "name" => __( "Categories", "htportfolio" ),
                "id"   => "edit-ht_portfolios_cat",
            ),

        )
    );
    ksort( $admin_tabs );
    $tabs = array();
    foreach ( $admin_tabs as $key => $value ) {
        array_push( $tabs, $key );
    }
    $pages = apply_filters(
        'ht_portfolios_admin_tabs_on_pages',
        array( 'edit-ht_portfolios', 'edit-ht_portfolios_cat', 'edit-portfolio_tag', 'ht_portfolios' )
    );
    $admin_tabs_on_page = array();
    foreach ( $pages as $page ) {
        $admin_tabs_on_page[ $page ] = $tabs;
    }

    $current_page_id = get_current_screen()->id;
    $current_user    = wp_get_current_user();
    if ( ! in_array( 'administrator', $current_user->roles ) ) {
        return;
    }
    if ( ! empty( $admin_tabs_on_page[ $current_page_id ] ) && count( $admin_tabs_on_page[ $current_page_id ] ) ) {
        echo '<h2 class="nav-tab-wrapper lp-nav-tab-wrapper">';
        foreach ( $admin_tabs_on_page[ $current_page_id ] as $admin_tab_id ) {

            $class = ( $admin_tabs[ $admin_tab_id ]["id"] == $current_page_id ) ? "nav-tab nav-tab-active" : "nav-tab";
            echo '<a href="' . admin_url( $admin_tabs[ $admin_tab_id ]["link"] ) . '" class="' . $class . ' nav-tab-' . $admin_tabs[ $admin_tab_id ]["id"] . '">' . $admin_tabs[ $admin_tab_id ]["name"] . '</a>';
        }
        echo '</h2>';
    }
}

if(isset($_GET['post_type']) && $_GET['post_type'] == 'ht_portfolios'){
    add_action( 'all_admin_notices', 'ht_portfolios_tabs' );
}
add_action( 'wsa_form_bottom_htportfolio_pro_themes', 'htportfolio_pro_tab_advertise' );

function htportfolio_pro_tab_advertise(){

        echo '<h3> <a target="_blank" href="#">
        Vargas – Multipurpose WordPress Theme</a></h3> <a target="_blank" href="#"><img alt="Roofing Service" src="#"></a>';
}