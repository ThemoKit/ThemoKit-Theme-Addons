=== Happy Elementor Addons ===
Plugin Name: Happy Elementor Addons
Version: 2.3.0
Author: weDevs
Author URI: https://happyaddons.com/
Contributors: thehappymonster, happyaddons, hasinhayder, mosaddek73, tareq1988, sourav926, wedevs, iqbalrony, obiplabon
Tags: elementor, elementor addon, elementor widget, essential widget, elements
Requires at least: 4.7
Tested up to: 5.2.4
Stable tag: trunk
Requires PHP: 5.4
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

[HappyAddons](https://happyaddons.com/) is a collection of slick, powerful widgets that works seamlessly with Elementor page builder. It’s trendy look with detail customization features allows to create extraordinary designs instantly. [HappyAddons](https://happyaddons.com/) is free, rapidly growing and comes with great support.

== Description ==

[HappyAddons](https://happyaddons.com/) is a collection of slick, powerful widgets that works seamlessly with Elementor page builder. It’s trendy look with detail customization features allows to create extraordinary designs instantly. [HappyAddons](https://happyaddons.com/) is free, rapidly growing and comes with great support.

https://www.youtube.com/watch?v=XpWm7zdvUoM

> HappyAddons is a unique Elementor Addon
   — Adam Preiser, Founder of WP Crafter

### Included 25 Free Widgets

1. **[Card](https://demo.happyaddons.com/elementor-card-widget-demo/)** - Incredibly powerful widget to demonstrate your products, articles, news, creative posts using a beautiful combination of texts, links, badge and image. Using built in positioning and offset feature you can create eye-candy designs in a twist. [Check demo](https://demo.happyaddons.com/elementor-card-widget-demo/)
2. **[Gradient Heading](https://demo.happyaddons.com/elementor-gradient-heading-widget-demo/)** - Another gem to create eye candy headings for your websites. You can apply different gradient styles, angles, opacity, and positions to make them look even better across different device screens. [Check demo](https://demo.happyaddons.com/elementor-gradient-heading-widget-demo/)
3. **[Info Box](https://demo.happyaddons.com/elementor-info-box-widget-demo/)** - Create beautiful information boxes using icons, links and texts, and make them slick using the built in positioning features. [Check demo](https://demo.happyaddons.com/elementor-info-box-widget-demo/)
4. **[Icon Box](https://demo.happyaddons.com/elementor-icon-box-widget-demo/)** - A simplified version of Info box but comes with powerful display features. Perfect for showcasing interesting information to your users in various styles. [Check demo](https://demo.happyaddons.com/elementor-icon-box-widget-demo/)
5. **[Image Compare](https://demo.happyaddons.com/elementor-image-compare-widget-demo/)** - Are you a photo-editor, agency or product designer who often needs to showcase their beautiful works in a form of before and after slider? This widget is perfect for this job. And built in styling options, vertical and horizontal orientation features can help you design these before-after sections with more creativity. [Check demo](https://demo.happyaddons.com/elementor-image-compare-widget-demo/)
6. **[Team Member](https://demo.happyaddons.com/elementor-team-member-widget-demo/)** - A perfect widget to showcase your beautiful team in various styles using texts, images, and social links. And just like our other widgets, you will find powerful styling options to make them stand out quite easily. [Check demo](https://demo.happyaddons.com/elementor-team-member-widget-demo/)
7. **[Review](https://demo.happyaddons.com/elementor-review-widget-demo/)** - Showcase your user feedback, reviews and rating easily than ever using our review widget. Display user photo, texts and star ratings. Make them stand out using built in offsets and positioning features. [Check demo](https://demo.happyaddons.com/elementor-review-widget-demo/)
8. **[Skill Bars](https://demo.happyaddons.com/elementor-skill-bars-widget-demo/)** - An essential building block to showcase user skills, task percentage, required tools and other progressive information in different ways. Comes with incredible customizing options to suit your needs. [Check demo](https://demo.happyaddons.com/elementor-skill-bars-widget-demo/)
9. **[Contact Form 7](https://demo.happyaddons.com/elementor-contact-form-7-widget-demo/)** - This utility widget helps you to integrate existing forms built using CF7 plugin across your web pages without spending too much time. [Check demo](https://demo.happyaddons.com/elementor-contact-form-7-widget-demo/)
10. **[ Caldera Forms](https://demo.happyaddons.com/elementor-caldera-forms-widget-demo/)** - This widget can help you to display your caldera forms to display on your web pages designed with Elementor. [Check demo](https://demo.happyaddons.com/elementor-caldera-forms-widget-demo/)
11. **[weForms](https://demo.happyaddons.com/elementor-we-forms-widget-demo/)** - Designed forms using weForms plugin and looking for a way to display those on your Elementor powered pages? This is the answer for that. [Check demo](https://demo.happyaddons.com/elementor-we-forms-widget-demo/)
12. **[Ninja Forms](https://demo.happyaddons.com/elementor-ninja-form-widget-demo/)** - Use this widget to embed forms created using Ninja Forms to display seamlessly on your web pages. Various styling options will help you to look at them even better. [Check demo](https://demo.happyaddons.com/elementor-ninja-form-widget-demo/)
13. **[WPForms](https://demo.happyaddons.com/elementor-wpform-widget-demo/)** - Use this widget to embed forms created using WPForms to display seamlessly on your web pages. Various styling options will help you to look at them even better. [Check demo](https://demo.happyaddons.com/elementor-wpform-widget-demo/)
14. **[Dual Button](https://demo.happyaddons.com/elementor-dual-button-widget-demo/)** - DualButton widget allows you to add two flexible and trendy action buttons in your sections, in different styles. [Check demo](https://demo.happyaddons.com/elementor-dual-button-widget-demo/)
15. **[Testimonial](https://demo.happyaddons.com/elementor-testimonial-widget-demo/)** - Create beautiful testimonial sections with different look-n-feels using HappyAddons Testimonial widget. [Check demo](https://demo.happyaddons.com/elementor-testimonial-widget-demo/)
16. **[Justified Grid](https://demo.happyaddons.com/elementor-justified-grid-widget-demo/)** - Another pro grade widget which can help you to create beautiful justified grid. Comes packed with tons of options to make it stand out from the crowd. [Check demo](https://demo.happyaddons.com/elementor-justified-grid-widget-demo/)
17. **[Number](https://demo.happyaddons.com/elementor-number-widget-demo/)** - Simply beautiful, this widget can help you create stunning number blocks with various styles, look-n-feels that’s literally going to blow your mind. [Check demo](https://demo.happyaddons.com/elementor-number-widget-demo/)
18. **[Logo Grid](https://demo.happyaddons.com/elementor-logo-grid-widget-demo)** - Showcase your clients or products using our logo grid widget, and display these items with styles. [Check demo](https://demo.happyaddons.com/elementor-logo-grid-widget-demo)
19. **[Carousel](https://demo.happyaddons.com/elementor-carousel-widget-demo/)** - Create interesting image and text carousels using our carousel widget which comes with lot of options. [Check demo](https://demo.happyaddons.com/elementor-carousel-widget-demo/)
20. **[Slider](https://demo.happyaddons.com/elementor-slider-widget-demo/)** - Now you can create sliders with beautiful animations and effects using our Slider widget. And just like our other widgets, there are lots of customization options for you. [Check demo](https://demo.happyaddons.com/elementor-slider-widget-demo/)
21. **[Step Flow](https://demo.happyaddons.com/elementor-step-flow-widget-demo/)** - Create excellent step by step visual diagram and instructions using this smart widget. Change directions, counters and make them look amazing with icons, texts and colors. [Check demo](https://demo.happyaddons.com/elementor-step-flow-widget-demo/)
22. **[Calendly](https://demo.happyaddons.com/elementor-calendly-widget-demo/)** - Schedule meetings without the back-and-forth emails through Calendly. We are happy to integrate this important application in our HappyAddons. [Check demo](https://demo.happyaddons.com/elementor-calendly-widget-demo/)
23. **[Flip Box](https://demo.happyaddons.com/elementor-flip-box-widget-demo/)** - FlipBox helps you to deliver messages in a beautiful way with before and after effects. [Check demo](https://demo.happyaddons.com/elementor-flip-box-widget-demo/)
24. **[Pricing Table](https://demo.happyaddons.com/elementor-pricing-table-widget-demo/)** - Create beautiful pricing tables with lots of customizations and sleek look-n-feel using this widget. [Check demo](https://demo.happyaddons.com/elementor-pricing-table-widget-demo/)
25. **[Image Grid](https://demo.happyaddons.com/elementor-image-grid-widget-demo/)** - Simply beautiful, this widget can help you create stunning number blocks with various styles, look-n-feels that’s literally going to blow your mind. [Check demo](https://demo.happyaddons.com/elementor-image-grid-widget-demo/)

### INCLUDED FREE EXTENSIONS FOR EVERY ELEMENTOR WIDGET

**Happy Extensions**

1. **Background Overlay** - You can add background overlay to any widget now.
2. **Happy Icons** - Custom icon fonts library.

**Happy Effects**

1. **[Floating Effects](https://demo.happyaddons.com/elementor-floating-effect-demo/)** - Now you can create stunning animations for any Elementor widget using Floating Effects. Translate, Rotate or Scale - Imagination is the limit!
2. **[CSS Transform](https://demo.happyaddons.com/elementor-css-transform-demo/)** - Another missing piece, a great enhancement over core Elementor that works seamlessly with every widget. You can now apply various CSS transforms like translate, rotate, scale and skew without any limitations.

https://www.youtube.com/watch?v=LmtacsLcFPU

**Space Effects Using Floating Effects**

https://www.youtube.com/watch?v=F33g3zqkeog

### Features

The widgets in [HappyAddons](https://happyaddons.com/) are well tested on different devices to give you the best responsive output. Our code doesn’t stink and we don’t leave you blind folded when you need support from us. Before jumping into the details, let’s have a look at the features at a glance

* Just because it’s free, we don’t compromise with the quality at all. You’re still getting the same carefully crafted collection of widgets that you get elsewhere which comes for a price
* Responsive and tested on different screens to ensure it doesn’t break
* Compatible with almost every themes out there. In case of any exception, let us know and we will fix it for you
* Comes with demo designs so that you can quickly copy the styles without spending too much to design everything from scratch
* Ever growing, which means that we’re constantly adding new features and widgets to this collection every week
* Comes with excellent support, and that is sweet. If you don’t understand a feature, or fail to give it a desired look which was already demonstrated in a demo, or it’s not working as expected - we got your back. Just drop us a line and we will do our best to help you figure a way out.
* Lightweight and fast. The widgets are carefully designed to remain fat-less and bloat free. We understand how important it is to serve your page faster and we took extra care for that
* Comes with cohesive elements, which means that these widgets are so customizable that you can easily fit them in your existing designs, and they work nicely together with each other without making anything look bad.
* [HappyAddons](https://happyaddons.com/) brings you some powerful features to the built-in motion effects section that helps you to animate and rotate objects on their x-axis, y-axis, and z-axis like never seen before, and brings lovely effects to help your websites stand out from others.

### Bugs, technical hints or contribute ###

Please give us feedback, contribute and file technical bugs on [GitHub Repo](https://github.com/weDevsOfficial/happy-elementor-addons/issues).


== Frequently Asked Questions ==

= Can I use Happy Elementor Addons without Elementor? =

I'm afraid, you cannot use **[Happy Elementor Addons](https://happyaddons.com/)** without Elementor. Happy Elementor Addons is a collection of slick, powerful widgets that works seamlessly with Elementor page builder and it's only for Elementor.

= Does it work along with other Elementor Addons? =

Yes, it does. And you'll get some cool and extra features like Happy Effects for other Elementor Addons or Extensions.

= Does it work with any WordPress theme? =

Yes, it works with any WordPress theme that works with Elementor. And it best works with [Hello Elementor](https://wordpress.org/themes/hello-elementor/).

= Does it work with Elementor Pro? =

Yes, undoubtedly.

= Will Happy Elementor Addons break my site after an update? =

No, It won't break your site or any page where you used Happy Elementor Addons. We put our best effort to make you happy.


== Screenshots ==

1. Review widget with image offset
2. Icon box widget - capsule design
3. Team member widget
4. Info box widget
5. Skill bars widget
6. Dual button widget
7. Icon box widget with label
8. Happy Effects - available in all kinds of Elementor widgets. And works smoothly with all the 3rd party Elementor addons plugin, Elementor Pro and Elementor
9. Happy Effects - CSS Transform - Rotate
10. happy Effects - CSS Transform - Rotate and Translate
11. Review widget - capsule design
12. Card widget with Happy Effects (Floating Effects)
13. Card widget - capsule design

== Installation ==

It's really easy and super simple to install **Happy Elementor Addons** plugin but before installing **Happy Elementor Addons** make sure you've installed [Elementor](https://wordpress.org/plugins/elementor/ "Install Elementor"). **Elementor** is the only dependency.

= Automatic Installation =
1.  Go to `Plugins > Add New` screen in WordPress.
2.  Search for `Happy Addons For Elementor`.
3.  Install and activate the plugin, that's it.

= Manual Installation =
1.  Download [Happy Elementor Addons](https://downloads.wordpress.org/plugin/happy-elementor-addons.zip "Download Happy Elementor Addons").
2.  Extract the `happy-elementor-addons.zip` file. You'll get plugin files inside `happy-elementor-addons` directory.
3.  Upload the plugin files to the `/wp-content/plugins/happy-elementor-addons` directory.
4.  Activate the plugin through the 'Plugins' screen in WordPress.


== Changelog ==

= 2.3.0 - 20 November 2019 =

- New: Gravity Forms Widget
- New: Column Order control
- New: Custom Column Width control
- New: weForms section break styles
- Fix: weForms misc style issues

= 2.2.6 - 11 November 2019 =

- Fix: Conflict with Essential Addons causing PHP fatal error
- Fix: PHP cannot declare class `Happy_Addons\Elementor\Finder` issue

= 2.2.5 - 11 November 2019 =

- Tweak: Improved floating effects editing performance
- Fix: Text editor slow performance and rendering lag issue

= 2.2.4 - 8 November 2019 =

- Tweak: Improved on demand assets loading for Elementor theme builder
- Tweak: Improved support for 3rd party header, footer builders
- Fix: Dashboard php error for users with non admin or super admin roles

= 2.2.3 - 6 November 2019 =

- Tweak: Improved support for image optimization plugins. ex: Shortpixel Image Optimiser
- Tweak: Widgets default styles
- Fix: WPForms Pro compatibility issue
- Fix: Image border radius style issue

= 2.2.2 - 16 October 2019 =

- Fix: Widget Control Panel link issue

= 2.2.1 - 15 October 2019 =

- Fix: Text overflow issue in all widgets
- Fix: PHP 5.4 compatibility issue

= 2.2.0 - 7 October 2019 =

- Update: Style copy-paste support improved
- Fix: Image Grid image alt attribute value issue
- Fix: Justified Gallery image alt attribute value issue
- Fix: Skills Bar % sign visibility inconsistency issue

= 2.1.0 - 3 October 2019 =

- New: Widgets control panel link in Elementor Finder
- New: Widgets control panel link in Elementor editor panel
- Update: Added Dual Button layout (Stack and Queue layout)
- Fix: Image Grid and Justified Gallery filter issue for non english languages
- Fix: Justified gallery image alt attribute missing issue
- Fix: Dual Button responsive issue - using layout feature
- Fix: Dual Button default hover text color
- Fix: Widgets Control Panel navigation jump issue

= 2.0.0 - 24 September 2019 =

- New: Dashboard - Widgets Control Panel
- New: Image popup support for Justified Grid
- New: Image popup support for Image Grid
- Update: Improved HTML tag support for description and title fields
- Update: Added more icons in Happy Icons
- Update: Improved HTML escaping support for security
- Fix: Skill Bars admin label fix
- Fix: Missing style issue while copy-pasting widget style
- Fix: Happy Icons cache issue
- Fix: Admin bar menu spacing issue
