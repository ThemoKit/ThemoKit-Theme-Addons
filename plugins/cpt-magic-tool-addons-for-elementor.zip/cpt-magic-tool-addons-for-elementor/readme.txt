=== Elementor CPT Magic Tool ===
Contributors: muzammilmotiwala20
Tags: elementor, elementor-addon,elementor addons, acf, pods
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7AB7YQ4TR5YKQ&source=url
Requires at least: 5.0
Tested up to: 5.2.3
Requires PHP: 7.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Elementor addon for add Custom post type fields add in to page or post

== Description ==
Elementor addon for add Custom post type fields add in to page or post.
You can add both ACFs & PODs plugin fields

Live Demo : [Click Here!](https://zypacinfotech.com/wp/demo)

== Installation ==
1. Upload 'cpt-magic-tool.php' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==
1. Add widget to page or post
2. Addon settings

== Changelog ==
1.0 Initial release
