<!DOCTYPE html>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
	<body>
		<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
			<tr>
				<td align="center" valign="top" style="background-color: #f7f7f7; padding: 70px 0;">
					<table cellpadding="0" cellspacing="0" border="0" width="600" id="tpf_t_builder" class="thwecmf-main-builder" style="max-width: 600px; width: 600px; margin: auto;">
						<tbody>
							<tr>
								<td class="thwecmf-builder-column" style="background-color: #ffffff; vertical-align: top; border: 1px solid #dedede; border-radius: 2px;">
									<table class="thwecmf-row thwecmf-block-one-column" id="tpf_1001" data-name="one_column" data-column-count="1" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border: 0px solid transparent; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: transparent; background-color: transparent;">
										<tbody>
											<tr>
												<td class="thwecmf-column-padding thwecmf-col thwecmf-columns" id="tpf_1002" data-name="one_column_one" style="vertical-align: top; box-sizing: border-box; border: 1px dotted #dddddd; word-break: break-word; padding: 10px 10px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; width: 100%; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: #dddddd; background-color: transparent; text-align: center; min-height: 0px;">
													<?php do_action( 'woocommerce_email_header', $email_heading, $email ); ?>
												</td>
											</tr>
										</tbody>
									</table>
									<table class="thwecmf-row thwecmf-block-one-column" id="tpf_1010" data-name="one_column" data-column-count="1" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border: 0px solid transparent; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: transparent; background-color: transparent;">
										<tbody>
											<tr>
												<td class="thwecmf-column-padding thwecmf-col thwecmf-columns" id="tpf_1011" data-name="one_column_one" style="vertical-align: top; box-sizing: border-box; border: 1px dotted #dddddd; word-break: break-word; padding: 10px 10px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; width: 100%; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: #dddddd; background-color: transparent; text-align: center; min-height: 0px;">
													<table class="thwecmf-block thwecmf-block-text" id="tpf_1012" data-block-name="text" cellspacing="0" cellpadding="0" style='table-layout: fixed; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; margin: 0 auto; box-sizing: border-box; color: #636363; font-size: 13px; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: left;'>
														<tbody style="color: #636363; font-size: 13px;">
															<tr style="color: #636363; font-size: 13px;">
																<td class="thwecmf-block-text-holder" style='vertical-align: top; box-sizing: border-box; width: 100%; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; padding: 15px 15px; color: #636363; font-size: 13px; text-align: left; background-color: transparent; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 20px; padding-bottom: 15px; padding-left: 40px;'>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;">Hi <?php if(isset($order)) : ?><?php echo esc_html( $order->get_billing_first_name()).' '.esc_html($order->get_billing_last_name()); ?><?php elseif(isset($user_login)): ?><?php echo esc_html( $user_login ); ?><?php endif; ?>,<br style="color: #636363; font-size: 13px;"></div>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;"><br style="color: #636363; font-size: 13px;"></div>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;">Thanks for creating an account on <?php echo esc_html(get_bloginfo());?>. Your username is <?php if(isset($user_login)){ ?><?php echo '<strong>' . esc_html( $user_login ) . '</strong>' ?><?php } ?>. You can access your account area to view orders, change your password, and more at: <?php echo make_clickable( esc_url( wc_get_page_permalink( 'myaccount' ) ) ); ?><br style="color: #636363; font-size: 13px;"></div>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;"><br style="color: #636363; font-size: 13px;"></div>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;">Your password has been automatically generated: <?php if ( 'yes' === get_option( 'woocommerce_registration_generate_password' ) && isset($password_generated) ) : ?><?php echo '<strong>' . esc_html( $user_pass ) . '</strong>' ?><?php endif; ?><br style="color: #636363; font-size: 13px;"></div>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;"><br style="color: #636363; font-size: 13px;"></div>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;">We look forward to seeing you soon.<br style="color: #636363; font-size: 13px;"></div>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
									<table class="thwecmf-row thwecmf-block-one-column" id="tpf_1013" data-name="one_column" data-column-count="1" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border: 0px solid transparent; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: transparent; background-color: transparent;">
										<tbody>
											<tr>
												<td class="thwecmf-column-padding thwecmf-col thwecmf-columns" id="tpf_1014" data-name="one_column_one" style="vertical-align: top; box-sizing: border-box; border: 1px dotted #dddddd; word-break: break-word; padding: 10px 10px; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; width: 100%; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: transparent; background-color: transparent; text-align: center; min-height: 0px;">
													<table class="thwecmf-block thwecmf-block-text" id="tpf_1015" data-block-name="text" cellspacing="0" cellpadding="0" style='table-layout: fixed; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; margin: 0 auto; box-sizing: border-box; color: #636363; font-size: 13px; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: center;'>
														<tbody style="color: #636363; font-size: 13px;">
															<tr style="color: #636363; font-size: 13px;">
																<td class="thwecmf-block-text-holder" style='vertical-align: top; box-sizing: border-box; width: 100%; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; padding: 15px 15px; color: #636363; font-size: 13px; text-align: center; background-color: transparent; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;'>
																	<div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;"><?php echo esc_html( get_bloginfo() );?><br style="color: #636363; font-size: 13px;"></div>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</table>
	</body>
</html>
