   jQuery('.advanced_blocks_blog_grid_post.type-1').on('mouseenter',function(){
        jQuery(this).find('.blog_body').slideDown();
    });
    jQuery('.advanced_blocks_blog_grid_post.type-1').on('mouseleave',function(){
        jQuery(this).find('.blog_body').slideUp();
    });
