<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

Class PageBuilderCompanion {

    private $templates;

    function __construct() {
        $this->includes();
        $this->templates = array(
            'pbc-full-width.php'           => esc_html__( 'PBC Full Width', 'page-builder-companion' ),
            'pbc-no-sidebar.php'           => esc_html__( 'PBC No Sidebar', 'page-builder-companion' ),
            'pbc-no-header-and-footer.php' => esc_html__( 'PBC No Header and Footer', 'page-builder-companion' ),
        );

        // Add a filter to the save post to inject out template into the page cache
        add_filter( 'wp_insert_post_data', array( $this, 'register_project_templates' ) );
        add_filter( 'template_include', array( $this, 'view_project_template' ) );

        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
        add_filter( 'body_class', array( $this, 'body_class' ) );

        // Add a filter to the wp 4.7 version attributes metabox
        add_action( 'init', array( $this, 'post_type_template' ), 999 );
        add_filter( 'plugin_row_meta', array( $this, 'add_plugin_meta_links' ), 10, 2);
    }

    function includes() {
        require_once PAGE_BUILDER_COMPANION_DIR . '/templates/helpers.php';
    }

    public function body_class( $body_Class ) {

        $template = get_page_template_slug();

        if ( false !== $template && $this->is_template_active() ) {
            $body_Class[] = 'pbc-template';
        }

        $body_Class[]   = 'pbc-template-' . get_template();

        return $body_Class;
    }

    public function is_template_active() {

        $template = get_page_template_slug();
        
        if ( false !== $template && array_key_exists( $template, $this->templates ) ) {
            return true;
        }

        return false;
    }

    public function enqueue() {
        if ( is_page_template( 'pbc-full-width.php' ) ) {
            wp_register_style( 'pbc-template', plugins_url( 'assets/css/pbc-full-width.css', __FILE__ ) );
            wp_enqueue_style( 'pbc-template' );
        }

        if ( is_page_template( 'pbc-no-sidebar.php' ) ) {
            wp_register_style( 'pbc-template-no-sidebar', plugins_url( 'assets/css/pbc-no-sidebar.css', __FILE__ ) );
            wp_enqueue_style( 'pbc-template-no-sidebar' );
        }

        if( is_page_template( 'pbc-no-header-and-footer.php' ) ) {
            wp_register_style( 'pbc-template-no-header-footer', plugins_url( 'assets/css/pbc-no-header-footer.css', __FILE__ ) );
            wp_enqueue_style( 'pbc-template-no-header-footer' );
        }
    }

    public function post_type_template() {
        $args = array(
           'public'   => true
        );

        $post_types = get_post_types( $args, 'names', 'and' );

        // Disable some of the known unwanted post types.
        unset( $post_types['attachment'] );

        if ( ! empty( $post_types ) ) {

            foreach ( $post_types as $post_type ) {
                add_filter( 'theme_' . $post_type . '_templates', array( $this, 'add_new_template' ) );
            }

        }
    }

    /**
     * Adds our template to the page dropdown for v4.7+
     *
     */
    public function add_new_template( $posts_templates ) {
        $posts_templates = array_merge( $posts_templates, $this->templates );
        return $posts_templates;
    }

    function register_project_templates( $atts ) {

        // Create the key used for the themes cache
        $cache_key = 'page_templates-' . md5( get_theme_root() . '/' . get_stylesheet() );

        $templates = wp_get_theme()->get_page_templates();
        if ( empty( $templates ) ) {
            $templates = array();
        }

        wp_cache_delete( $cache_key, 'themes' );

        $templates = array_merge( $templates, $this->templates );
        wp_cache_add( $cache_key, $templates, 'themes', 1800 );

        return $atts;
    }

    function view_project_template( $template ) {

        global $post;

        // If it is nont a single post/page/post-type, don't apply the template from the plugin.
        if ( ! is_singular() ) {
            return $template;
        }

        if ( ! isset( $this->templates[ get_post_meta( $post->ID, '_wp_page_template', true ) ] ) ) {

            return $template;
        }

        $file = PAGE_BUILDER_COMPANION_DIR . '/templates/' . get_post_meta( $post->ID, '_wp_page_template', true );

        // Just to be safe, we check if the file exist first
        if ( file_exists( $file ) ) {
            return $file;
        } else {
            echo $file;
        }

        return $template;
    }
    function add_plugin_meta_links( $meta_fields, $file ){

        if( $file == PAGE_BUILDER_COMPANION_PATH  ) {

            $meta_fields[] = "<a href='https://catchplugins.com/support-forum/forum/page-builder-companion/' target='_blank'>Support Forum</a>";
            $meta_fields[] = "<a href='https://wordpress.org/support/plugin/page-builder-companion/reviews#new-post' target='_blank' title='Rate'>
                    <i class='ct-rate-stars'>"
              . "<svg xmlns='http://www.w3.org/2000/svg' width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-star'><polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/></svg>"
              . "<svg xmlns='http://www.w3.org/2000/svg' width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-star'><polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/></svg>"
              . "<svg xmlns='http://www.w3.org/2000/svg' width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-star'><polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/></svg>"
              . "<svg xmlns='http://www.w3.org/2000/svg' width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-star'><polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/></svg>"
              . "<svg xmlns='http://www.w3.org/2000/svg' width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-star'><polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/></svg>"
              . "</i></a>";

            $stars_color = "#ffb900";

            echo "<style>"
                . ".ct-rate-stars{display:inline-block;color:" . $stars_color . ";position:relative;top:3px;}"
                . ".ct-rate-stars svg{fill:" . $stars_color . ";}"
                . ".ct-rate-stars svg:hover{fill:" . $stars_color . "}"
                . ".ct-rate-stars svg:hover ~ svg{fill:none;}"
                . "</style>";
        }

        return $meta_fields;
    }


}