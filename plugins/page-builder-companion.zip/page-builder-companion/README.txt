=== Page Builder Companion ===
Contributors: catchplugins, catchthemes, sakinshrestha, pratikshrestha, maheshmaharjan, dreamsapana
Donate link: https://catchplugins.com/plugins/page-builder-companion/
Tags: templates, fullwidth, pagebuilder, elementor
Requires at least: 4.8
Tested up to: 5.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Page Builder Companion helps you build fascinating full width pages with three different template types. Choose the one you like and enjoy displaying your full width pages.

== Description ==

Page Builder Companion is a free WordPress plugin for creating beautiful full width pages on your website with various template types. It is a simple yet handy plugin that aims at building full width pages with many page builders, for instance, Elementor and Beaver Builder. It allows you to easily create and edit full width pages with different layouts for your website. There are three templates you can go for – Full Width, No Sidebar (Content Width), and No Header and Footer (Blank Page). All of these three templates provide responsive layouts, which will run smoothly across all devices. The plugin lets you control and remove all the unnecessary elements—like default page title, boxed layout, extra margins, and more—which usually comes while using a Page Builder. It is easy to install and setup, responsively designed and provides three different templates, everything to create a full width page with ease and comfort. So, from now on, whenever you need to build a full width page, you know whom to trust – Page Builder Companion. Simple and fast!

== Screenshots ==

1. Additional template selection option for pages and posts
2. Default Template
3. Full Width Template
4. No Sidebar Template
5. No Header and Footer Template (Blank Page)

== Installation ==

The easy way (via Dashboard) :

* Go to Plugins > Add New
* Type in the **Page Builder Companion** in Search Plugins box
* Click Install Now to install the plugin
* After Installation click activate to start using the **Page Builder Companion**
* Go to **Page Builder Companion** from Dashboard menu

Not so easy way (via FTP) :

* Download the **Page Builder Companion**
* Unarchive **Page Builder Companion** plugin
* Copy folder with page-builder-companion.zip
* Open the ftp \wp-content\plugins\
* Paste the plug-ins folder in the folder
* Go to admin panel => open item "Plugins" => activate **Page Builder Companion**
* Go to **Page Builder Companion** from Dashboard menu

== Changelog ==
= 1.0.1 (Released: November 12, 2019) =
* Added Pot file
* Bug Fixed: CSS update
* Removed: Unnecessary codes
* Updated: Translation ready
* Compatibility check up to version 5.3

= 1.0.0 (May 16, 2019) =
* Initial Release