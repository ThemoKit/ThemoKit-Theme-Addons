<?php 
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://catchplugins.com/
 * @since             1.0.0
 * @package           Page_Builder_Companion
 *
 * @wordpress-plugin
 * Plugin Name:       Page Builder Companion
 * Plugin URI:        https://catchplugins.com/plugins/page-builder-companion/
 * Description:       Page Builder Companion helps you build fascinating full width pages with three different template types. Choose the one you like and enjoy displaying your full width pages.
 * Version:           1.0.1
 * Author:            Catch Plugins
 * Author URI:        https://catchplugins.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       page-builder-companion
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

require_once 'class-page-builder-companion.php';

define( 'PAGE_BUILDER_COMPANION_VER', '1.0.1' );
define( 'PAGE_BUILDER_COMPANION_DIR', plugin_dir_path( __FILE__ ) );
define( 'PAGE_BUILDER_COMPANION_URL', plugins_url( '/', __FILE__ ) );
define( 'PAGE_BUILDER_COMPANION_PATH', plugin_basename( __FILE__ ) );

/**
 * Load the Plugin Class.
 */
function page_builder_companion_init() {

    // Load localization file
    load_plugin_textdomain( 'page-builder-companion' );

    // Init dynamic header footer
    new PageBuilderCompanion();

}

add_action( 'plugins_loaded', 'page_builder_companion_init' );