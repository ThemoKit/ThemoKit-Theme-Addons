=== Inspirelite Addons For Elementor ===
Contributors: easetemplate, wporganic
Tags: elementor, elementor addons, page builder addon, page builder widgets
Requires at least: 4.4
Tested up to: 5.1
Requires PHP: 7.0
Stable tag: 1.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Inspirelite Addons For Elementor - WordPress Plugin provide elementor buttons addons any user easy to modify.

== Description ==
Adds new Addons & Widgets that are specifically designed to be used in conjunction with the [Elementor Page Builder](https://wordpress.org/plugins/elementor/). 
Buttons like primary, brand, secondary, sucess, danger, light also button style included square, rounded, outline etc..

== Installation ==
1. Install using the WordPress built-in Plugin installer, or Extract the zip file and drop the contents in the `wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the \'Plugins\' menu in WordPress.
3. Go to Pages > Add New
4. Press the \'Edit with Elementor\' button.
5. Scroll down the left pane to the WordPress section and you should see the new widgets that you can drag and drop on to your page.

== Screenshots ==
1. Widgets Panel
2. Editor View
3. Design View

== Changelog ==
= 1.0.0 =
* Initial release.