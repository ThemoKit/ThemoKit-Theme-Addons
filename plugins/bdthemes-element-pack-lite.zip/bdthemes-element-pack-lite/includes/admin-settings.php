<?php
/**
 * Element Pack Admin Settings Class 
 */
class ElementPack_Admin_Settings {

    private $settings_api;

    function __construct() {
        $this->settings_api = new ElementPack_Settings_API;

        if (!defined('BDTEP_HIDE')) {
            add_action( 'admin_init', [ $this, 'admin_init' ] );
            add_action( 'admin_menu', [ $this, 'admin_menu' ], 201 );
        }
    }

    function admin_init() {

        //set the settings
        $this->settings_api->set_sections( $this->get_settings_sections() );
        $this->settings_api->set_fields( $this->element_pack_admin_settings() );

        //initialize settings
        $this->settings_api->admin_init();
    }

    function admin_menu() {
        add_submenu_page(
            'elementor',
            '',
            BDTEP_TITLE . ' Settings',
            'manage_options',
            'element_pack_options',
            [ $this, 'plugin_page' ]
        );
    }

    function get_settings_sections() {
        $sections = [
            [
                'id'    => 'element_pack_active_modules',
                'title' => esc_html__( 'Core Widgets', 'bdthemes-element-pack-lite' )
            ],
            [
                'id'    => 'element_pack_other_settings',
                'title' => esc_html__( 'Other Settings', 'bdthemes-element-pack-lite' )
            ],
        ];
        return $sections;
    }

    protected function element_pack_admin_settings() {
        $settings_fields = [
            'element_pack_active_modules' => [
                [
                    'name'    => 'select-all-widget',
                    'label'   => esc_html__( 'Select All Widgets', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                ],
                [
                    'name'    => 'business-hours',
                    'label'   => esc_html__( 'Business Hours', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                [
                    'name'    => 'call-out',
                    'label'   => esc_html__( 'Call Out', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                [
                    'name'    => 'contact-form',
                    'label'   => esc_html__( 'Simple Contact Form', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                [
                    'name'    => 'cookie-consent',
                    'label'   => esc_html__( 'Cookie Consent', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                [
                    'name'    => 'countdown',
                    'label'   => esc_html__( 'Countdown', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'custom-gallery',
                    'label'   => esc_html__( 'Custom Gallery', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'flip-box',
                    'label'   => esc_html__( 'Flip Box', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                [
                    'name'    => 'image-compare',
                    'label'   => esc_html__( 'Image Compare', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                [
                    'name'    => 'lightbox',
                    'label'   => esc_html__( 'Lightbox', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'member',
                    'label'   => esc_html__( 'Member', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'panel-slider',
                    'label'   => esc_html__( 'Panel Slider', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'progress-pie',
                    'label'   => esc_html__( 'Progress Pie', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'slider',
                    'label'   => esc_html__( 'Slider', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'scroll-button',
                    'label'   => esc_html__( 'Scroll Button', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
                
                [
                    'name'    => 'trailer-box',
                    'label'   => esc_html__( 'Trailer Box', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
               
                [
                    'name'    => 'toggle',
                    'label'   => esc_html__( 'Toggle', 'bdthemes-element-pack-lite' ),
                    'type'    => 'checkbox',
                    'default' => "on",
                ],
            ],
        ];

        $other_settings = [];
        $other_settings['element_pack_other_settings'][] = [
            'name'              => 'contact_form_email',
            'label'             => esc_html__( 'Contact Form Email', 'bdthemes-element-pack-lite' ),
            'desc'              => __( 'You can set alternative email for simple contact form', 'bdthemes-element-pack-lite' ),
            'placeholder'       => 'example@email.com',
            'type'              => 'text',
            'sanitize_callback' => 'sanitize_text_field'
        ];

        return array_merge($settings_fields, $other_settings);
    }


    


    function plugin_page() {

        echo '<div class="wrap">';
        echo '<h1>'.BDTEP_TITLE.' Settings</h1>';
        $this->save_message();
        $this->settings_api->show_navigation();
        $this->settings_api->show_forms();
        if ( !defined('BDTEP_WL') ) {
            $this->footer_info();
        }
        echo '</div>';
    }

    function save_message() {
        if( isset($_GET['settings-updated']) ) { ?>
            <div class="updated notice is-dismissible"> 
                <p><strong><?php esc_html_e('Your settings have been saved.', 'bdthemes-element-pack-lite') ?></strong></p>
            </div>
            
            <?php
        }
    }


    function footer_info() {
        ?>
        <div class="element-pack-footer-info">
            <p>If you don't know how to use the widgets please visit our <a href="https://www.youtube.com/playlist?list=PLP0S85GEw7DOJf_cbgUIL20qqwqb5x8KA">Youtube Channel</a> for visual instructions. <br>For help and support please send a <a href="https://bdthemes.com/support/">Support Ticket</a> to us.</p> 
        </div>
        <?php
    }

    /**
     * Get all the pages
     *
     * @return array page names with key value pairs
     */
    function get_pages() {
        $pages = get_pages();
        $pages_options = [];
        if ( $pages ) {
            foreach ($pages as $page) {
                $pages_options[$page->ID] = $page->post_title;
            }
        }

        return $pages_options;
    }

}

new ElementPack_Admin_Settings();