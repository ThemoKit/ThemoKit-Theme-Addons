( function( $, elementor ) {

	'use strict';

	var widgetSimpleContactForm = function( $scope, $ ) {

		var $contactForm = $scope.find('.bdt-contact-form form');
			
        if ( ! $contactForm.length ) {
            return;
        }

        $contactForm.submit(function(){
            ElementPack.sendContactForm($contactForm);
            return false;
        });

        return false;

	};


	jQuery(window).on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/bdt-contact-form.default', widgetSimpleContactForm );
	});

}( jQuery, window.elementorFrontend ) );