( function( $, elementor ) {

	'use strict';

	var ElementPack = {

		init: function() {

			var widgets = {

				//...

			};

			// Action for element pack widget scripts
			$.each( widgets, function( widget, callback ) {
				elementor.hooks.addAction( 'frontend/element_ready/' + widget, callback );
			});

			// Action for element section scripts
			elementor.hooks.addAction( 'frontend/element_ready/section', ElementPack.elementorSection );
		},		
		

		// loadSDK: function() {
		// 	// Don't load in parallel
		// 	if ( config.isLoading || config.isLoaded ) {
		// 		return;
		// 	}

		// 	config.isLoading = true;

		// 	jQuery.ajax( {
		// 		url: 'https://connect.facebook.net/en_US/sdk.js',
		// 		dataType: 'script',
		// 		cache: true,
		// 		success: function() {
		// 			FB.init( {
		// 				appId: $settings.app_id,
		// 				version: 'v2.10',
		// 				xfbml: false
		// 			} );
		// 			config.isLoaded = true;
		// 			config.isLoading = false;
		// 			jQuery( document ).trigger( 'fb:sdk:loaded' );
		// 		}
		// 	} );
		// },



		// Table Code Object



		lazyLoader:function( $scope ) {
			var $lazyload = $scope;

			$($lazyload).recliner({
				throttle : $lazyload.data('throttle'),
				threshold : $lazyload.data('threshold'),
				live : $lazyload.data('live')
			});
		},




		// google invisible captcha
		elementPackGIC: function(token) {   
			var langStr = window.ElementPackConfig.contact_form;

			return new Promise(function(resolve, reject) {  
				if (grecaptcha === undefined) {
					bdtUIkit.notification({message: '<div bdt-spinner></div> ' + langStr.captcha_nd, timeout: false, status: 'warning'});
					reject();
				}

				var response = grecaptcha.getResponse();

				if (!response) {
					bdtUIkit.notification({message: '<div bdt-spinner></div> ' + langStr.captcha_nr, timeout: false, status: 'warning'});
					reject();
				}

				var $contactForm=$('textarea.g-recaptcha-response').filter(function () {
					return $(this).val() === response;
					}).closest('form.bdt-contact-form-form');
				var contactFormAction = $contactForm.attr('action');
				if(contactFormAction && contactFormAction !== ''){
					ElementPack.sendContactForm($contactForm);
				} else {
					console.log($contactForm);
				}
				
				grecaptcha.reset();

			}); //end promise
		},

		sendContactForm: function($contactForm) {
			var langStr = window.ElementPackConfig.contact_form;

			$.ajax({
				url:$contactForm.attr('action'),
				type:'POST',
				data:$contactForm.serialize(),
				beforeSend:function(){
					bdtUIkit.notification({message: '<div bdt-spinner></div> ' + langStr.sending_msg, timeout: false, status: 'primary'});
				},
				success:function(data){
					bdtUIkit.notification.closeAll();
					bdtUIkit.notification({message: data});
					//$contactForm[0].reset();
				}
			});
			return false;
		},

	


		elementorSection: function( $scope ) {
			var $section   = $scope,
				instance   = null,
				sectionID  = $section.data('id'),
				//editMode   = Boolean( elementor.isEditMode() ),
				particleID = 'bdt-particle-container-' + sectionID,
				particleSettings = {};

			//sticky fixes for inner section.
			$.each($section, function( index ) {
				var $sticky      = $(this),
					$stickyFound = $sticky.find('.elementor-inner-section.bdt-sticky');
					
				if ($stickyFound.length) {
					$($stickyFound).wrap('<div class="bdt-sticky-wrapper"></div>');
				}
			});

			instance = new bdtWidgetTooltip( $section );
			instance.init();

			if (typeof particlesJS === 'undefined') {
				return;
			}

			if ( window.ElementPackConfig && window.ElementPackConfig.elements_data.sections.hasOwnProperty( sectionID ) ) {
				particleSettings = window.ElementPackConfig.elements_data.sections[ sectionID ];
			}
			
			
			$.each($section, function( index ) {
				var $this = $(this);
				if ($this.hasClass('bdt-particles-yes')) {
					$section.prepend( '<div id="'+particleID+'" class="bdt-particle-container"></div>' );
					particlesJS( particleID, JSON.parse( particleSettings.particles_js ));
				}
			});
		}
	};

	$( window ).on( 'elementor/frontend/init', ElementPack.init );
	
	//Contact form recaptcha callback, if needed
	window.elementPackGICCB = ElementPack.elementPackGIC;

	window.bdtWidgetTooltip = function ( $selector ) {

		var $tooltip = $selector.find('.elementor-widget.bdt-tippy-tooltip');

		this.init = function() {
			if ( ! $tooltip.length ) {
				return;
			}
			$tooltip.each( function( index ) {

				tippy( this, {
					appendTo: this
				});				
			});
		};
		
	};

}( jQuery, window.elementorFrontend ) );
