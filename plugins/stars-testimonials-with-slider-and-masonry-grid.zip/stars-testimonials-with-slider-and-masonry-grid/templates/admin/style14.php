<figure class="st-style14">
  <figcaption class="st-testimonial-bg">
    <blockquote class="st-testimonial-content">
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </blockquote>
    <div class="starrating st-rating" title="Rated <?php echo $stars; ?> out of 5.0">
      <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i>
    </div>
    <h3 class="st-testimonial-title"><?php echo $clientArray[$j-1]; ?></h3>
    <h4 class="st-testimonial-company"><?php echo $companyArray[$j-1]; ?></h4>
  </figcaption>
</figure>
