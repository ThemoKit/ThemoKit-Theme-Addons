jQuery(document).ready(function($) {
	$('.masonry-wrap').masonry({
		itemSelector : '.masonry-item',
	});	
});