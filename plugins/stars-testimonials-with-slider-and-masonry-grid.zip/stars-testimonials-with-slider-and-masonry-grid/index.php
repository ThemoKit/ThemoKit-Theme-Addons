<?php
defined('ABSPATH') or die('Nope, not accessing this');
?>