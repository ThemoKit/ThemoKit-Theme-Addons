<?php

/**
 *
 *
 * @link              https://zeetheme.com/elements-for-lifterlms
 * @since             1.0.1
 * @package           Elements_For_Lifterlms
 *
 * @wordpress-plugin
 * Plugin Name:       Elements for LifterLMS
 * Plugin URI:        https://zeetheme.com/elements-for-lifterlms
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.1
 * Author:            Vishal Ranjan
 * Author URI:        https://zeetheme.com/about
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       elements-for-lifterlms
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
    die;
}
/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'ELEMENTS_FOR_LIFTERLMS_VERSION', '1.0.0' );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-elements-for-lifterlms-activator.php
 */
function activate_elements_for_lifterlms()
{
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-elements-for-lifterlms-activator.php';
    Elements_For_Lifterlms_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-elements-for-lifterlms-deactivator.php
 */
function deactivate_elements_for_lifterlms()
{
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-elements-for-lifterlms-deactivator.php';
    Elements_For_Lifterlms_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_elements_for_lifterlms' );
register_deactivation_hook( __FILE__, 'deactivate_elements_for_lifterlms' );
/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-elements-for-lifterlms.php';
/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_elements_for_lifterlms()
{
    $plugin = new Elements_For_Lifterlms();
    $plugin->run();
}

run_elements_for_lifterlms();


if ( ! function_exists( 'llms_elements' ) ) {
    // Create a helper function for easy SDK access.
    function llms_elements() {
        global $llms_elements;

        if ( ! isset( $llms_elements ) ) {
            // Activate multisite network integration.
            if ( ! defined( 'WP_FS__PRODUCT_3512_MULTISITE' ) ) {
                define( 'WP_FS__PRODUCT_3512_MULTISITE', true );
            }

            // Include Freemius SDK.
            require_once dirname(__FILE__) . '/freemius/start.php';

            $llms_elements = fs_dynamic_init( array(
                'id'                  => '3512',
                'slug'                => 'elements-for-lifterlms',
                'premium_slug'        => 'elements-for-lifterlms-premium',
                'type'                => 'plugin',
                'public_key'          => 'pk_b2655e8697c76f15dfa1a80bdfff5',
                'is_premium'          => true,
                'premium_suffix'      => 'Elements for LifterLMS License',
                // If your plugin is a serviceware, set this option to false.
                'has_premium_version' => true,
                'has_addons'          => false,
                'has_paid_plans'      => true,
                'trial'               => array(
                    'days'               => 7,
                    'is_require_payment' => false,
                ),
                'menu'                => array(
                    'slug'           => 'elements-for-lifterlms',
                    'first-path'     => 'admin.php?page=elements-for-lifterlms',
                    'contact'    => false,
                    'support'    => false,
                    'pricing'    => false,

                ),
                // Set the SDK to work in a sandbox mode (for development & testing).
                // IMPORTANT: MAKE SURE TO REMOVE SECRET KEY BEFORE DEPLOYMENT.
                'secret_key'          => 'sk_Lls2D!NT@=.PjdQ8_DP6Zal}]J9gT',
            ) );
        }

        return $llms_elements;
    }

    // Init Freemius.
    llms_elements();
    // Signal that SDK was initiated.
    do_action( 'llms_elements_loaded' );
}

function llms_elements_icon()
{
    return plugin_dir_path( __FILE__ ) . '/admin/img/llmse-logo-freemius.png';
}

llms_elements()->add_filter( 'plugin_icon', 'llms_elements_icon' );
function llms_elements_custom_connect_message_on_update(
    $message,
    $user_first_name,
    $plugin_title,
    $user_login,
    $site_link,
    $freemius_link
)
{
    return sprintf(
        __( 'Hey %1$s' ) . ',<br>' . __( 'Thanks for installing %2$s. We are very exited to see what you are going to create with it. Please help us improve this plugin! Opt-in to our security and feature updates notifications, and non-sensitive diagnostic tracking.' ),
        $user_first_name,
        '<b>' . $plugin_title . '</b>',
        '<b>' . $user_login . '</b>',
        $site_link
    );
}

llms_elements()->add_filter(
    'connect_message_on_update',
    'llms_elements_custom_connect_message_on_update',
    10,
    6
);