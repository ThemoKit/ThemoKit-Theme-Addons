=== Elements for LifterLMS ===
Contributors: zeetheme, vranjan257
Donate link: https://zeetheme.com/elements-for-lifterlms
Tags: learning management system, LMS, membership, elearning, online courses, quizzes, sell courses, badges, gamification, learning, Lifter, LifterLMS
Requires at least: 3.0.1
Tested up to: 5.2.2
Requires PHP: 7.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Elements for LifterLMS is a plugin that integrates Elementor to LifterLMS.

== Description ==

Elements for LifterLMS is an Elementor integration plugin for LifterLMS that offers you a library of unique Elementor Widgets to create stunning Course and Lesson Pages. Take LifterLMS to next level with a new set of dynamic Elementor widgets and a whole new range of design possibilities for your  Courses.

## Features

# **TOTAL DESIGN FREEDOM**

Create beautiful and intuitive Course and Lesson Pages with total freedom. With the library of unique Elementor Widgets for LifterLMS, your course design will stand out.

# **USE WITH ANY THEME**

You can use Elements for LifterLMS with any WordPress theme as long as Elementor Page Builder is Working on it. We’ve already tested it on popular theme like GeneratePress, Astra and OceanWP.

# **100% COMPATIBLE**

Elements for LifterLMS is 100% compatible with LifterLMS add-ons like WooCommerce Integration, LifterLMS Assignments . We have tasted it with every add-on available.

## WIDGETS

# **Course Widgets**

+ COURSE TITLE
+ FEATURED VIDEO
+ FEATURED AUDIO
+ PROGRESS BAR
+ COURSE INFO
+ CONTINUE BUTTON
+ COURSE SYLLABUS
+ COURSE INSTRUCTORS
+ PRICING TABLE
+ COURSE PREREQUISITE
+ COURSE REVIEWS
+ COURSE VIDEO POPUP
+ Many more coming soon...

# **Lesson Widgets**

+ LESSON TITLE
+ FEATURED VIDEO
+ PROGRESS BAR
+ COURSE SYLLABUS
+ LESSON TITLE
+ MARK COMPLETE BUTTON
+ BACK TO COURSE LINK
+ Many more coming soon...

[Official Homepage](https://lifterlmselements.com)
[Documentation](https://lifterlmselements.com/documentation/)
[Support](https://lifterlmselements.com/support/)
[Join Facebook Group](https://www.facebook.com/groups/2409753875977922/)

== Installation ==

#### Automatic Installation

This is the simplest way to install Elements for LifterLMS as it utilizes WordPress to handle file transfers and you never need to leave the web browser or admin panel.

1. Log in to your WordPress dashboard.
2. Navigate to Plugins -> Add New
3. In the search field type "Elements for LifterLMS" and click "Search Plugins"
4. Once you've located Elements for LifterLMS click "Install Now"
5. Once installation is complete, click "Activate"

#### Manual Installation

To manually install Elements for LifterLMS you'll need to download the zip file using the "Download" link on this screen. You'll then need to use FTP to manually upload the files to the proper directory on your webserver.

== Frequently Asked Questions ==

**What is Elements for LifterLMS?**

Elements for LifterLMS is an Elementor integration plugin for LifterLMS that offers you a library of unique Elementor Widgets to create stunning Course and Lesson Pages.

**Will Elements for LifterLMS work with my theme?**

You can use Elements for LifterLMS with any WordPress theme as long as Elementor Page Builder is Working on it. We’ve already tested it on popular theme like GeneratePress, Astra and OceanWP.

**Can I use the plugin without Elementor Page Builder?**

No. You cannot use the plugin without Elementor since it’s an addon for Elementor.

**Can I use the plugin without LifterLMS?**

No. You cannot use the plugin without LifterLMS since it's an integration plugin for LifterLMS and Elementor and it only works on LifterLMS Lesson, Course and Membership pages.

**Is the plugin compatible with LifterLMS Add-ons and extentions?**

Yes! Elements for LifterLMS is 100% compatible with LifterLMS official add-ons like WooCommerce Integration and LifterLMS Assignments . We have tasted it with every add-on available. But it may not be compatible with any thirdparty add-ons for LifterLMS.

**Does the plugin use an External Service for Tracking?**

Yes. We use Freemius for collecting non-sensitive diagnostic data about the plugin install from your website. When  you activate the plugin we ask you to help us improve the plugin by sending us non-sensitive diagnostic data. We do this via a service called Freemius. If you choose to not opt-in no data is sent.

When you opt-in, we collect the following information:

+ The name and email address of the WordPress user installing the plugin
+ Site URL
+ WordPress version
+ PHP version
+ Elements for LifterLMS plugin status (activation, deactivation, uninstall)
+ Elements for LifterLMS plugin version


== Screenshots ==

1. Elements of LifterLMS Course Page Settings. The plugin gives you option to hide all the elements added by default from the Course and Lesson page, so that you get a blank canvas to design your own course and lesson layout.
2. Elements of LifterLMS allows to create course and lesson layout vissually on front-end of your website.
3. Course Instructors design options. Elements of LifterLMS gives you complete design freedom.
4. Pricing Table design options. You Get pixel perfect designs that are completely mobile responsive.
5. Lesson Layout Design. With the library of unique Elementor Widgets for LifterLMS, your lesson page design will stand out.


== Changelog ==

= 1.0.0 =
* Initial release

= 1.0.1 =
* Minor Improvement

