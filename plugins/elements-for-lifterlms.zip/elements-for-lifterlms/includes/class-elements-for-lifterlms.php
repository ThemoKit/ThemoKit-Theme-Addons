<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://zeetheme.com/
 * @since      1.0.0
 *
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/includes
 */
/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/includes
 * @author     Vishal Ranjan <support@zeetheme.com>
 */
class Elements_For_Lifterlms
{
    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Elements_For_Lifterlms_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected  $loader ;
    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected  $plugin_name ;
    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected  $version ;
    /**
     * Minimum Elementor Version
     *
     * @since 1.0.0
     *
     * @var string Minimum Elementor version required to run the plugin.
     */
    const  MINIMUM_ELEMENTOR_VERSION = '2.0.0' ;
    /**
     * Minimum PHP Version
     *
     * @since 1.0.0
     *
     * @var string Minimum PHP version required to run the plugin.
     */
    const  MINIMUM_PHP_VERSION = '7.0' ;
    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct()
    {
        
        if ( defined( 'ELEMENTS_FOR_LIFTERLMS_VERSION' ) ) {
            $this->version = ELEMENTS_FOR_LIFTERLMS_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        
        $this->plugin_name = 'elements-for-lifterlms';
        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
        add_action( 'plugins_loaded', [ $this, 'init' ] );
    }
    
    /**
     * Initialize the plugin
     *
     * Load the plugin only after Elementor (and other plugins) are loaded.
     * Checks for basic plugin requirements, if one check fail don't continue,
     * if all check have passed load the files required to run the plugin.
     *
     * Fired by `plugins_loaded` action hook.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function init()
    {
        // Check if Elementor installed and activated
        
        if ( !did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
            return;
        }
        
        // Check for required Elementor version
        
        if ( !version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
            return;
        }
        
        // Check for required PHP version
        
        if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
            return;
        }
        
        add_action( 'wp_head', [ $this, 'show_hide_widgets_class' ] );
        // Add Plugin actions
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
        // add_action( 'elementor/controls/controls_registered', [ $this, 'init_controls' ] );
        add_action( 'elementor/elements/categories_registered', array( $this, 'add_elementor_widget_categories' ) );
        //Membership
        if ( get_option( 'hide-membership-elements-checkbox' ) == 1 ) {
            remove_action( 'lifterlms_single_membership_after_summary', 'lifterlms_template_pricing_table', 10 );
        }
        //Lesson
        
        if ( get_option( 'hide-lesson-elements-radio' ) == 2 ) {
            // Lesson Navigation.
            remove_action( 'lifterlms_single_lesson_after_summary', 'lifterlms_template_lesson_navigation', 20 );
            remove_action( 'astra_entry_after', 'lifterlms_template_lesson_navigation' );
            // Lesson Progression.
            remove_action( 'lifterlms_single_lesson_after_summary', 'lifterlms_template_complete_lesson_link', 10 );
            // Lesson Back to course.
            remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_parent_course', 10 );
            // Lesson Video
            remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_lesson_video', 20 );
            // Lesson Audio
            remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_lesson_audio', 20 );
        } else {
            
            if ( get_option( 'hide-lesson-nav-checkbox' ) == 1 ) {
                // Lesson Navigation.
                remove_action( 'lifterlms_single_lesson_after_summary', 'lifterlms_template_lesson_navigation', 20 );
                remove_action( 'astra_entry_after', 'lifterlms_template_lesson_navigation' );
            }
            
            if ( get_option( 'hide-lesson-mark-complete-checkbox' ) == 1 ) {
                // Lesson Progression.
                remove_action( 'lifterlms_single_lesson_after_summary', 'lifterlms_template_complete_lesson_link', 10 );
            }
            if ( get_option( 'hide-lesson-back-to-course-checkbox' ) == 1 ) {
                // Lesson Back to course.
                remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_parent_course', 10 );
            }
            if ( get_option( 'hide-lesson-featured-video-checkbox' ) == 1 ) {
                // Lesson Video
                remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_lesson_video', 20 );
            }
            if ( get_option( 'hide-lesson-featured-audio-checkbox' ) == 1 ) {
                // Lesson Audio
                remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_lesson_audio', 20 );
            }
        }
        
        //Course
        
        if ( get_option( 'hide-course-elements-radio' ) == 2 ) {
            remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_featured_image', 10 );
            remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_video', 20 );
            remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_audio', 30 );
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_meta_wrapper_start', 5 );
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_length', 10 );
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_difficulty', 20 );
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_tracks', 25 );
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_categories', 30 );
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_tags', 35 );
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_meta_wrapper_end', 50 );
            // Remove Course Progress.
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_progress', 60 );
            // Course Syllabus.
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_syllabus', 90 );
            // Instructors.
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_course_author', 40 );
            // Pricing Table.
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_pricing_table', 60 );
            // remove_action( 'lifterlms_single_membership_after_summary', 'lifterlms_template_pricing_table', 10 );
            // Prerequisites
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_prerequisites', 55 );
            // Reviews
            remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_reviews', 100 );
            remove_action( 'lifterlms_single_course_after_summary', 'single_reviews', 100 );
        } else {
            if ( get_option( 'hide-course-featured-video-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_video', 20 );
            }
            if ( get_option( 'hide-course-featured-img-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_featured_image', 10 );
            }
            if ( get_option( 'hide-course-featured-audio-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_audio', 30 );
            }
            
            if ( get_option( 'hide-course-info-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_meta_wrapper_start', 5 );
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_length', 10 );
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_difficulty', 20 );
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_tracks', 25 );
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_categories', 30 );
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_tags', 35 );
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_course_author', 40 );
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_meta_wrapper_end', 50 );
            }
            
            if ( get_option( 'hide-course-prerequisites-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_prerequisites', 55 );
            }
            if ( get_option( 'hide-course-pricing-table-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_pricing_table', 60 );
            }
            if ( get_option( 'hide-course-progress-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_progress', 60 );
            }
            if ( get_option( 'hide-course-syllabus-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_syllabus', 90 );
            }
            if ( get_option( 'hide-course-reviews-checkbox' ) == 1 ) {
                remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_reviews', 100 );
            }
        }
    
    }
    
    /**
     * Admin notice
     *
     * Warning when the site doesn't have Elementor installed or activated.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function admin_notice_missing_main_plugin()
    {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor */
            esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'elements-for-lifterlms' ),
            '<strong>' . esc_html__( 'Elements for LifterLMS', 'elements-for-lifterlms' ) . '</strong>',
            '<strong>' . esc_html__( 'Elementor', 'elements-for-lifterlms' ) . '</strong>'
        );
        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }
    
    /**
     * Admin notice
     *
     * Warning when the site doesn't have a minimum required Elementor version.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function admin_notice_minimum_elementor_version()
    {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
            esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'elements-for-lifterlms' ),
            '<strong>' . esc_html__( 'Elements for LifterLMS', 'elements-for-lifterlms' ) . '</strong>',
            '<strong>' . esc_html__( 'Elementor', 'elements-for-lifterlms' ) . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );
        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }
    
    /**
     * Admin notice
     *
     * Warning when the site doesn't have a minimum required PHP version.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function admin_notice_minimum_php_version()
    {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
        $message = sprintf(
            /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
            esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'elements-for-lifterlms' ),
            '<strong>' . esc_html__( 'Elements for LifterLMS', 'elements-for-lifterlms' ) . '</strong>',
            '<strong>' . esc_html__( 'PHP', 'elements-for-lifterlms' ) . '</strong>',
            self::MINIMUM_PHP_VERSION
        );
        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }
    
    /**
     * Init Widgets
     *
     * Include widgets files and register them
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function init_widgets()
    {
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lifterlms-video.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lifterlms-audio.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lifterlms-title.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lesson-navigation.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lesson-mark-complete.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lesson-back-to-course.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lesson-syllabus.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/lesson-progress-bar.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/course-continue-button.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/course-syllabus.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/course-instructors.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/course-pricing-table.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/course-prerequisite.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/course-info.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . '/includes/widgets/course-reviews.php';
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Lesson_Video() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Audio() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Title() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Lesson_Navigation() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Lesson_Mark_Complete() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Lesson_Backtocourse() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Lesson_Syllabus() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Lesson_Progress_Bar() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Course_Continue_Btn() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Course_Syllabus() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Course_Instructors() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Course_Pricing_Table() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Course_Prerequisite() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Course_Info() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LLMSE_Lifterlms_Course_Reviews() );
    }
    
    public function add_elementor_widget_categories( $elements_manager )
    {
        $elements_manager->add_category( 'elements-for-lifterlms', [
            'title' => __( 'LifterLMS General', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-plug',
        ] );
        $elements_manager->add_category( 'elements-for-lifterlms-lesson', [
            'title' => __( 'LifterLMS Lesson', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-plug',
        ] );
        $elements_manager->add_category( 'elements-for-lifterlms-course', [
            'title' => __( 'LifterLMS Course', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-plug',
        ] );
    }
    
    /**
     * Init Controls
     *
     * Include controls files and register them
     *
     * @since 1.0.0
     *
     * @access public
     */
    // public function init_controls() {
    // 	// Include Control files
    // 	require_once( __DIR__ . '/controls/llmse-upgrade-message.php' );
    // 	// Register control
    // 	\Elementor\Plugin::$instance->controls_manager->register_control( 'control-type-', new \EmojiOneArea_Control() );
    // }
    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Elements_For_Lifterlms_Loader. Orchestrates the hooks of the plugin.
     * - Elements_For_Lifterlms_i18n. Defines internationalization functionality.
     * - Elements_For_Lifterlms_Admin. Defines all hooks for the admin area.
     * - Elements_For_Lifterlms_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies()
    {
        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-elements-for-lifterlms-loader.php';
        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-elements-for-lifterlms-i18n.php';
        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-elements-for-lifterlms-admin.php';
        /**
         * The class responsible for defining all actions that occur in the public-facing
         * side of the site.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-elements-for-lifterlms-public.php';
        /**
         * The class responsible for Showing Course Reviews
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-course-review.php';
        $this->loader = new Elements_For_Lifterlms_Loader();
    }
    
    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the Elements_For_Lifterlms_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale()
    {
        $plugin_i18n = new Elements_For_Lifterlms_i18n();
        $this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
    }
    
    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks()
    {
        $plugin_admin = new Elements_For_Lifterlms_Admin( $this->get_plugin_name(), $this->get_version() );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
    }
    
    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks()
    {
        $plugin_public = new Elements_For_Lifterlms_Public( $this->get_plugin_name(), $this->get_version() );
        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
    }
    
    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run()
    {
        $this->loader->run();
    }
    
    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name()
    {
        return $this->plugin_name;
    }
    
    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    Elements_For_Lifterlms_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader()
    {
        return $this->loader;
    }
    
    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version()
    {
        return $this->version;
    }
    
    public function show_hide_widgets_class()
    {
        ?>
		<style type="text/css">

			<?php 
        
        if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
        } else {
            ?>

				<?php 
            
            if ( class_exists( 'LifterLMS' ) ) {
                ?>
					
					<?php 
                
                if ( is_course() ) {
                    ?>
						<?php 
                    global  $post ;
                    $course = new LLMS_Course( $post );
                    $lesson = new LLMS_Lesson( $post->ID );
                    $student = llms_get_student();
                    ?>

						<?php 
                    
                    if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) ) {
                        ?>

							.show-to-visitors-only{
								display: none;
							}

							.elementor-editor-active .show-to-visitors-only,
							.elementor-editor-preview .show-to-visitors-only{
								display: block;
							}

						<?php 
                    } else {
                        ?>

							.show-to-students-only{
								display: none;
							}

							.elementor-editor-active .show-to-students-only,
							.elementor-editor-preview .show-to-students-only{
								display: block;
							}

						<?php 
                    }
                    
                    ?>
							
					<?php 
                } elseif ( is_lesson() ) {
                    ?>
						<?php 
                    global  $post ;
                    $lesson = new LLMS_Lesson( $post->ID );
                    $course_id = $lesson->get_parent_course();
                    $course = new LLMS_Course( $course_id );
                    $student = llms_get_student();
                    ?>

						<?php 
                    
                    if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) ) {
                        ?>

							.show-to-visitors-only{
								display: none;
							}

						<?php 
                    } else {
                        ?>

							.show-to-students-only{
								display: none;
							}

						<?php 
                    }
                    
                    ?>
					<?php 
                }
                
                ?>

				<?php 
            }
            
            ?>

			<?php 
        }
        
        ?>
			
		</style>
		<?php 
    }

}