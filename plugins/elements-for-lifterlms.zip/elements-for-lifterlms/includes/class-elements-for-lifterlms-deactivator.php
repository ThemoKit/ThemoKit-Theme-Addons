<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://zeetheme.com/
 * @since      1.0.0
 *
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/includes
 * @author     Vishal Ranjan <support@zeetheme.com>
 */
class Elements_For_Lifterlms_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
