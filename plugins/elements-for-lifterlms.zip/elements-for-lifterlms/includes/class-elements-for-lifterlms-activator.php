<?php

/**
 * Fired during plugin activation
 *
 * @link       https://zeetheme.com/
 * @since      1.0.0
 *
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/includes
 * @author     Vishal Ranjan <support@zeetheme.com>
 */
class Elements_For_Lifterlms_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
