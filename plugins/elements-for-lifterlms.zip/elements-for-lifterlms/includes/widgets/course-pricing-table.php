<?php

/**
 * LifterLMS Title Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Course_Pricing_Table extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-course-pricing-table';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Course/Membership Pricing Table', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-price-table';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms-course' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'pricing_table_section', [
            'label' => __( 'Pricing Table', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'pricing_table_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-wrap, {{WRAPPER}} .le-access-plan' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'hr', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ] );
        $this->add_control( 'control_get_pro_1', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_section();
        // Header
        $this->start_controls_section( 'pricing_head_section', [
            'label' => __( 'Head', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'pricing_head_background_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_2,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-head' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'pricing_head_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-head' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'header_title', [
            'label'     => __( 'Title', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'pricing_title_color', [
            'label'     => __( 'Title Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-title' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'pricing_title_typography',
            'label'    => __( 'Title Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-title',
        ] );
        $this->end_controls_section();
        // Pricing
        $this->start_controls_section( 'pricing_price_section', [
            'label' => __( 'Pricing', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'pricing_price_background_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-pricing-wrap' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'pricing_price_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-pricing-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'pricing_price_title', [
            'label'     => __( 'Price', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'pricing_price_color', [
            'label'     => __( 'Price Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_2,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-price .lifterlms-price' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'pricing_price_typography',
            'label'    => __( 'Price Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-price .lifterlms-price',
        ] );
        $this->add_control( 'pricing_period_color', [
            'label'     => __( 'Period Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-schedule' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'pricing_period_typography',
            'label'    => __( 'Period Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-schedule',
        ] );
        $this->add_control( 'membership_title', [
            'label'     => __( 'Membership List', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'pricing_membership_title_color', [
            'label'     => __( 'Membership Lebel Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-restrictions .le-stamp' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'pricing_membership_title_typography',
            'label'    => __( 'Membership Lebel Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-restrictions .le-stamp',
        ] );
        $this->start_controls_tabs( 'membership_btn_tabs' );
        $this->start_controls_tab( 'membership_btn_normal_tab', [
            'label' => __( 'Normal', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'membership_button_color', [
            'label'     => __( 'Membership Button Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-restrictions ul li a' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'membership_button_text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-restrictions ul li a' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'membership_btn_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-restrictions ul li a',
        ] );
        $this->add_control( 'membership_btn_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-restrictions ul li a' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'membership_btn_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-restrictions ul li a',
        ] );
        $this->end_controls_tab();
        $this->start_controls_tab( 'membership_btn_hover_tab', [
            'label' => __( 'Hover', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'membership_button_hover_color', [
            'label'     => __( 'Membership Button Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-restrictions ul li a:hover' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'membership_button_text_hover_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-restrictions ul li a:hover' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'membership_btn_hover_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-restrictions ul li a:hover',
        ] );
        $this->add_control( 'membership_btn_hover_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-restrictions ul li a:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'membership_btn_hover_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-restrictions ul li a:hover',
        ] );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
        // Description
        $this->start_controls_section( 'pricing_description_section', [
            'label' => __( 'Description', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'description_background_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-content' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'description_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'description_text_title', [
            'label'     => __( 'Text', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'description_text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-description' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'description_text_typography',
            'label'    => __( 'Text Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-description',
        ] );
        $this->add_control( 'description_list_title', [
            'label'     => __( 'List Style', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'description_list_color', [
            'label'     => __( 'List Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-description ul li' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'description_list_typography',
            'label'    => __( 'List Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-description ul li',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'description_list_border',
            'label'    => __( 'List Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-description ul li',
        ] );
        $this->add_control( 'description_list_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-description ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->end_controls_section();
        // Footer
        $this->start_controls_section( 'pricing_footer_section', [
            'label' => __( 'Footer', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'footer_background_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-footer' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'footer_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'footer_btn_title', [
            'label'     => __( 'Button', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'footer_btn_width', [
            'label'      => __( 'Button Width', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 500,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => '%',
            'size' => null,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button' => 'width: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'footer_btn_padding', [
            'label'      => __( 'Button Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'footer_btn_margin', [
            'label'      => __( 'Button Margin', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->start_controls_tabs( 'footer_btn_tabs' );
        $this->start_controls_tab( 'footer_btn_normal_tab', [
            'label' => __( 'Normal', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'footer_button_color', [
            'label'     => __( 'Button Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'footer_button_text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'footer_button_typography',
            'label'    => __( 'Button Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'footer_btn_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button',
        ] );
        $this->add_control( 'footer_btn_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'footer_btn_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button',
        ] );
        $this->end_controls_tab();
        $this->start_controls_tab( 'footer_btn_hover_tab', [
            'label' => __( 'Hover', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'footer_button_hover_color', [
            'label'     => __( 'Button Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_4,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button:hover' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'footer_button_text_hover_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button:hover' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'footer_btn_hover_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button:hover',
        ] );
        $this->add_control( 'footer_btn_hover_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'footer_btn_hover_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-footer a.le-button-action.button:hover',
        ] );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control( 'footer_trial', [
            'label'     => __( 'Trial', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'trial_color', [
            'label'     => __( 'Trial Price Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_2,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-trial-price' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'trial_typography',
            'label'    => __( 'Trial Price Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-trial-price',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'trial_border',
            'label'    => __( 'Trial Price Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-trial-price',
        ] );
        $this->add_control( 'trial_border_radius', [
            'label'      => __( 'Trial Price Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-trial-price' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'trial_padding', [
            'label'      => __( 'Trial Price Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-access-plan-trial-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'trial_period_color', [
            'label'     => __( 'Trial Period Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-access-plan-trial' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'trial_period_typography',
            'label'    => __( 'Trial Period Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-access-plan-trial',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'go_premium_style', [
            'label' => __( 'Go Premium for More Features', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'control_get_pro_style', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more stunning widgets and customization options.</span>',
        ] );
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render( $post_id = null )
    {
        ?>

		<div class="le-course-pricing-table">
			<?php 
        $this->le_template_pricing_table();
        ?>
		</div> 

		<?php 
    }
    
    public function le_template_pricing_table( $post_id = null )
    {
        global  $post ;
        $post_id = ( $post_id ? $post_id : get_the_ID() );
        $product = new LLMS_Product( $post_id );
        $is_enrolled = llms_is_user_enrolled( get_current_user_id(), $product->get( 'id' ) );
        $purchaseable = $product->is_purchasable();
        $has_free = $product->has_free_access_plan();
        $free_only = $has_free && !$purchaseable;
        $settings = $this->get_settings_for_display();
        ?>

		<?php 
        
        if ( !apply_filters( 'llms_product_pricing_table_enrollment_status', $is_enrolled ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            ?>

			<?php 
            
            if ( $purchaseable || $has_free ) {
                ?>

				<?php 
                do_action( 'lifterlms_before_access_plans', $product->get( 'id' ) );
                ?>

				<?php 
                $table_count = $product->get_pricing_table_columns_count( $free_only );
                ?>

				<section class="llms-access-plans le-access-plans cols-<?php 
                echo  ( $table_count <= 4 ? $table_count : 4 ) ;
                ?> <?php 
                if ( $table_count > 4 ) {
                    ?>multiple-rows<?php 
                }
                ?> <?php 
                if ( 'yes' === $settings['table_equal_height'] && $table_count > 1 ) {
                    ?>equal-height<?php 
                }
                ?>">

					<?php 
                do_action( 'lifterlms_before_access_plans_loop', $product->get( 'id' ) );
                ?>

					<?php 
                foreach ( $product->get_access_plans( $free_only ) as $plan ) {
                    ?>

						<div class="le-access-plan le<?php 
                    echo  llms_get_access_plan_classes( $plan ) ;
                    ?>" id="le-access-plan-<?php 
                    echo  $plan->get( 'id' ) ;
                    ?>">

							<div class="le-access-plan-wrap">

								<div class="le-access-plan-head">

									<!-- access plan featured -->
									<?php 
                    
                    if ( $plan->is_featured() ) {
                        ?>
										<div class="le-featured-wrap">
											<span class="le-access-plan-featured">
												<?php 
                        echo  apply_filters( 'lifterlms_featured_access_plan_text', __( 'FEATURED', 'lifterlms' ), $plan ) ;
                        ?>
											</span>
										</div>
									<?php 
                    }
                    
                    ?>

									<!-- access_plan_title -->
									<h4 class="le-access-plan-title"><?php 
                    echo  $plan->get( 'title' ) ;
                    ?></h4>

								</div>

								<div class="le-access-plan-pricing-wrap">

																<!-- access plan pricing -->
									<?php 
                    $schedule = $plan->get_schedule_details();
                    $expires = $plan->get_expiration_details();
                    ?>
									<div class="le-access-plan-pricing regular">

										<div class="le-access-plan-price">

											<?php 
                    
                    if ( $plan->is_on_sale() ) {
                        ?>
												<em class="stamp"><?php 
                        _e( 'SALE', 'lifterlms' );
                        ?></em>
											<?php 
                    }
                    
                    ?>

											<span class="price-regular"><?php 
                    echo  $plan->get_price( 'price' ) ;
                    ?></span>

											<?php 
                    
                    if ( $plan->is_on_sale() ) {
                        ?>
												<span class="price-sale"><?php 
                        echo  $plan->get_price( 'sale_price' ) ;
                        ?></span>
											<?php 
                    }
                    
                    ?>

										</div>

										<?php 
                    
                    if ( $schedule ) {
                        ?>
											<div class="le-access-plan-schedule"><?php 
                        echo  $schedule ;
                        ?></div>
										<?php 
                    }
                    
                    ?>

										<?php 
                    
                    if ( $expires ) {
                        ?>
											<div class="le-access-plan-expiration"><?php 
                        echo  $expires ;
                        ?></div>
										<?php 
                    }
                    
                    ?>

										<?php 
                    
                    if ( $plan->is_on_sale() && $plan->get( 'sale_end' ) ) {
                        ?>
											<div class="le-access-plan-sale-end"><?php 
                        printf( __( 'sale ends %s', 'lifterlms' ), $plan->get_date( 'sale_end', 'n/j/y' ) );
                        ?></div>
										<?php 
                    }
                    
                    ?>

									</div>

									<!-- access plan restrictions -->
									<?php 
                    
                    if ( $plan->has_availability_restrictions() ) {
                        ?>
										<div class="le-access-plan-restrictions">
											<em class="le-stamp"><?php 
                        _e( 'MEMBER PRICING', 'lifterlms' );
                        ?></em>
											<ul>
												<?php 
                        foreach ( $plan->get_array( 'availability_restrictions' ) as $mid ) {
                            ?>
													<li><a href="<?php 
                            echo  get_permalink( $mid ) ;
                            ?>"><?php 
                            echo  get_the_title( $mid ) ;
                            ?></a></li>
												<?php 
                        }
                        ?>
											</ul>
										</div>
									<?php 
                    }
                    
                    ?>
									
								</div>

								<div class="le-access-plan-content">

									<!-- access_plan_description -->
									<div class="le-access-plan-description"><?php 
                    echo  $plan->get( 'content' ) ;
                    ?></div>

								</div>

								<div class="le-access-plan-footer">


									<!-- access_plan_trial -->
									<?php 
                    
                    if ( class_exists( 'WooCommerce' ) && 'yes' === get_option( 'lifterlms_woocommerce_enabled', 'no' ) ) {
                    } else {
                        ?>

										<div class="le-access-plan-pricing trial">
											<?php 
                        
                        if ( $plan->has_trial() ) {
                            ?>
												<div class="le-access-plan-trial-price">
													<?php 
                            echo  $plan->get_price( 'trial_price' ) ;
                            ?>
													<span class="stamp"><?php 
                            _e( 'TRIAL', 'lifterlms' );
                            ?></span>
												</div>
												<div class="le-access-plan-trial"><?php 
                            echo  $plan->get_trial_details() ;
                            ?></div>
											<?php 
                        } else {
                            ?>
												
											<?php 
                        }
                        
                        ?>
										</div>
									<?php 
                    }
                    
                    ?>

									<!-- access_plan_button -->
									<?php 
                    
                    if ( get_current_user_id() && $plan->has_free_checkout() && $plan->is_available_to_user() ) {
                        ?>
										<?php 
                        llms_get_template( 'product/free-enroll-form.php', compact( 'plan' ) );
                        ?>
									<?php 
                    } else {
                        ?>
										<a class="le-button-action button" href="<?php 
                        echo  $plan->get_checkout_url() ;
                        ?>"><?php 
                        echo  $plan->get_enroll_text() ;
                        ?></a>
									<?php 
                    }
                    
                    ?>

								</div>

							</div>


							<?php 
                    /**
                     * llms_after_access_plan
                     */
                    do_action( 'llms_after_access_plan', $plan );
                    ?>

						</div>

					<?php 
                }
                ?>

					<?php 
                do_action( 'lifterlms_after_access_plans_loop', $product->get( 'id' ) );
                ?>

				</section>

				<?php 
                do_action( 'lifterlms_after_access_plans', $product->get( 'id' ) );
                ?>

			<?php 
            }
            
            ?>

		<?php 
        } elseif ( !$is_enrolled ) {
            ?>

			<?php 
            do_action( 'lifterlms_product_not_purchasable', $product->get( 'id' ) );
            ?>

			<?php 
            
            if ( 'course' === $product->get( 'type' ) ) {
                $course = new LLMS_Course( $product->post );
                ?>
				<?php 
                
                if ( 'yes' === $course->get( 'enrollment_period' ) ) {
                    ?>
					<?php 
                    
                    if ( !$course->has_date_passed( 'enrollment_start_date' ) ) {
                        ?>
						<?php 
                        llms_print_notice( $course->get( 'enrollment_opens_message' ), 'notice' );
                        ?>
					<?php 
                    } elseif ( $course->has_date_passed( 'enrollment_end_date' ) ) {
                        ?>
						<?php 
                        llms_print_notice( $course->get( 'enrollment_closed_message' ), 'error' );
                        ?>
					<?php 
                    }
                    
                    ?>
				<?php 
                }
                
                ?>
				<?php 
                
                if ( !$course->has_capacity() ) {
                    ?>
					<?php 
                    llms_print_notice( $course->get( 'capacity_message' ), 'error' );
                    ?>
				<?php 
                }
                
                ?>
			<?php 
            }
            
            ?>

		<?php 
        }
        
        ?>

		<?php 
    }

}