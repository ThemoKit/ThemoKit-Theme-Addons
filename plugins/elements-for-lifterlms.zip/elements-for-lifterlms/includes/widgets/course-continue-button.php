<?php

/**
 * LifterLMS Title Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Course_Continue_Btn extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-course-continue-btn';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Course Continue Button', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-button';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms-course' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'content_students_section', [
            'label' => __( 'Enrolled Students', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'button_text_continue', [
            'label'       => __( 'Continue Button Text', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Continue', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'button_text_getstarted', [
            'label'       => __( 'Get Started Button Text', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Get Started', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'content_visitors_section', [
            'label' => __( 'Unenrolled Students & Visitors', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'control_get_pro_1', [
            'label'       => __( 'Only Available in Premium Version', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> to unlock the customization options.</span>',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'style_section', [
            'label' => __( 'Style', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'button_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-course-continue-button, {{WRAPPER}} .le-course-complete-text, {{WRAPPER}} .le-course-enroll-btn',
        ] );
        $this->start_controls_tabs( 'style_tabs' );
        $this->start_controls_tab( 'style_normal_tab', [
            'label' => __( 'Normal', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'button_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-course-continue-button, {{WRAPPER}} .le-course-enroll-btn' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'button_text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-course-continue-button, {{WRAPPER}} .le-course-enroll-btn' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-course-continue-button, {{WRAPPER}} .le-course-enroll-btn',
        ] );
        $this->add_control( 'border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-course-continue-button, {{WRAPPER}} .le-course-enroll-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .le-course-enroll-btn',
        ] );
        $this->end_controls_tab();
        $this->start_controls_tab( 'style_hover_tab', [
            'label' => __( 'Hover', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'button_hover_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_4,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-course-continue-button:hover, {{WRAPPER}} .le-course-enroll-btn:hover' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'button_text_hover_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-course-continue-button:hover, {{WRAPPER}} .le-course-enroll-btn:hover' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'hover_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-course-continue-button:hover, {{WRAPPER}} .le-course-enroll-btn:hover',
        ] );
        $this->add_control( 'hover_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-course-continue-button:hover, {{WRAPPER}} .le-course-enroll-btn:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'hover_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-course-continue-button:hover, {{WRAPPER}} .le-course-enroll-btn:hover',
        ] );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control( 'width', [
            'label'      => __( 'Width', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 1000,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => null,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-mark-complete-button-wrapper .llms-form-field, {{WRAPPER}} .le-course-continue-button, {{WRAPPER}} .le-course-enroll-btn' => 'width: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-course-continue-button, {{WRAPPER}} .le-course-enroll-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'go_premium_style', [
            'label' => __( 'Go Premium for More Features', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'control_get_pro_style', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more stunning widgets and customization options.</span>',
        ] );
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        global  $post ;
        $student = new LLMS_Student();
        $progress = $student->get_progress( $post->ID, 'course' );
        $course = llms_get_post( get_the_ID() );
        $instructors = $course->get_instructors( true );
        $count = count( $instructors );
        
        if ( class_exists( 'LifterLMS' ) && is_course() ) {
            ?>
			<div class="le-course-complete-btn le-align-<?php 
            echo  $settings['text_align'] ;
            ?>">
				<span class="le-continue-btn">
					<?php 
            $this->le_course_continue_button( $post->ID, $student, $progress );
            ?>
				</span>
			</div> <?php 
        } else {
            ?>
			<div class="le-widget-error">
				<p><?php 
            _e( 'This widget only works on LifterLMS Course Page', 'elements-for-lifterlms' );
            ?></p>
			</div>
			<?php 
        }
    
    }
    
    public function le_course_continue_button( $post_id = null, $student = null, $progress = null )
    {
        $settings = $this->get_settings_for_display();
        $continue_btn_txt = $settings['button_text_continue'];
        $getstarted_btn_txt = $settings['button_text_getstarted'];
        $enroll_btn_txt = $settings['button_text_enroll'];
        
        if ( !$post_id ) {
            $post_id = get_the_ID();
            if ( !$post_id ) {
                return '';
            }
        }
        
        $course = llms_get_post( $post_id );
        if ( !$course || !is_a( $course, 'LLMS_Post_Model' ) ) {
            return '';
        }
        
        if ( in_array( $course->get( 'type' ), array( 'lesson', 'quiz' ) ) ) {
            $course = llms_get_post_parent_course( $course->get( 'id' ) );
            if ( !$course ) {
                return '';
            }
        }
        
        if ( !$student ) {
            $student = llms_get_student();
        }
        // if ( ! $student || ! $student->exists() || ! llms_is_user_enrolled( $student->get_id(), $course->get( 'id' ) ) ) {
        // 	return '';
        // }
        if ( is_null( $progress ) ) {
            $progress = $student->get_progress( $course->get( 'id' ), 'course' );
        }
        
        if ( llms_is_user_enrolled( $student->get_id(), $course->get( 'id' ) ) ) {
            
            if ( 100 == $progress ) {
                echo  '<p class="le-course-complete-text">' . apply_filters( 'llms_course_continue_button_complete_text', __( 'Course Complete', 'lifterlms' ), $course ) . '</p>' ;
            } else {
                $lesson = apply_filters(
                    'llms_course_continue_button_next_lesson',
                    $student->get_next_lesson( $course->get( 'id' ) ),
                    $course,
                    $student
                );
                
                if ( $lesson ) {
                    ?>

					<a class="le-button le-course-continue-button" href="<?php 
                    echo  get_permalink( $lesson ) ;
                    ?>">

						<?php 
                    
                    if ( 0 == $progress ) {
                        ?>

							<?php 
                        echo  $getstarted_btn_txt ;
                        ?>

						<?php 
                    } else {
                        ?>

							<?php 
                        echo  $continue_btn_txt ;
                        ?>

						<?php 
                    }
                    
                    ?>

					</a>

				<?php 
                }
            
            }
        
        } else {
        }
    
    }

}