<?php

/**
 * LifterLMS Title Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Course_Instructors extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-course-instructors';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Course Instructors', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-image-box';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms-course' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'content_section', [
            'label' => __( 'Content', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'visibility', [
            'label'   => __( 'Enrollment Visibility', 'elements-for-lifterlms' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'everyone',
            'options' => [
            'everyone'   => __( 'Everyone', 'elements-for-lifterlms' ),
            'enrolled'   => __( 'Enrolled Students', 'elements-for-lifterlms' ),
            'unenrolled' => __( 'Unenrolled Students and Visitors', 'elements-for-lifterlms' ),
        ],
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'go_premium_content', [
            'label' => __( 'Go Premium for More Features', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'control_get_pro_content', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more stunning widgets and customization options.</span>',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'pricing_table_section', [
            'label' => __( 'Style', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'instructor_background_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-instructors.le-cols .le-author, {{WRAPPER}} .le-instructors .le-instructors-column' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'instructor_padding', [
            'label'       => __( 'Padding', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units'  => [ 'px', '%', 'em' ],
            'selectors'   => [
            '{{WRAPPER}} .le-instructors.le-cols .le-author' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
            'description' => __( '<span style="padding: 5px; border:1px solid #ddd; display: block;" class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>', 'elements-for-lifterlms' ),
        ] );
        //Photos
        $this->add_control( 'instructor_photo_title', [
            'label'     => __( 'Instructor\'s Photo', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'instructor_photo_width', [
            'label'      => __( 'Width', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 500,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 200,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-author-img img' => 'width: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'instructor_photo_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => '%',
            'size' => 50,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-author-img img' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        
        //Instructor Name
        $this->add_control( 'instructor_name_title', [
            'label'     => __( 'Instructor\'s Name', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'instructor_name_color', [
            'label'     => __( 'Period Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-author-info.name' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'instructor_name_typography',
            'label'    => __( 'Period Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-author-info.name',
        ] );
        //Instructor Label
        $this->add_control( 'instructor_label_title', [
            'label'     => __( 'Instructor\'s Label', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'instructor_label_color', [
            'label'     => __( 'Instructor\'s Label Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-author-label.label' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'instructor_label_typography',
            'label'    => __( 'Instructor\'s Label Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-author-label.label',
        ] );
        //Instructor Bio
        $this->add_control( 'instructor_bio_title', [
            'label'     => __( 'Instructor\'s Bio', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'instructor_bio_color', [
            'label'     => __( 'Instructor\'s Bio Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-author-info.bio' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'instructor_bio_typography',
            'label'    => __( 'Instructor\'s Bio Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-author-info.bio',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'go_premium_style', [
            'label' => __( 'Go Premium for More Features', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'control_get_pro_style', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more stunning widgets and customization options.</span>',
        ] );
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        global  $post ;
        $course = llms_get_post( get_the_ID() );
        $instructors = $course->get_instructors( true );
        $count = count( $instructors );
        $student = llms_get_student();
        $settings = $this->get_settings_for_display();
        
        if ( class_exists( 'LifterLMS' ) && is_course() ) {
            
            if ( 'everyone' === $settings['visibility'] ) {
                ?>
			    <section class="le-instructor clear">
					<div class="le-instructors le-cols <?php 
                if ( 'yes' === $settings['instructor_height'] ) {
                    ?>equal-height<?php 
                }
                ?>">
						<?php 
                foreach ( $instructors as $instructor ) {
                    ?>
							<div class="le-instructors-column le-col-<?php 
                    echo  ( $count <= 4 ? $count : 4 ) ;
                    ?>">
								<?php 
                    echo  $this->le_get_author( array(
                        'avatar_size' => 300,
                        'bio'         => true,
                        'label'       => $instructor['label'],
                        'user_id'     => $instructor['id'],
                    ) ) ;
                    ?>
							</div>
						<?php 
                }
                ?>
					</div>
				</section> <?php 
            } elseif ( 'enrolled' === $settings['visibility'] ) {
                
                if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                    ?>
				    <section class="le-instructor clear">
						<div class="le-instructors le-cols <?php 
                    if ( 'yes' === $settings['instructor_height'] ) {
                        ?>equal-height<?php 
                    }
                    ?>">
							<?php 
                    foreach ( $instructors as $instructor ) {
                        ?>
								<div class="le-instructors-column le-col-<?php 
                        echo  ( $count <= 4 ? $count : 4 ) ;
                        ?>">
									<?php 
                        echo  $this->le_get_author( array(
                            'avatar_size' => 300,
                            'bio'         => true,
                            'label'       => $instructor['label'],
                            'user_id'     => $instructor['id'],
                        ) ) ;
                        ?>
								</div>
							<?php 
                    }
                    ?>
						</div>
					</section> <?php 
                }
            
            } elseif ( 'unenrolled' === $settings['visibility'] ) {
                
                if ( !llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                    ?>
				    <section class="le-instructor clear">
						<div class="le-instructors le-cols <?php 
                    if ( 'yes' === $settings['instructor_height'] ) {
                        ?>equal-height<?php 
                    }
                    ?>">
							<?php 
                    foreach ( $instructors as $instructor ) {
                        ?>
								<div class="le-instructors-column le-col-<?php 
                        echo  ( $count <= 4 ? $count : 4 ) ;
                        ?>">
									<?php 
                        echo  $this->le_get_author( array(
                            'avatar_size' => 300,
                            'bio'         => true,
                            'label'       => $instructor['label'],
                            'user_id'     => $instructor['id'],
                        ) ) ;
                        ?>
								</div>
							<?php 
                    }
                    ?>
						</div>
					</section> <?php 
                }
            
            }
        
        } else {
            ?>
			<div class="le-widget-error">
				<p><?php 
            _e( 'This widget only works on LifterLMS Course Page', 'elements-for-lifterlms' );
            ?></p>
			</div>
			<?php 
        }
    
    }
    
    /**
     * Retrieve Course author name, avatar, and bio
     * @param    array      $args  arguments
     * @return   string
     * @since    3.0.0
     * @version  3.13.0
     */
    function le_get_author( $args = array() )
    {
        $args = wp_parse_args( $args, array(
            'avatar'      => true,
            'avatar_size' => 96,
            'bio'         => false,
            'label'       => '',
            'user_id'     => get_the_author_meta( 'ID' ),
        ) );
        $name = get_the_author_meta( 'display_name', $args['user_id'] );
        
        if ( $args['avatar'] ) {
            $img = get_avatar(
                $args['user_id'],
                $args['avatar_size'],
                apply_filters( 'lifterlms_author_avatar_placeholder', '' ),
                $name
            );
        } else {
            $img = '';
        }
        
        $img = apply_filters( 'llms_get_author_image', $img );
        $desc = '';
        if ( $args['bio'] ) {
            $desc = get_the_author_meta( 'description', $args['user_id'] );
        }
        ob_start();
        ?>
		<div class="le-author clear">
			<div class="le-author-img">
				<?php 
        echo  $img ;
        ?>
				<span></span>
			</div>
			<div class="le-author-info-wrap">
				<span class="le-author-info name"><?php 
        echo  $name ;
        ?></span>
				<?php 
        
        if ( $args['label'] ) {
            ?>
				<span class="le-author-label label"><?php 
            echo  $args['label'] ;
            ?></span>
			<?php 
        }
        
        ?>
				<?php 
        
        if ( $desc ) {
            ?>
					<p class="le-author-info bio"><?php 
            echo  $desc ;
            ?></p>
				<?php 
        }
        
        ?>
			</div>
		</div>
		<?php 
        $html = ob_get_clean();
        return apply_filters( 'llms_get_author', $html );
    }

}