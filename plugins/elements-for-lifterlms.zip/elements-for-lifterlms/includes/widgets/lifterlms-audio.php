<?php
/**
 * LifterLMS Lesson Video Widget.
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Audio extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'le-lifterlms-audio';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Course/Lesson Audio', 'elements-for-lifterlms' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-headphones';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'elements-for-lifterlms' ];
	}

	/**
	 * Register widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'elements-for-lifterlms' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'visibility',
			[
				'label' => __( 'Enrollment Visibility', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'everyone',
				'options' => [
					'everyone'  => __( 'Everyone', 'elements-for-lifterlms' ),
					'enrolled' => __( 'Enrolled Students', 'elements-for-lifterlms' ),
					'unenrolled' => __( 'Unenrolled Students and Visitors', 'elements-for-lifterlms' ),
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		global $post;

		if( class_exists( 'LifterLMS' ) && is_course() ) { 

			$course = new LLMS_Course( $post );

		}

		if( class_exists( 'LifterLMS' ) && is_lesson() ) { 
			$lesson = new LLMS_Lesson( $post->ID );
			$course_id = $lesson->get_parent_course();
			$course = new LLMS_Course( $course_id );
		}

		$student = llms_get_student(); 

		$settings = $this->get_settings_for_display();

		if( class_exists( 'LifterLMS' ) ) { 

			if ( 'everyone' === $settings['visibility'] ){

				if( is_course() ) { 

					if ( ! $course->get_audio() ) { return; } ?>

					<div class="llms-audio-wrapper">
						<div class="center-audio">
							<?php echo $course->get_audio(); ?>
						</div>
					</div> <?php

				}elseif( is_lesson() ) { 

					if ( ! $lesson->get( 'video_embed' ) ) { return; }?>

					<div class="llms-audio-wrapper">
						<div class="center-audio">
							<?php echo $lesson->get_audio(); ?>
						</div>
					</div> <?php

				}else{
					?>
					<div class="le-widget-error">
						<p>This widget only works on LifterLMS Course/Lesson Page</p>
					</div>
					<?php
				}

			}elseif ( 'enrolled' === $settings['visibility'] ){
				if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {

					if( is_course() ) { 

						if ( ! $course->get_audio() ) { return; } ?>

						<div class="llms-audio-wrapper">
							<div class="center-audio">
								<?php echo $course->get_audio(); ?>
							</div>
						</div> <?php

					}elseif( is_lesson() ) { 

						if ( ! $lesson->get( 'video_embed' ) ) { return; }?>

						<div class="llms-audio-wrapper">
							<div class="center-audio">
								<?php echo $lesson->get_audio(); ?>
							</div>
						</div> <?php

					}else{
						?>
						<div class="le-widget-error">
							<p>This widget only works on LifterLMS Course/Lesson Page</p>
						</div>
						<?php
					}

				}

			}elseif ( 'unenrolled' === $settings['visibility'] ){

				if ( !llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
					if( is_course() ) { 

						if ( ! $course->get_audio() ) { return; } ?>

						<div class="llms-audio-wrapper">
							<div class="center-audio">
								<?php echo $course->get_audio(); ?>
							</div>
						</div> <?php

					}elseif( is_lesson() ) { 

						if ( ! $lesson->get( 'video_embed' ) ) { return; }?>

						<div class="llms-audio-wrapper">
							<div class="center-audio">
								<?php echo $lesson->get_audio(); ?>
							</div>
						</div> <?php

					}else{
						?>
						<div class="le-widget-error">
							<p>This widget only works on LifterLMS Course/Lesson Page</p>
						</div>
						<?php
					}
				}
			}

		}else{
			?>
			<div class="le-widget-error">
				<p><?php _e( 'This widget only works on LifterLMS Lesson Page', 'elements-for-lifterlms' ); ?></p>
			</div>
			<?php
		}
		

	}

	

}
