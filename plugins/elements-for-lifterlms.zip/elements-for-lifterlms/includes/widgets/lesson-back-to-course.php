<?php
/**
 * LifterLMS Title Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Lesson_Backtocourse extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'le-lifterlms-lesson-back-to-course';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Back to Course Link', 'elements-for-lifterlms' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-angle-left';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'elements-for-lifterlms-lesson' ];
	}

	/**
	 * Register widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'elements-for-lifterlms' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'widget_text',
			[
				'label' => __( 'Custom Text', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Back to', 'elements-for-lifterlms' ),
				'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
			]
		);

		$this->add_control(
			'text_icon',
			[
				'label' => __( 'Icon', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'include' => [
					'fa fa-chevron-left',
					'fa fa-angle-double-left',
					'fa fa-caret-left',
					'fa fa-arrow-left',
					'fa fa-chevron-circle-left',
				],
				'default' => '',
			]
		);

		$this->add_control(
			'hide_course_name',
			[
				'label' => __( 'Hide Course Name', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'On', 'elements-for-lifterlms' ),
				'label_off' => __( 'Off', 'elements-for-lifterlms' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		

		$this->end_controls_section();



		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Style', 'elements-for-lifterlms' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Typography', 'elements-for-lifterlms' ),
				'selector' => '{{WRAPPER}} .le-parent-course-link .le-lesson-link',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Text Color', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .le-parent-course-link .le-lesson-link' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'hover_text_color',
			[
				'label' => __( 'Hover Text Color', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .le-parent-course-link .le-lesson-link:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .le-parent-course-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_align',
			[
				'label' => __( 'Alignment', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {	
		$settings = $this->get_settings_for_display();
		global $post;

		$lesson = new LLMS_Lesson( $post );

		$custom_txt = $settings['widget_text'];


		if( class_exists( 'LifterLMS' ) && is_lesson() ) { ?>
			<div class="le-parent-course-link-wrap le-align-<?php echo $settings['text_align'] ?>">
				<p class="le-parent-course-link">
				<a class="le-lesson-link" href="<?php echo  get_permalink( $lesson->get_parent_course() ); ?>">
					<i class="<?php echo $settings['text_icon']; ?>" aria-hidden="true"></i>
					<?php echo $custom_txt; ?> 
					<?php if ( 'yes' === $settings['hide_course_name'] ) {}else{ ?>
						<?php echo  get_the_title( $lesson->get_parent_course() ); ?>	
					<?php } ?>
				</a>
				</p>
			</div> <?php
		}else{
			?>
			<div class="le-widget-error">
				<p><?php _e( 'This widget only works on LifterLMS Lesson Page', 'elements-for-lifterlms' ); ?></p>
			</div>
			<?php
		}

		
	}

	

}
