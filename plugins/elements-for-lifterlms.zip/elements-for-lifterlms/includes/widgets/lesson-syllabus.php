<?php

/**
 * LifterLMS Title Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Lesson_Syllabus extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-lesson-syllabus';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Course Syllabus in Lesson', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-bullet-list';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms-lesson' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'header_style_section', [
            'label' => __( 'Section Heading', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'heading_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-section-title',
        ] );
        $this->add_control( 'text_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-section-title' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'head_bg_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-section-heading' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-section-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'heading_align', [
            'label'   => __( 'Alignment', 'elements-for-lifterlms' ),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
            'left'   => [
            'title' => __( 'Left', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-left',
        ],
            'center' => [
            'title' => __( 'Center', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-center',
        ],
            'right'  => [
            'title' => __( 'Right', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-right',
        ],
        ],
            'default' => 'left',
            'toggle'  => true,
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'lesson_style_section', [
            'label' => __( 'Lesson', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'lesson_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .syllabus-lesson-wrap',
        ] );
        $this->add_control( 'lesson_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .syllabus-lesson-wrap' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'lesson_bg_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-single-syllabus-lesson' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'lesson_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-single-syllabus-lesson' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'lesson_complete_color', [
            'label'     => __( 'Lesson Complete Icon Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-lesson-complete-icon' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'hr', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ] );
        $this->add_control( 'control_get_pro_1', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        global  $post ;
        $lesson = new LLMS_Lesson( $post->ID );
        $course_id = $lesson->get_parent_course();
        $course = new LLMS_Course( $course_id );
        $student = llms_get_student();
        $restrictions = llms_page_restricted( $lesson->get( 'id' ), get_current_user_id() );
        $data_msg = ( $restrictions['is_restricted'] ? ' data-tooltip-msg="' . esc_html( strip_tags( llms_get_restriction_message( $restrictions ) ) ) . '"' : '' );
        // retrieve sections to use in the template
        $sections = $course->get_sections( 'posts' );
        $settings = $this->get_settings_for_display();
        
        if ( class_exists( 'LifterLMS' ) && is_lesson() ) {
            ?>

			<div class="lesson-syllabus-wrap">

				<div class="clear"></div>
				<div class="le-syllabus-wrapper le-lesson-syllabus" id="lesson-syllabus">
					
					<?php 
            
            if ( !$sections ) {
                ?>

						<?php 
                _e( 'This course does not have any sections.', 'elements-for-lifterlms' );
                ?>

					<?php 
            } else {
                ?>

						<?php 
                foreach ( $sections as $s ) {
                    $section = new LLMS_Section( $s->ID );
                    ?>

							<div class="le-syllabus-section section-<?php 
                    echo  $section->get_order() ;
                    ?>">
								<div class="le-section-heading le-align-<?php 
                    echo  $settings['heading_align'] ;
                    ?>">
									<?php 
                    
                    if ( apply_filters( 'llms_display_outline_section_titles', true ) ) {
                        ?>
										<h3 class="le-section-title"><?php 
                        echo  get_the_title( $s->ID ) ;
                        ?></h3>
									<?php 
                    }
                    
                    ?>
								</div>
								<div class="le-syllabus-lessons">
								
									<?php 
                    $lessons = $section->get_lessons( "posts" );
                    
                    if ( $lessons ) {
                        ?>

										<?php 
                        foreach ( $lessons as $l ) {
                            $llms_lessons = new LLMS_Lesson( $l->ID );
                            $llms_lessons_id = $l->ID;
                            $current_post_id = $post->ID;
                            ?>
											
											<div class="le-single-syllabus-lesson">
												<?php 
                            
                            if ( $llms_lessons->is_free() || llms_is_user_enrolled( get_current_user_id(), $course->get( 'id' ) ) ) {
                                ?>
													<a class="llms-lesson-link" href="<?php 
                                echo  get_the_permalink( $l->ID ) ;
                                ?>">
												<?php 
                            } else {
                                ?>
													<a class="llms-lesson-link<?php 
                                echo  ( $restrictions['is_restricted'] ? ' llms-lesson-link-locked' : '' ) ;
                                ?>" href="#llms-lesson-locked"<?php 
                                echo  $data_msg ;
                                ?>>
													<!-- <div class="lesson-tooltip"><div class="lesson-tooltip-content">You must enroll in this course to access course content.</div></div> -->
												<?php 
                            }
                            
                            ?>
												<div class="syllabus-lesson-wrap <?php 
                            if ( $llms_lessons_id == $current_post_id ) {
                                ?>current<?php 
                            }
                            ?>" <?php 
                            if ( $llms_lessons_id == $current_post_id ) {
                                ?>id="current-lesson"<?php 
                            }
                            ?>>

													<?php 
                            
                            if ( llms_is_user_enrolled( $student->get_id(), $course->get( 'id' ) ) ) {
                                ?>
														<span class="le-lesson-complete">
														<?php 
                                //load student object
                                $user_id = get_current_user_id();
                                $student = new LLMS_Student( $user_id );
                                $is_complete = $student->is_complete( $l->ID, 'lesson' );
                                //check if lesson is complete then change icon
                                
                                if ( $is_complete ) {
                                    ?>

															<?php 
                                    ?>
																<span class="le-lesson-complete-icon"><i class="fa fa-check-square" aria-hidden="true"></i></span>
															<?php 
                                    ?>


														<?php 
                                } else {
                                    ?>

															<?php 
                                    ?>
																<span class="le-lesson-incomplete-icon"><i class="fa fa-check-square" aria-hidden="true"></i></span>
															<?php 
                                    ?>

														<?php 
                                }
                                
                                ?>
														</span>
													<?php 
                            }
                            
                            ?>

													<?php 
                            ?>

													<span class="lesson-title ">
														<?php 
                            echo  get_the_title( $l->ID ) ;
                            ?>
													</span>
													
												</div>
												<?php 
                            if ( $restrictions['is_restricted'] ) {
                                ?>
												<?php 
                            }
                            ?>
												</a>
											</div>
										<?php 
                        }
                        ?>

									<?php 
                    } else {
                        ?>

										<?php 
                        _e( 'This section does not have any lessons.', 'elements-for-lifterlms' );
                        ?>

									<?php 
                    }
                    
                    ?>

								</div>

							</div>

						<?php 
                }
                ?>

					<?php 
            }
            
            ?>

				</div>

			</div> <?php 
        } else {
            ?>
			<div class="le-widget-error">
				<p><?php 
            _e( 'This widget only works on LifterLMS Lesson Page', 'elements-for-lifterlms' );
            ?></p>
			</div>
			<?php 
        }
    
    }

}