<?php

/**
 * LifterLMS Lesson Navigation Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Lesson_Navigation extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-lesson-navigation';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Lesson Navigation', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-post-navigation';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms-lesson' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'content_section', [
            'label' => __( 'Content', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'previous_lesson_text', [
            'label'       => __( 'Previous Lesson Text', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Previous Lesson', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'next_lesson_text', [
            'label'       => __( 'Next Lesson Text', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Next Lesson', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'back_to_course_text', [
            'label'       => __( 'Back to Course Text', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Back to Course', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'hr', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ] );
        $this->add_control( 'control_get_pro_1', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'style_section', [
            'label' => __( 'Style', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'link_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .llms-lesson-link',
        ] );
        $this->add_control( 'padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .llms-lesson-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->start_controls_tabs( 'style_tabs' );
        $this->start_controls_tab( 'style_normal_tab', [
            'label' => __( 'Normal', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .llms-lesson-link' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'hr', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ] );
        $this->add_control( 'control_get_pro_2', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_tab();
        $this->start_controls_tab( 'style_hover_tab', [
            'label' => __( 'Hover', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'hover_text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .llms-lesson-link:hover' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'hr', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ] );
        $this->add_control( 'control_get_pro_3', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        global  $post ;
        $lesson = new LLMS_Lesson( $post->ID );
        $prev_id = $lesson->get_previous_lesson();
        $next_id = $lesson->get_next_lesson();
        $restrictions = llms_page_restricted( $lesson->get( 'id' ), get_current_user_id() );
        $data_msg = ( $restrictions['is_restricted'] ? ' data-tooltip-msg="' . esc_html( strip_tags( llms_get_restriction_message( $restrictions ) ) ) . '"' : '' );
        $settings = $this->get_settings_for_display();
        $prev_lesson_txt = $settings['previous_lesson_text'];
        $next_lesson_txt = $settings['next_lesson_text'];
        $to_course_txt = $settings['back_to_course_text'];
        $is_pro_active = 'no';
        
        if ( class_exists( 'LifterLMS' ) && is_lesson() ) {
            ?>

			<nav class="le-lesson-navigation clear">

				<?php 
            
            if ( $prev_id ) {
                ?>

					<div class="le-lesson-navigation-btn le-prev-lesson <?php 
                
                if ( yes == $settings['button_tyle'] && $is_pro_active == 'yes' ) {
                    ?>button-style<?php 
                } else {
                    ?>link-style<?php 
                }
                
                ?>">
						<?php 
                $lesson = new LLMS_Lesson( $prev_id );
                $restrictions = llms_page_restricted( $lesson->get( 'id' ), get_current_user_id() );
                $data_msg = ( $restrictions['is_restricted'] ? ' data-tooltip-msg="' . esc_html( strip_tags( llms_get_restriction_message( $restrictions ) ) ) . '"' : '' );
                ?>
						<a class="llms-lesson-link<?php 
                echo  ( $restrictions['is_restricted'] ? ' le-lesson-link-locked' : '' ) ;
                
                if ( 'show_on_hover' == $settings['icon_style'] && $is_pro_active == 'yes' ) {
                    ?> show-on-hover<?php 
                } elseif ( 'hide_on_hover' == $settings['icon_style'] && $is_pro_active == 'yes' ) {
                    ?> hide-on-hover<?php 
                } else {
                    ?> always <?php 
                }
                
                ?>" href="<?php 
                echo  ( !$restrictions['is_restricted'] ? get_permalink( $lesson->get( 'id' ) ) : '#llms-lesson-locked' ) ;
                ?>"<?php 
                echo  $data_msg ;
                ?>>

							<?php 
                ?>
							<?php 
                echo  $prev_lesson_txt ;
                ?>
						</a>
					</div>

				<?php 
            }
            
            ?>

				<?php 
            
            if ( !$prev_id || !$next_id ) {
                ?>
					<div class="le-lesson-navigation-btn le-back-to-course <?php 
                
                if ( yes == $settings['button_tyle'] && $is_pro_active == 'yes' ) {
                    ?>button-style<?php 
                } else {
                    ?>link-style<?php 
                }
                
                ?>">
							<a class="llms-lesson-link<?php 
                
                if ( 'show_on_hover' == $settings['icon_style'] && $is_pro_active == 'yes' ) {
                    ?> show-on-hover<?php 
                } elseif ( 'hide_on_hover' == $settings['icon_style'] && $is_pro_active == 'yes' ) {
                    ?> hide-on-hover<?php 
                } else {
                    ?> always <?php 
                }
                
                ?>" href="<?php 
                echo  get_permalink( $lesson->get_parent_course() ) ;
                ?>">
								<?php 
                ?>
								<?php 
                echo  $to_course_txt ;
                ?>
							</a>
					</div>
				<?php 
            }
            
            ?>

				<?php 
            
            if ( $next_id ) {
                ?>

					<div class="le-lesson-navigation-btn le-next-lesson <?php 
                
                if ( yes == $settings['button_tyle'] && $is_pro_active == 'yes' ) {
                    ?>button-style<?php 
                } else {
                    ?>link-style<?php 
                }
                
                ?>">
						<?php 
                $lesson = new LLMS_Lesson( $next_id );
                $restrictions = llms_page_restricted( $lesson->get( 'id' ), get_current_user_id() );
                $data_msg = ( $restrictions['is_restricted'] ? ' data-tooltip-msg="' . esc_html( strip_tags( llms_get_restriction_message( $restrictions ) ) ) . '"' : '' );
                ?>
						 <a class="llms-lesson-link<?php 
                echo  ( $restrictions['is_restricted'] ? ' le-lesson-link-locked' : '' ) ;
                
                if ( 'show_on_hover' == $settings['icon_style'] && $is_pro_active == 'yes' ) {
                    ?> show-on-hover<?php 
                } elseif ( 'hide_on_hover' == $settings['icon_style'] && $is_pro_active == 'yes' ) {
                    ?> hide-on-hover<?php 
                } else {
                    ?> always <?php 
                }
                
                ?>" href="<?php 
                echo  ( !$restrictions['is_restricted'] ? get_permalink( $lesson->get( 'id' ) ) : '#llms-lesson-locked' ) ;
                ?>"<?php 
                echo  $data_msg ;
                ?>>
							<?php 
                echo  $next_lesson_txt ;
                ?>
							<?php 
                ?>
								</i>
						</a>
					</div>

				<?php 
            }
            
            ?>



			</nav> <?php 
        } else {
            ?>
			<div class="le-widget-error">
				<p><?php 
            _e( 'This widget only works on LifterLMS Lesson Page', 'elements-for-lifterlms' );
            ?></p>
			</div>
			<?php 
        }
    
    }

}