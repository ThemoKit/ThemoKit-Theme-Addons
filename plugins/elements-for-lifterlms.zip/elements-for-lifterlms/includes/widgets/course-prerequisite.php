<?php

/**
 * LifterLMS Lesson Video Widget.
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Course_Prerequisite extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-prerequisite';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Course Prerequisite', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-post-info';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms-course' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'content_section', [
            'label' => __( 'Content', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'visibility', [
            'label'   => __( 'Enrollment Visibility', 'elements-for-lifterlms' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'everyone',
            'options' => [
            'everyone'   => __( 'Everyone', 'elements-for-lifterlms' ),
            'enrolled'   => __( 'Enrolled Students', 'elements-for-lifterlms' ),
            'unenrolled' => __( 'Unenrolled Students and Visitors', 'elements-for-lifterlms' ),
        ],
        ] );
        $this->add_control( 'course_prerequisite_title', [
            'label'     => __( 'Course Prerequisite', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'course_prerequisite_text', [
            'label'       => __( 'Custom Text', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'rows'        => 6,
            'default'     => __( 'Before starting this course you must complete the required prerequisite course:', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'track_prerequisite_title', [
            'label'     => __( 'Track Prerequisite', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'track_prerequisite_text', [
            'label'       => __( 'Custom Text', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'rows'        => 6,
            'default'     => __( 'Before starting this course you must complete the required prerequisite track:', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'go_premium_content', [
            'label' => __( 'Go Premium for More Features', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'control_get_pro_content', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more stunning widgets and customization options.</span>',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'style_section', [
            'label' => __( 'Style', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'prerequisite_background_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-prerequisite-notice' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'prerequisite_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-prerequisite-notice',
        ] );
        $this->add_control( 'text_align', [
            'label'   => __( 'Alignment', 'elements-for-lifterlms' ),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
            'left'   => [
            'title' => __( 'Left', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-left',
        ],
            'center' => [
            'title' => __( 'Center', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-center',
        ],
            'right'  => [
            'title' => __( 'Right', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-right',
        ],
        ],
            'default' => 'left',
            'toggle'  => true,
        ] );
        $this->add_control( 'prerequisite_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-prerequisite-notice' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'prerequisite_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-prerequisite-notice',
        ] );
        $this->add_control( 'text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-prerequisite-text' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'text_typography',
            'label'    => __( 'Text Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-prerequisite-text',
        ] );
        $this->add_control( 'link_color', [
            'label'     => __( 'Link Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-prerequisite-link' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'link_typography',
            'label'    => __( 'Link Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-prerequisite-link',
        ] );
        $this->add_control( 'hr', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ] );
        $this->add_control( 'control_get_pro_1', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        
        if ( class_exists( 'LifterLMS' ) && is_course() ) {
            global  $post ;
            $course = new LLMS_Course( $post );
            $settings = $this->get_settings_for_display();
            $course_prerequisite_text = $settings['course_prerequisite_text'];
            $track_prerequisite_text = $settings['track_prerequisite_text'];
            $student = llms_get_student();
            $is_pro_active = 'no';
            ?>

			<?php 
            
            if ( 'everyone' === $settings['visibility'] ) {
                
                if ( $course->has_prerequisite( 'course' ) && !$course->is_prerequisite_complete( 'course' ) ) {
                    $prereq_id = $course->get_prerequisite_id( 'course' );
                    ?>

					<div class="le-prerequisite-notice le-align-<?php 
                    echo  $settings['text_align'] ;
                    ?> <?php 
                    if ( 'yes' === $settings['stick_to_bottom'] && $is_pro_active === 'yes' ) {
                        ?>sticky<?php 
                    }
                    ?>">
						<p><span class="le-prerequisite-text"><?php 
                    echo  $course_prerequisite_text ;
                    ?> </span><a class="le-prerequisite-link <?php 
                    if ( 'yes' === $settings['show_link_as_button'] && $is_pro_active === 'yes' ) {
                        ?>button-style<?php 
                    }
                    ?>" href="<?php 
                    echo  get_permalink( $prereq_id ) ;
                    ?>"><?php 
                    echo  get_the_title( $prereq_id ) ;
                    ?></a></p>
					</div>

				<?php 
                }
                
                ?>

				<?php 
                
                if ( $course->has_prerequisite( 'course_track' ) && !$course->is_prerequisite_complete( 'course_track' ) ) {
                    $track = new LLMS_Track( $course->get_prerequisite_id( 'course_track' ) );
                    ?>

					<div class="le-prerequisite-notice le-align-<?php 
                    echo  $settings['text_align'] ;
                    ?> <?php 
                    if ( 'yes' === $settings['stick_to_bottom'] && $is_pro_active === 'yes' ) {
                        ?>sticky<?php 
                    }
                    ?>">
						<p><span class="le-prerequisite-text"><?php 
                    echo  $track_prerequisite_text ;
                    ?> </span><a class="le-prerequisite-link <?php 
                    if ( 'yes' === $settings['show_link_as_button'] && $is_pro_active === 'yes' ) {
                        ?>button-style<?php 
                    }
                    ?>" href="<?php 
                    echo  get_permalink( $prereq_id ) ;
                    ?>"><?php 
                    echo  get_the_title( $prereq_id ) ;
                    ?></a></p>
					</div>

				<?php 
                }
            
            } elseif ( 'enrolled' === $settings['visibility'] ) {
                
                if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                    
                    if ( $course->has_prerequisite( 'course' ) && !$course->is_prerequisite_complete( 'course' ) ) {
                        $prereq_id = $course->get_prerequisite_id( 'course' );
                        ?>

						<div class="le-prerequisite-notice le-align-<?php 
                        echo  $settings['text_align'] ;
                        ?> <?php 
                        if ( 'yes' === $settings['stick_to_bottom'] && $is_pro_active === 'yes' ) {
                            ?>sticky<?php 
                        }
                        ?>">
							<p><span class="le-prerequisite-text"><?php 
                        echo  $course_prerequisite_text ;
                        ?> </span><a class="le-prerequisite-link <?php 
                        if ( 'yes' === $settings['show_link_as_button'] && $is_pro_active === 'yes' ) {
                            ?>button-style<?php 
                        }
                        ?>" href="<?php 
                        echo  get_permalink( $prereq_id ) ;
                        ?>"><?php 
                        echo  get_the_title( $prereq_id ) ;
                        ?></a></p>
						</div>

					<?php 
                    }
                    
                    ?>

					<?php 
                    
                    if ( $course->has_prerequisite( 'course_track' ) && !$course->is_prerequisite_complete( 'course_track' ) ) {
                        $track = new LLMS_Track( $course->get_prerequisite_id( 'course_track' ) );
                        ?>

						<div class="le-prerequisite-notice le-align-<?php 
                        echo  $settings['text_align'] ;
                        ?> <?php 
                        if ( 'yes' === $settings['stick_to_bottom'] && $is_pro_active === 'yes' ) {
                            ?>sticky<?php 
                        }
                        ?>">
							<p><span class="le-prerequisite-text"><?php 
                        echo  $track_prerequisite_text ;
                        ?> </span><a class="le-prerequisite-link <?php 
                        if ( 'yes' === $settings['show_link_as_button'] && $is_pro_active === 'yes' ) {
                            ?>button-style<?php 
                        }
                        ?>" href="<?php 
                        echo  get_permalink( $prereq_id ) ;
                        ?>"><?php 
                        echo  get_the_title( $prereq_id ) ;
                        ?></a></p>
						</div>

					<?php 
                    }
                
                }
            
            } elseif ( 'unenrolled' === $settings['visibility'] ) {
                
                if ( !llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                    
                    if ( $course->has_prerequisite( 'course' ) && !$course->is_prerequisite_complete( 'course' ) ) {
                        $prereq_id = $course->get_prerequisite_id( 'course' );
                        ?>

						<div class="le-prerequisite-notice le-align-<?php 
                        echo  $settings['text_align'] ;
                        ?> <?php 
                        if ( 'yes' === $settings['stick_to_bottom'] && $is_pro_active === 'yes' ) {
                            ?>sticky<?php 
                        }
                        ?>">
							<p><span class="le-prerequisite-text"><?php 
                        echo  $course_prerequisite_text ;
                        ?> </span><a class="le-prerequisite-link <?php 
                        if ( 'yes' === $settings['show_link_as_button'] && $is_pro_active === 'yes' ) {
                            ?>button-style<?php 
                        }
                        ?>" href="<?php 
                        echo  get_permalink( $prereq_id ) ;
                        ?>"><?php 
                        echo  get_the_title( $prereq_id ) ;
                        ?></a></p>
						</div>

					<?php 
                    }
                    
                    ?>

					<?php 
                    
                    if ( $course->has_prerequisite( 'course_track' ) && !$course->is_prerequisite_complete( 'course_track' ) ) {
                        $track = new LLMS_Track( $course->get_prerequisite_id( 'course_track' ) );
                        ?>

						<div class="le-prerequisite-notice le-align-<?php 
                        echo  $settings['text_align'] ;
                        ?> <?php 
                        if ( 'yes' === $settings['stick_to_bottom'] && $is_pro_active === 'yes' ) {
                            ?>sticky<?php 
                        }
                        ?>">
							<p><span class="le-prerequisite-text"><?php 
                        echo  $track_prerequisite_text ;
                        ?> </span><a class="le-prerequisite-link <?php 
                        if ( 'yes' === $settings['show_link_as_button'] && $is_pro_active === 'yes' ) {
                            ?>button-style<?php 
                        }
                        ?>" href="<?php 
                        echo  get_permalink( $prereq_id ) ;
                        ?>"><?php 
                        echo  get_the_title( $prereq_id ) ;
                        ?></a></p>
						</div>

					<?php 
                    }
                
                }
            
            }
        
        } else {
            ?>
			<div class="le-widget-error">
				<p><?php 
            _e( 'This widget only works on LifterLMS Course Page', 'elements-for-lifterlms' );
            ?></p>
			</div>
			<?php 
        }
    
    }

}