<?php
/**
 * LifterLMS Lesson Navigation Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Lesson_Mark_Complete extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'le-lifterlms-lesson-mark-complete';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Lesson Mark Complete Button', 'elements-for-lifterlms' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-check-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'elements-for-lifterlms-lesson' ];
	}

	/**
	 * Register widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'elements-for-lifterlms' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'widget_title',
			[
				'label' => __( 'Button Text', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Mark Complete', 'elements-for-lifterlms' ),
				'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
			]
		);

		$this->add_control(
			'btn_align',
			[
				'label' => __( 'Alignment', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
			]
		);
		

		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Style', 'elements-for-lifterlms' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => __( 'Typography', 'elements-for-lifterlms' ),
				'selector' => '{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .llms-start-assignment-button, {{WRAPPER}} .le-lesson-completed-text',
			]
		);

		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'elements-for-lifterlms' ),
			]
		);

			$this->add_control(
				'button_color',
				[
					'label' => __( 'Background Color', 'elements-for-lifterlms' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .llms-start-assignment-button' => 'background: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'button_text_color',
				[
					'label' => __( 'Text Color', 'elements-for-lifterlms' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color_Picker::get_type(),
						'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
					],
					'selectors' => [
						'{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .llms-start-assignment-button' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'border',
					'label' => __( 'Border', 'elements-for-lifterlms' ),
					'selector' => '{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .llms-start-assignment-button',
				]
			);

			$this->add_control(
				'border_radius',
				[
					'label' => __( 'Border Radius', 'elements-for-lifterlms' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],
					'selectors' => [
						'{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .llms-start-assignment-button' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'box_shadow',
					'label' => __( 'Box Shadow', 'elements-for-lifterlms' ),
					'selector' => '{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .llms-start-assignment-button',
				]
			);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __( 'Hover', 'elements-for-lifterlms' ),
			]
		);

			$this->add_control(
				'button_hover_color',
				[
					'label' => __( 'Background Color', 'elements-for-lifterlms' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} .le-mark-complete-button:hover, {{WRAPPER}} .llms-start-assignment-button:hover' => 'background: {{VALUE}}',
					],
				]
			);

			$this->add_control(
							'button_text_hover_color',
							[
								'label' => __( 'Text Color', 'elements-for-lifterlms' ),
								'type' => \Elementor\Controls_Manager::COLOR,
								'scheme' => [
									'type' => \Elementor\Scheme_Color::get_type(),
									'value' => \Elementor\Scheme_Color::COLOR_2,
								],
								'selectors' => [
									'{{WRAPPER}} .le-mark-complete-button:hover, {{WRAPPER}} .llms-start-assignment-button:hover' => 'color: {{VALUE}}',
								],
							]
						);

			$this->add_group_control(
							\Elementor\Group_Control_Border::get_type(),
							[
								'name' => 'hover_border',
								'label' => __( 'Border', 'elements-for-lifterlms' ),
								'selector' => '{{WRAPPER}} .le-mark-complete-button:hover, {{WRAPPER}} .llms-start-assignment-button:hover',
							]
						);

			$this->add_control(
				'hover_border_radius',
				[
					'label' => __( 'Border Radius', 'elements-for-lifterlms' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],
					'selectors' => [
						'{{WRAPPER}} .le-mark-complete-button:hover, {{WRAPPER}} .llms-start-assignment-button:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'hover_box_shadow',
					'label' => __( 'Box Shadow', 'elements-for-lifterlms' ),
					'selector' => '{{WRAPPER}} .le-mark-complete-button:hover, {{WRAPPER}} .llms-start-assignment-button:hover',
				]
			);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'width',
			[
				'label' => __( 'Width', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => null,
				],
				'selectors' => [
					'{{WRAPPER}} .le-mark-complete-button-wrapper .llms-form-field, {{WRAPPER}} .le-lesson-completed-wrap' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .le-mark-complete-button, {{WRAPPER}} .llms-start-assignment-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'lesson_completed_text_color',
			[
				'label' => __( 'Lesson Complete Text Color', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .le-lesson-completed-wrap, {{WRAPPER}} .le-lesson-completed-wrap:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {	
		global $post;

		$lesson = llms_get_post( $post );
		if ( ! $lesson ) {
			return;
		}

		if ( ! llms_is_user_enrolled( get_current_user_id(), $lesson->get( 'parent_course' ) ) && ! current_user_can( 'edit_post', $lesson->get( 'id' ) ) ) {
			return;
		}

		$student = llms_get_student( get_current_user_id() );
		$quiz_id = $lesson->get( 'quiz' );
		if ( 'publish' !== get_post_status( $quiz_id ) && ! current_user_can( 'edit_post', $quiz_id ) ) {
			$quiz_id = false;
		}

		$show_button = $quiz_id ? false : true;

		$settings = $this->get_settings_for_display();
		$btn_txt = $settings['widget_title'];


		if( class_exists( 'LifterLMS' ) && is_lesson() ) { ?>

			<div class="clear"></div>
			<div class="le-mark-complete-button-wrapper le-align-<?php echo $settings['btn_align'] ?>">

				<?php do_action( 'llms_before_lesson_buttons', $lesson, $student ); ?>

				<?php if ( $student->is_complete( $lesson->get( 'id' ), 'lesson' ) ) : ?>

					<?php if ( apply_filters( 'llms_show_mark_complete_button', $show_button, $lesson ) ) : ?>

						<div class="le-lesson-completed-wrap">

							<span class="le-lesson-completed-text">
							<?php echo apply_filters( 'llms_lesson_complete_text', __( 'Lesson Complete', 'lifterlms' ) ); ?></span>

							<?php do_action( 'llms_after_lesson_complete_text', $lesson ); ?>

							<?php if ( 'yes' === get_option( 'lifterlms_retake_lessons', 'no' ) || apply_filters( 'lifterlms_retake_lesson_' . $lesson->get( 'parent_course' ), false ) ) : ?>

								<span class="le-unmark-icon"><i class="fa fa-undo" aria-hidden="true"></i></span>

								<form action="" class="le-incomplete-lesson-form" method="POST" name="mark_incomplete">

									<?php do_action( 'lifterlms_before_mark_incomplete_lesson' ); ?>

									<input type="hidden" name="mark-incomplete" value="<?php echo esc_attr( $lesson->get( 'id' ) ); ?>" />
									<input type="hidden" name="action" value="mark_incomplete" />
									<?php wp_nonce_field( 'mark_incomplete' ); ?>
									<?php $btn_color = 'background-color: ' . $settings['button_color'] . ';' ?>
									<?php llms_form_field( array(
										'columns' => 12,
										'classes' => 'le-unmark-complete-button',
										'id' => 'llms_mark_incomplete',
										'value' => apply_filters( 'lifterlms_mark_lesson_incomplete_button_text', __( 'Mark Incomplete', 'lifterlms' ), $lesson ),
										'last_column' => true,
										'name' => 'mark_incomplete',
										'required' => false,
										'type'  => 'submit',
										'style' => $btn_color,
									) ); ?>

									<?php do_action( 'lifterlms_after_mark_incomplete_lesson' ); ?>

									<span class="le-unmark-close-icon">×</span>

								</form>

							<?php endif; ?>

						</div>

					<?php endif; ?>

				<?php else : ?>

					<?php if ( apply_filters( 'llms_show_mark_complete_button', $show_button, $lesson ) ) : ?>

						<form action="" class="le-complete-lesson-form" method="POST" name="mark_complete">

							<?php do_action( 'lifterlms_before_mark_complete_lesson' ); ?>

							<input type="hidden" name="mark-complete" value="<?php echo esc_attr( $lesson->get( 'id' ) ); ?>" />
							<input type="hidden" name="action" value="mark_complete" />
							<?php wp_nonce_field( 'mark_complete' ); ?>

							<?php llms_form_field( array(
								'columns' => '',
								'classes' => 'le-mark-complete-button button',
								'id' => 'le_mark_complete',
								'value' => $btn_txt,
								'last_column' => true,
								'name' => 'mark_complete',
								'required' => false,
								'type'  => 'submit',
							) ); ?>

							<?php do_action( 'lifterlms_after_mark_complete_lesson' ); ?>

						</form>

					<?php endif; ?>

				<?php endif; ?>

				<?php if ( $quiz_id ) : ?>

					<?php do_action( 'llms_before_start_quiz_button' ); ?>

					<a class="llms-button-action auto button" id="llms_start_quiz" href="<?php echo get_permalink( $quiz_id ); ?>">
						<?php echo apply_filters( 'lifterlms_start_quiz_button_text', __( 'Take Quiz', 'lifterlms' ), $quiz_id, $lesson ); ?>
					</a>

					<?php do_action( 'llms_after_start_quiz_button' ); ?>

				<?php endif; ?>

				<?php do_action( 'llms_after_lesson_buttons', $lesson, $student ); ?>

			</div> <?php
		}else{
			?>
			<div class="le-widget-error">
				<p><?php _e( 'This widget only works on LifterLMS Lesson Page', 'elements-for-lifterlms' ); ?></p>
			</div>
			<?php
		}

	}

	

}
