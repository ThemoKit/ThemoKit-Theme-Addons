<?php
/**
 * LifterLMS Lesson Video Widget.
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Course_Info extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'le-lifterlms-course-info';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Course Info', 'elements-for-lifterlms' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-excerpt';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'elements-for-lifterlms-course' ];
	}

	/**
	 * Register widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'elements-for-lifterlms' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'visibility',
			[
				'label' => __( 'Enrollment Visibility', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'everyone',
				'options' => [
					'everyone'  => __( 'Everyone', 'elements-for-lifterlms' ),
					'enrolled' => __( 'Enrolled Students', 'elements-for-lifterlms' ),
					'unenrolled' => __( 'Unenrolled Students and Visitors', 'elements-for-lifterlms' ),
				],
			]
		);

		//Course Difficulty
		$this->add_control(
			'difficulty_title',
			[
				'label' => __( 'Course Difficulty', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_course_difficulty',
			[
				'label' => __( 'Show Course Difficulty', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'elements-for-lifterlms' ),
				'label_off' => __( 'Hide', 'elements-for-lifterlms' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'difficulty_text',
			[
				'label' => __( 'Custom Text', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Difficulty', 'elements-for-lifterlms' ),
				'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
			]
		);

		//Course Length
		$this->add_control(
			'length_title',
			[
				'label' => __( 'Course Length', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_course_length',
			[
				'label' => __( 'Show Course Length', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'elements-for-lifterlms' ),
				'label_off' => __( 'Hide', 'elements-for-lifterlms' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'length_text',
			[
				'label' => __( 'Custom Text', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Estimated Time', 'elements-for-lifterlms' ),
				'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
			]
		);

		//Course Tracks
		$this->add_control(
			'tracks_title',
			[
				'label' => __( 'Course Tracks', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_course_tracks',
			[
				'label' => __( 'Show Course Tracks', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'elements-for-lifterlms' ),
				'label_off' => __( 'Hide', 'elements-for-lifterlms' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'tracks_text',
			[
				'label' => __( 'Custom Text', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Tracks', 'elements-for-lifterlms' ),
				'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
			]
		);

		//Course Categories
		$this->add_control(
			'categories_title',
			[
				'label' => __( 'Course Categories', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_course_categories',
			[
				'label' => __( 'Show Course Categories', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'elements-for-lifterlms' ),
				'label_off' => __( 'Hide', 'elements-for-lifterlms' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'categories_text',
			[
				'label' => __( 'Custom Text', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Categories', 'elements-for-lifterlms' ),
				'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
			]
		);

		//Course Tags
		$this->add_control(
			'tags_title',
			[
				'label' => __( 'Course Tags', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_course_tags',
			[
				'label' => __( 'Show Course Tags', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'elements-for-lifterlms' ),
				'label_off' => __( 'Hide', 'elements-for-lifterlms' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'tags_text',
			[
				'label' => __( 'Custom Text', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Tags', 'elements-for-lifterlms' ),
				'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
			]
		);

		$this->end_controls_section();





		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Style', 'elements-for-lifterlms' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'text_align',
			[
				'label' => __( 'Alignment', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elements-for-lifterlms' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
			]
		);

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .le-course-info .le-meta p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'style_text_title',
			[
				'label' => __( 'Info Text Style', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Text Color', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .le-course-info' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'info_typography',
				'label' => __( 'Typography', 'elements-for-lifterlms' ),
				'selector' => '{{WRAPPER}} .le-course-info',
			]
		);

		$this->add_control(
			'style_title_title',
			[
				'label' => __( 'Info Title Style', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Info Title Color', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .le-course-info .le-info-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'info_title_typography',
				'label' => __( 'Info Title Typography', 'elements-for-lifterlms' ),
				'selector' => '{{WRAPPER}} .le-course-info .le-info-title',
			]
		);

		$this->add_control(
			'style_link_title',
			[
				'label' => __( 'Info Link Style', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'link_color',
			[
				'label' => __( 'Link Color', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .le-course-info a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'hover_link_color',
			[
				'label' => __( 'Hover Link Color', 'elements-for-lifterlms' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_4,
				],
				'selectors' => [
					'{{WRAPPER}} .le-course-info a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',
				'label' => __( 'Link Typography', 'elements-for-lifterlms' ),
				'selector' => '{{WRAPPER}} .le-course-info a',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

			if( class_exists( 'LifterLMS' ) && is_course() ) { 

				global $post;

				$settings = $this->get_settings_for_display();
				$difficulty_text = $settings['difficulty_text'];
				$length_text = $settings['length_text'];
				$tracks_text = $settings['tracks_text'];
				$categories_text = $settings['categories_text'];
				$tags_text = $settings['tags_text'];

				$course = new LLMS_Course( $post );

				$student = llms_get_student();

				if ( 'everyone' === $settings['visibility'] ){

					?><div class="le-course-info le-align-<?php echo $settings['text_align'] ?>"><?php

						if ( $course->get_difficulty() ) {
							if ( 'yes' === $settings['show_course_difficulty'] ){
								?>
								<div class="le-meta le-difficulty">
									<p><span class="le-info-title"><?php echo $difficulty_text; ?>: </span><span class="difficulty"><?php echo $course->get_difficulty(); ?></span></p>
								</div>
								<?php
							}
						}

						if ( $course->get( 'length' ) && 'yes' === $settings['show_course_length'] ) {
							?>
							<div class="le-meta le-course-length">
								<p><span class="le-info-title"><?php echo $length_text; ?>: </span><span class="length"><?php echo $course->get( 'length' ); ?></span></p>
							</div>
							<?php
						}

						if ( 'yes' === $settings['show_course_tracks'] ) {
							?>
							<div class="le-meta le-tracks">
								<p><span class="le-info-title"><?php echo $tracks_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_track', '', ', ', '' ); ?> </p>
							</div>
							<?php
						}

						if ( 'yes' === $settings['show_course_categories'] ) {
							?>
							<div class="le-meta le-categories">
								<p><span class="le-info-title"><?php echo $categories_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_cat', '', ', ', '' ); ?></p>
							</div>
							<?php
						}

						if ( 'yes' === $settings['show_course_tags'] ) {
							?>
							<div class="le-meta le-tags">
								<p><span class="le-info-title"><?php echo $tags_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_tag', '', ', ', '' ); ?></p>
							</div>
							<?php
						}
					?></div><?php

				}elseif ( 'enrolled' === $settings['visibility'] ){

					if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {

						?><div class="le-course-info le-align-<?php echo $settings['text_align'] ?>"><?php

							if ( $course->get_difficulty() ) {
								if ( 'yes' === $settings['show_course_difficulty'] ){
									?>
									<div class="le-meta le-difficulty">
										<p><span class="le-info-title"><?php echo $difficulty_text; ?>: </span><span class="difficulty"><?php echo $course->get_difficulty(); ?></span></p>
									</div>
									<?php
								}
							}

							if ( $course->get( 'length' ) && 'yes' === $settings['show_course_length'] ) {
								?>
								<div class="le-meta le-course-length">
									<p><span class="le-info-title"><?php echo $length_text; ?>: </span><span class="length"><?php echo $course->get( 'length' ); ?></span></p>
								</div>
								<?php
							}

							if ( 'yes' === $settings['show_course_tracks'] ) {
								?>
								<div class="le-meta le-tracks">
									<p><span class="le-info-title"><?php echo $tracks_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_track', '', ', ', '' ); ?> </p>
								</div>
								<?php
							}

							if ( 'yes' === $settings['show_course_categories'] ) {
								?>
								<div class="le-meta le-categories">
									<p><span class="le-info-title"><?php echo $categories_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_cat', '', ', ', '' ); ?></p>
								</div>
								<?php
							}

							if ( 'yes' === $settings['show_course_tags'] ) {
								?>
								<div class="le-meta le-tags">
									<p><span class="le-info-title"><?php echo $tags_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_tag', '', ', ', '' ); ?></p>
								</div>
								<?php
							}
						?></div><?php

					}
				}elseif ( 'unenrolled' === $settings['visibility'] ){

					if ( !llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {

						?><div class="le-course-info le-align-<?php echo $settings['text_align'] ?>"><?php

							if ( $course->get_difficulty() ) {
								if ( 'yes' === $settings['show_course_difficulty'] ){
									?>
									<div class="le-meta le-difficulty">
										<p><span class="le-info-title"><?php echo $difficulty_text; ?>: </span><span class="difficulty"><?php echo $course->get_difficulty(); ?></span></p>
									</div>
									<?php
								}
							}

							if ( $course->get( 'length' ) && 'yes' === $settings['show_course_length'] ) {
								?>
								<div class="le-meta le-course-length">
									<p><span class="le-info-title"><?php echo $length_text; ?>: </span><span class="length"><?php echo $course->get( 'length' ); ?></span></p>
								</div>
								<?php
							}

							if ( 'yes' === $settings['show_course_tracks'] ) {
								?>
								<div class="le-meta le-tracks">
									<p><span class="le-info-title"><?php echo $tracks_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_track', '', ', ', '' ); ?> </p>
								</div>
								<?php
							}

							if ( 'yes' === $settings['show_course_categories'] ) {
								?>
								<div class="le-meta le-categories">
									<p><span class="le-info-title"><?php echo $categories_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_cat', '', ', ', '' ); ?></p>
								</div>
								<?php
							}

							if ( 'yes' === $settings['show_course_tags'] ) {
								?>
								<div class="le-meta le-tags">
									<p><span class="le-info-title"><?php echo $tags_text; ?>: </span><?php echo get_the_term_list( $post->ID, 'course_tag', '', ', ', '' ); ?></p>
								</div>
								<?php
							}
						?></div><?php

					}
					
				}

			}else{
				?>
				<div class="le-widget-error">
					<p><?php _e( 'This widget only works on LifterLMS Lesson Page', 'elements-for-lifterlms' ); ?></p>
				</div>
				<?php
			}
		

	}

	

}
