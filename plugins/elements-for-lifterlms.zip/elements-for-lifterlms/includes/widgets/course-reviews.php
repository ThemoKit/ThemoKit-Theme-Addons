<?php

/**
 * LifterLMS Title Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Course_Reviews extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-course-reviews';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Course Reviews', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-blockquote';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms-course' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'content_section', [
            'label' => __( 'Content', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'visibility', [
            'label'   => __( 'Enrollment Visibility', 'elements-for-lifterlms' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'everyone',
            'options' => [
            'everyone'   => __( 'Everyone', 'elements-for-lifterlms' ),
            'enrolled'   => __( 'Enrolled Students', 'elements-for-lifterlms' ),
            'unenrolled' => __( 'Unenrolled Students and Visitors', 'elements-for-lifterlms' ),
        ],
        ] );
        $this->add_control( 'title_text', [
            'label'       => __( 'Custom Text for Title', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'What Others Have Said', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'review_carousel', [
            'label' => __( 'Carousel Slider', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'enable_carousel', [
            'label'        => __( 'Enable Carousel Slider', 'elements-for-lifterlms' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => __( 'On', 'elements-for-lifterlms' ),
            'label_off'    => __( 'Off', 'elements-for-lifterlms' ),
            'return_value' => 'yes',
            'default'      => 'no',
        ] );
        $this->add_control( 'hr_1', [
            'type'      => \Elementor\Controls_Manager::DIVIDER,
            'style'     => 'thick',
            'condition' => [
            'enable_carousel' => 'yes',
        ],
        ] );
        $this->add_control( 'control_get_pro_1', [
            'label'       => __( 'Only Available in Premium Version', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> to unlock the customization options.</span>',
            'condition'   => [
            'enable_carousel' => 'yes',
        ],
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'title_section', [
            'label' => __( 'Title', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'show_title', [
            'label'        => __( 'Show Title', 'elements-for-lifterlms' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => __( 'Show', 'elements-for-lifterlms' ),
            'label_off'    => __( 'Hide', 'elements-for-lifterlms' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-reviews-title',
        ] );
        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-reviews-title' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'title_text_align', [
            'label'   => __( 'Alignment', 'elements-for-lifterlms' ),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
            'left'   => [
            'title' => __( 'Left', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-left',
        ],
            'center' => [
            'title' => __( 'Center', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-center',
        ],
            'right'  => [
            'title' => __( 'Right', 'elements-for-lifterlms' ),
            'icon'  => 'fa fa-align-right',
        ],
        ],
            'default' => 'left',
            'toggle'  => true,
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'reviews_section', [
            'label' => __( 'Reviews', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'review_bg_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le_review' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_responsive_control( 'review_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le_review' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
            'devices'    => [ 'desktop', 'tablet', 'mobile' ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'review_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le_review',
        ] );
        $this->add_control( 'review_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le_review' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'review_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le_review',
        ] );
        $this->add_control( 'review_title_title', [
            'label'     => __( 'Review Title', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'review_title_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le_review_title',
        ] );
        $this->add_control( 'review_title_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_2,
        ],
            'selectors' => [
            '{{WRAPPER}} .le_review_title' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'review_content_title', [
            'label'     => __( 'Review Content', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'review_content_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le_review_content',
        ] );
        $this->add_control( 'review_content_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le_review_content' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'review_name_title', [
            'label'     => __( 'Name', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'review_name_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le_reviewer_name',
        ] );
        $this->add_control( 'review_name_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_2,
        ],
            'selectors' => [
            '{{WRAPPER}} .le_reviewer_name' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'review_icon_title', [
            'label'     => __( 'Icon', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_control( 'enable_icon', [
            'label'        => __( 'Show Icon', 'elements-for-lifterlms' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => __( 'Show', 'elements-for-lifterlms' ),
            'label_off'    => __( 'Hide', 'elements-for-lifterlms' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );
        $this->add_control( 'review_icon_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .avatar-quote' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'review_icon_bg_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .avatar-quote' => 'background: {{VALUE}}',
        ],
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'review_form_section', [
            'label' => __( 'Review Form', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'review_form_title_title', [
            'label'     => __( 'Form Title', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'review_form_title_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-review-form-title',
        ] );
        $this->add_control( 'review_form_title_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-review-form-title' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'control_get_pro_2', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'review_form_field_section', [
            'label' => __( 'Review Form Field', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'review_form_field_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-write-review-wrap #review_title, {{WRAPPER}} .le-write-review-wrap #review_text' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'review_form_field_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-write-review-wrap #review_title, {{WRAPPER}} .le-write-review-wrap #review_text',
        ] );
        $this->add_control( 'control_get_pro_3', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more customization options.</span>',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'review_form_btn_section', [
            'label' => __( 'Review Form Button', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'review_form_btn_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button',
        ] );
        $this->start_controls_tabs( 'review_form_btn_tabs' );
        $this->start_controls_tab( 'review_form_btn_normal_tab', [
            'label' => __( 'Normal', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'review_form_btn_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'review_form_button_text_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'review_form_btn_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button',
        ] );
        $this->add_control( 'review_form_btn_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'review_form_btn_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button',
        ] );
        $this->end_controls_tab();
        $this->start_controls_tab( 'review_form_btn_hover_tab', [
            'label' => __( 'Hover', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'review_form_btn_button_hover_color', [
            'label'     => __( 'Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_4,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button:hover' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'review_form_btn_button_text_hover_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color_Picker::get_type(),
            'value' => \Elementor\Scheme_Color_Picker::COLOR_8,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button:hover' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Border::get_type(), [
            'name'     => 'review_form_btn_hover_border',
            'label'    => __( 'Border', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button:hover',
        ] );
        $this->add_control( 'review_form_btn_hover_border_radius', [
            'label'      => __( 'Border Radius', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 100,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => 0,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'review_form_btn_hover_box_shadow',
            'label'    => __( 'Box Shadow', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button:hover',
        ] );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control( 'review_form_btn_width', [
            'label'      => __( 'Width', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
            'px' => [
            'min'  => 0,
            'max'  => 1000,
            'step' => 1,
        ],
            '%'  => [
            'min' => 0,
            'max' => 100,
        ],
        ],
            'default'    => [
            'unit' => 'px',
            'size' => null,
        ],
            'selectors'  => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button' => 'width: {{SIZE}}{{UNIT}};',
        ],
        ] );
        $this->add_control( 'review_form_btn_padding', [
            'label'      => __( 'Padding', 'elements-for-lifterlms' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
            '{{WRAPPER}} .le-write-review-wrap #llms_review_submit_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'review_form_msg_section', [
            'label' => __( 'Review Form Messages', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'review_form_msg_color', [
            'label'     => __( 'Text Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} #le_thank_you_box h2' => 'color: {{VALUE}}',
        ],
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'review_form_msg_typography',
            'label'    => __( 'Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} #le_thank_you_box h2',
        ] );
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        global  $post ;
        $settings = $this->get_settings_for_display();
        $course = new LLMS_Course( $post );
        $student = llms_get_student();
        $title_text = $settings['title_text'];
        $carousel_column_per_view = $settings['carousel_column_per_view'];
        $carousel_column_per_scroll = $settings['carousel_column_per_scroll'];
        $carousel_column_per_view_tab = $settings['carousel_column_per_view_tab'];
        $carousel_column_per_scroll_tab = $settings['carousel_column_per_scroll_tab'];
        $carousel_column_per_view_mob = $settings['carousel_column_per_view_mob'];
        $carousel_column_per_scroll_mob = $settings['carousel_column_per_scroll_mob'];
        $carousel_transition_duration = $settings['carousel_transition_duration'];
        $carousel_autoplay_speed = $settings['carousel_autoplay_speed'];
        
        if ( 'yes' === $settings['enable_carousel_arrows'] ) {
            $enable_carousel_arrows = 'true';
        } else {
            $enable_carousel_arrows = 'false';
        }
        
        
        if ( 'yes' === $settings['enable_carousel_dots'] ) {
            $enable_carousel_dots = 'true';
        } else {
            $enable_carousel_dots = 'false';
        }
        
        
        if ( 'yes' === $settings['enable_carousel_autoplay'] ) {
            $enable_carousel_autoplay = 'true';
        } else {
            $enable_carousel_autoplay = 'false';
        }
        
        
        if ( 'yes' === $settings['enable_carousel_infinite_loop'] ) {
            $enable_carousel_infinite_loop = 'true';
        } else {
            $enable_carousel_infinite_loop = 'false';
        }
        
        
        if ( 'yes' === $settings['enable_carousel_pause'] ) {
            $enable_carousel_pause = 'true';
        } else {
            $enable_carousel_pause = 'false';
        }
        
        $is_pro_active = 'no';
        
        if ( class_exists( 'LifterLMS' ) && is_course() ) {
            
            if ( 'everyone' === $settings['visibility'] ) {
                ?>
				<div class="le-review-wrap <?php 
                
                if ( 'yes' === $settings['enable_carousel'] && $is_pro_active === 'yes' ) {
                    ?>slider<?php 
                } else {
                    ?>no-slider<?php 
                }
                
                ?> <?php 
                
                if ( 'yes' === $settings['enable_icon'] ) {
                    ?>icon<?php 
                } else {
                    ?>no-icon<?php 
                }
                
                ?> col-<?php 
                echo  $carousel_column_per_view ;
                ?> tab-col-<?php 
                echo  $carousel_column_per_view_tab ;
                ?> mob-col-<?php 
                echo  $carousel_column_per_view_mob ;
                ?> <?php 
                if ( 'yes' === $settings['review_form_centered'] ) {
                    ?>form-align-center<?php 
                }
                ?>"> 

					<?php 
                
                if ( 'yes' === $settings['show_title'] ) {
                    ?>
						<h2 class="le-reviews-title le-align-<?php 
                    echo  $settings['title_text_align'] ;
                    ?>"><?php 
                    echo  $title_text ;
                    ?></h2>
					<?php 
                }
                
                ?>

					<?php 
                LLMSE_Course_Review::output();
                ?>

					<script type="text/javascript">
						jQuery(document).ready(function($){
							$(".le-review-wrap.slider .review-boxes-wrap").slick({
								speed: <?php 
                echo  $carousel_transition_duration ;
                ?>,
								dots: <?php 
                echo  $enable_carousel_dots ;
                ?>,
								arrows: <?php 
                echo  $enable_carousel_arrows ;
                ?>,
								infinite: <?php 
                echo  $enable_carousel_infinite_loop ;
                ?>,
								slidesToShow: <?php 
                echo  $carousel_column_per_view ;
                ?>,
								slidesToScroll: <?php 
                echo  $carousel_column_per_scroll ;
                ?>,
								adaptiveHeight : true,
								autoplay : <?php 
                echo  $enable_carousel_autoplay ;
                ?>,
								autoplaySpeed : <?php 
                echo  $carousel_autoplay_speed ;
                ?>,
								pauseOnFocus: <?php 
                echo  $enable_carousel_pause ;
                ?>,
								pauseOnHover: <?php 
                echo  $enable_carousel_pause ;
                ?>,
								pauseOnDotsHover: <?php 
                echo  $enable_carousel_pause ;
                ?>,
								responsive: [
								{
									breakpoint: 1024,
									settings: {
										slidesToShow: <?php 
                echo  $carousel_column_per_view_tab ;
                ?>,
										slidesToScroll: <?php 
                echo  $carousel_column_per_scroll_tab ;
                ?>,
									}
								},
								{
									breakpoint: 767,
									settings: {
										slidesToShow: <?php 
                echo  $carousel_column_per_view_mob ;
                ?>,
										slidesToScroll: <?php 
                echo  $carousel_column_per_scroll_mob ;
                ?>,
									}
								}
									// You can unslick at a given breakpoint now by adding:
									// settings: "unslick"
									// instead of a settings object
								]
							});
						});


						jQuery(document).ready(function($){

							$('.review-boxes-wrap .slick-track').each(function(){  

								var highestBox = 0;

								$(this).find('.le_review').each(function(){
									if($(this).height() > highestBox){  
										highestBox = $(this).height();  
									}
								})

								$(this).find('.le_review').height(highestBox);

							}); 

						});
					</script>

					<?php 
                $theme = wp_get_theme();
                if ( 'Astra' == $theme->name || 'astra' == $theme->template ) {
                    
                    if ( get_option( 'hide-course-elements-radio' ) == 2 ) {
                        ?>
							<style type="text/css">
								#old_reviews, #review_box, #thank_you_box{
									display: none;
								}
							</style>
							<?php 
                    } else {
                        if ( get_option( 'hide-course-reviews-checkbox' ) == 1 ) {
                            ?>
								<style type="text/css">
									#old_reviews, #review_box, #thank_you_box{
										display: none;
									}
								</style>
								<?php 
                        }
                    }
                
                }
                ?>
					

				</div>

				<?php 
            } elseif ( 'enrolled' === $settings['visibility'] ) {
                
                if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                    ?>
					<div class="le-review-wrap <?php 
                    
                    if ( 'yes' === $settings['enable_carousel'] ) {
                        ?>slider<?php 
                    } else {
                        ?>no-slider<?php 
                    }
                    
                    ?> <?php 
                    
                    if ( 'yes' === $settings['enable_icon'] ) {
                        ?>icon<?php 
                    } else {
                        ?>no-icon<?php 
                    }
                    
                    ?> col-<?php 
                    echo  $carousel_column_per_view ;
                    ?> tab-col-<?php 
                    echo  $carousel_column_per_view_tab ;
                    ?> mob-col-<?php 
                    echo  $carousel_column_per_view_mob ;
                    ?> <?php 
                    if ( 'yes' === $settings['review_form_centered'] ) {
                        ?>form-align-center<?php 
                    }
                    ?>"> 

						<?php 
                    
                    if ( 'yes' === $settings['show_title'] ) {
                        ?>
							<h2 class="le-reviews-title le-align-<?php 
                        echo  $settings['title_text_align'] ;
                        ?>"><?php 
                        echo  $title_text ;
                        ?></h2>
						<?php 
                    }
                    
                    ?>

						<?php 
                    LLMSE_Course_Review::output();
                    ?>

						<script type="text/javascript">
							jQuery(document).ready(function($){
								$(".le-review-wrap.slider .review-boxes-wrap").slick({
									speed: <?php 
                    echo  $carousel_transition_duration ;
                    ?>,
									dots: <?php 
                    echo  $enable_carousel_dots ;
                    ?>,
									arrows: <?php 
                    echo  $enable_carousel_arrows ;
                    ?>,
									infinite: <?php 
                    echo  $enable_carousel_infinite_loop ;
                    ?>,
									slidesToShow: <?php 
                    echo  $carousel_column_per_view ;
                    ?>,
									slidesToScroll: <?php 
                    echo  $carousel_column_per_scroll ;
                    ?>,
									adaptiveHeight : true,
									autoplay : <?php 
                    echo  $enable_carousel_autoplay ;
                    ?>,
									autoplaySpeed : <?php 
                    echo  $carousel_autoplay_speed ;
                    ?>,
									pauseOnFocus: <?php 
                    echo  $enable_carousel_pause ;
                    ?>,
									pauseOnHover: <?php 
                    echo  $enable_carousel_pause ;
                    ?>,
									pauseOnDotsHover: <?php 
                    echo  $enable_carousel_pause ;
                    ?>,
									responsive: [
									{
										breakpoint: 1024,
										settings: {
											slidesToShow: <?php 
                    echo  $carousel_column_per_view_tab ;
                    ?>,
											slidesToScroll: <?php 
                    echo  $carousel_column_per_scroll_tab ;
                    ?>,
										}
									},
									{
										breakpoint: 767,
										settings: {
											slidesToShow: <?php 
                    echo  $carousel_column_per_view_mob ;
                    ?>,
											slidesToScroll: <?php 
                    echo  $carousel_column_per_scroll_mob ;
                    ?>,
										}
									}
										// You can unslick at a given breakpoint now by adding:
										// settings: "unslick"
										// instead of a settings object
									]
								});
							});


							jQuery(document).ready(function($){

								$('.review-boxes-wrap .slick-track').each(function(){  

									var highestBox = 0;

									$(this).find('.le_review').each(function(){
										if($(this).height() > highestBox){  
											highestBox = $(this).height();  
										}
									})

									$(this).find('.le_review').height(highestBox);

								}); 

							});
						</script>

						<?php 
                    $theme = wp_get_theme();
                    if ( 'Astra' == $theme->name || 'astra' == $theme->template ) {
                        
                        if ( get_option( 'hide-course-elements-radio' ) == 2 ) {
                            ?>
								<style type="text/css">
									#old_reviews, #review_box, #thank_you_box{
										display: none;
									}
								</style>
								<?php 
                        } else {
                            if ( get_option( 'hide-course-reviews-checkbox' ) == 1 ) {
                                ?>
									<style type="text/css">
										#old_reviews, #review_box, #thank_you_box{
											display: none;
										}
									</style>
									<?php 
                            }
                        }
                    
                    }
                    ?>
						

					</div>

					<?php 
                }
            
            } elseif ( 'unenrolled' === $settings['visibility'] ) {
                
                if ( !llms_is_user_enrolled( get_current_user_id(), $post->ID ) || \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                    ?>
					<div class="le-review-wrap <?php 
                    
                    if ( 'yes' === $settings['enable_carousel'] ) {
                        ?>slider<?php 
                    } else {
                        ?>no-slider<?php 
                    }
                    
                    ?> <?php 
                    
                    if ( 'yes' === $settings['enable_icon'] ) {
                        ?>icon<?php 
                    } else {
                        ?>no-icon<?php 
                    }
                    
                    ?> col-<?php 
                    echo  $carousel_column_per_view ;
                    ?> tab-col-<?php 
                    echo  $carousel_column_per_view_tab ;
                    ?> mob-col-<?php 
                    echo  $carousel_column_per_view_mob ;
                    ?> <?php 
                    if ( 'yes' === $settings['review_form_centered'] ) {
                        ?>form-align-center<?php 
                    }
                    ?>"> 

						<?php 
                    
                    if ( 'yes' === $settings['show_title'] ) {
                        ?>
							<h2 class="le-reviews-title le-align-<?php 
                        echo  $settings['title_text_align'] ;
                        ?>"><?php 
                        echo  $title_text ;
                        ?></h2>
						<?php 
                    }
                    
                    ?>

						<?php 
                    LLMSE_Course_Review::output();
                    ?>

						<script type="text/javascript">
							jQuery(document).ready(function($){
								$(".le-review-wrap.slider .review-boxes-wrap").slick({
									speed: <?php 
                    echo  $carousel_transition_duration ;
                    ?>,
									dots: <?php 
                    echo  $enable_carousel_dots ;
                    ?>,
									arrows: <?php 
                    echo  $enable_carousel_arrows ;
                    ?>,
									infinite: <?php 
                    echo  $enable_carousel_infinite_loop ;
                    ?>,
									slidesToShow: <?php 
                    echo  $carousel_column_per_view ;
                    ?>,
									slidesToScroll: <?php 
                    echo  $carousel_column_per_scroll ;
                    ?>,
									adaptiveHeight : true,
									autoplay : <?php 
                    echo  $enable_carousel_autoplay ;
                    ?>,
									autoplaySpeed : <?php 
                    echo  $carousel_autoplay_speed ;
                    ?>,
									pauseOnFocus: <?php 
                    echo  $enable_carousel_pause ;
                    ?>,
									pauseOnHover: <?php 
                    echo  $enable_carousel_pause ;
                    ?>,
									pauseOnDotsHover: <?php 
                    echo  $enable_carousel_pause ;
                    ?>,
									responsive: [
									{
										breakpoint: 1024,
										settings: {
											slidesToShow: <?php 
                    echo  $carousel_column_per_view_tab ;
                    ?>,
											slidesToScroll: <?php 
                    echo  $carousel_column_per_scroll_tab ;
                    ?>,
										}
									},
									{
										breakpoint: 767,
										settings: {
											slidesToShow: <?php 
                    echo  $carousel_column_per_view_mob ;
                    ?>,
											slidesToScroll: <?php 
                    echo  $carousel_column_per_scroll_mob ;
                    ?>,
										}
									}
										// You can unslick at a given breakpoint now by adding:
										// settings: "unslick"
										// instead of a settings object
									]
								});
							});


							jQuery(document).ready(function($){

								$('.review-boxes-wrap .slick-track').each(function(){  

									var highestBox = 0;

									$(this).find('.le_review').each(function(){
										if($(this).height() > highestBox){  
											highestBox = $(this).height();  
										}
									})

									$(this).find('.le_review').height(highestBox);

								}); 

							});
						</script>

						<?php 
                    $theme = wp_get_theme();
                    if ( 'Astra' == $theme->name || 'astra' == $theme->template ) {
                        
                        if ( get_option( 'hide-course-elements-radio' ) == 2 ) {
                            ?>
								<style type="text/css">
									#old_reviews, #review_box, #thank_you_box h2{
										display: none;
									}
									.elementor-element #old_reviews, .elementor-element #review_box, .elementor-element #thank_you_box h2{
										display: block;
									}
								</style>
								<?php 
                        } else {
                            if ( get_option( 'hide-course-reviews-checkbox' ) == 1 ) {
                                ?>
									<style type="text/css">
										#old_reviews, #review_box, #thank_you_box h2{
										display: none;
										}
										.elementor-element #old_reviews, .elementor-element #review_box, .elementor-element #thank_you_box h2{
											display: block;
										}
									</style>
									<?php 
                            }
                        }
                    
                    }
                    ?>
						

					</div>

					<?php 
                }
            
            }
        
        } else {
            ?>
			<div class="le-widget-error">
				<p><?php 
            _e( 'This widget only works on LifterLMS Course Page', 'elements-for-lifterlms' );
            ?></p>
			</div>
			<?php 
        }
    
    }

}