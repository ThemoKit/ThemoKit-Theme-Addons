<?php

/**
 * LifterLMS Title Widget.
 *
 *
 * @since 1.0.0
 */
class LLMSE_Lifterlms_Lesson_Progress_Bar extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'le-lifterlms-lesson-progress-bar';
    }
    
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __( 'Progress Bar', 'elements-for-lifterlms' );
    }
    
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-skill-bar';
    }
    
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'elements-for-lifterlms' ];
    }
    
    /**
     * Register widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section( 'content_section', [
            'label' => __( 'Content', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'widget_text', [
            'label'       => __( 'Title', 'elements-for-lifterlms' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Course Progress', 'elements-for-lifterlms' ),
            'placeholder' => __( 'Type your own text here', 'elements-for-lifterlms' ),
        ] );
        $this->add_control( 'show_title', [
            'label'        => __( 'Show Title', 'elements-for-lifterlms' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => __( 'On', 'elements-for-lifterlms' ),
            'label_off'    => __( 'Off', 'elements-for-lifterlms' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );
        $this->add_control( 'show_percentage', [
            'label'        => __( 'Show Percentage', 'elements-for-lifterlms' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => __( 'On', 'elements-for-lifterlms' ),
            'label_off'    => __( 'Off', 'elements-for-lifterlms' ),
            'return_value' => 'yes',
            'default'      => 'no',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'go_premium_content', [
            'label' => __( 'Go Premium for More Features', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );
        $this->add_control( 'control_get_pro_content', [
            'label'       => __( 'Unlock more Customizations', 'essential-addons-elementor' ),
            'type'        => \Elementor\Controls_Manager::CHOOSE,
            'options'     => [
            '1' => [
            'title' => __( '', 'essential-addons-elementor' ),
            'icon'  => 'fa fa-unlock-alt',
        ],
        ],
            'default'     => '1',
            'description' => '<span class="pro-feature"> Get the  <a href="https://lifterlmselements.com/pricing" target="_blank">Pro version</a> for more stunning widgets and customization options.</span>',
        ] );
        $this->end_controls_section();
        $this->start_controls_section( 'title_style_section', [
            'label' => __( 'Title', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Title Typography', 'elements-for-lifterlms' ),
            'selector' => '{{WRAPPER}} .le-lesson-progress-title',
        ] );
        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-lesson-progress-title' => 'color: {{VALUE}}',
        ],
        ] );
        // $this->add_control(
        // 	'title_align',
        // 	[
        // 		'label' => __( 'Alignment', 'elements-for-lifterlms' ),
        // 		'type' => \Elementor\Controls_Manager::CHOOSE,
        // 		'options' => [
        // 			'left' => [
        // 				'title' => __( 'Left', 'elements-for-lifterlms' ),
        // 				'icon' => 'fa fa-align-left',
        // 			],
        // 			'center' => [
        // 				'title' => __( 'Center', 'elements-for-lifterlms' ),
        // 				'icon' => 'fa fa-align-center',
        // 			],
        // 			'right' => [
        // 				'title' => __( 'Right', 'elements-for-lifterlms' ),
        // 				'icon' => 'fa fa-align-right',
        // 			],
        // 		],
        // 		'default' => 'left',
        // 		'toggle' => true,
        // 	]
        // );
        $this->end_controls_section();
        $this->start_controls_section( 'progress_style_section', [
            'label' => __( 'Progress Bar', 'elements-for-lifterlms' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );
        $this->add_control( 'progress_color', [
            'label'     => __( 'Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_1,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-progress-bar-complete' => 'background: {{VALUE}}',
        ],
        ] );
        $this->add_control( 'allow_custom_progress_bg', [
            'label'        => __( 'Customize Background Color', 'elements-for-lifterlms' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => __( 'On', 'elements-for-lifterlms' ),
            'label_off'    => __( 'Off', 'elements-for-lifterlms' ),
            'return_value' => 'yes',
            'default'      => 'no',
        ] );
        $this->add_control( 'progress_background_color', [
            'label'     => __( 'Progress Background Color', 'elements-for-lifterlms' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'scheme'    => [
            'type'  => \Elementor\Scheme_Color::get_type(),
            'value' => \Elementor\Scheme_Color::COLOR_3,
        ],
            'selectors' => [
            '{{WRAPPER}} .le-progress-bar' => 'background: {{VALUE}}',
        ],
            'condition' => [
            'allow_custom_progress_bg' => 'yes',
        ],
        ] );
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        global  $post ;
        
        if ( class_exists( 'LifterLMS' ) ) {
            
            if ( is_lesson() ) {
                $lesson = new LLMS_Lesson( $post->ID );
                $course_id = $lesson->get_parent_course();
                $course = new LLMS_Course( $course_id );
                $student = new LLMS_Student();
                $progress = $student->get_progress( $course->get( 'id' ), 'course' );
            } elseif ( is_course() ) {
                $course = new LLMS_Course( $post );
                $student = new LLMS_Student();
                $progress = $student->get_progress( $course->get( 'id' ), 'course' );
            }
            
            
            if ( is_lesson() || is_course() ) {
                $settings = $this->get_settings_for_display();
                $title_txt = $settings['widget_text'];
                
                if ( llms_is_user_enrolled( get_current_user_id(), $post->ID ) ) {
                    ?>
					<?php 
                    
                    if ( apply_filters( 'lifterlms_display_course_progress_bar', true ) ) {
                        ?>
						<div class="le-lesson-progress-bar <?php 
                        if ( 'yes' === $settings['animate_progress'] ) {
                            ?>animated<?php 
                        }
                        ?>">
							<?php 
                        
                        if ( 'yes' === $settings['show_title'] ) {
                            ?>
								<h3 class="le-lesson-progress-title"><?php 
                            echo  $title_txt ;
                            if ( 'yes' === $settings['show_percentage'] ) {
                                echo  ': ' . $progress . '%' ;
                            }
                            ?></h3>
							<?php 
                        }
                        
                        ?>

							<?php 
                        $this->le_course_progress_bar( $progress, false, false );
                        ?>
						</div>
					<?php 
                    }
                    
                    ?>
					<?php 
                }
            
            } else {
                ?>
				<div class="le-widget-error">
					<p>This widget only works on LifterLMS Course or Lesson Page</p>
				</div>
				<?php 
            }
        
        } else {
            ?>
			<div class="le-widget-error">
				<p><?php 
            _e( 'This widget only works on LifterLMS Lesson Page', 'elements-for-lifterlms' );
            ?></p>
			</div>
			<?php 
        }
    
    }
    
    public function le_course_progress_bar(
        $progress,
        $link = false,
        $button = true,
        $echo = true
    )
    {
        $progress = round( $progress, 2 );
        $tag = ( $link ? 'a' : 'span' );
        $href = ( $link ? ' href=" ' . $link . ' "' : '' );
        $html = $this->le_get_progress_bar_html( $progress );
        if ( $button ) {
            $html .= '<' . $tag . ' class="llms-button-primary llms-purchase-button"' . $href . '>' . __( 'Continue', 'lifterlms' ) . '(' . $progress . '%)</' . $tag . '>';
        }
        
        if ( $echo ) {
            echo  $html ;
        } else {
            return $html;
        }
    
    }
    
    public function le_get_progress_bar_html( $percentage )
    {
        $percentage = sprintf( '%s%%', $percentage );
        $settings = $this->get_settings_for_display();
        ?>
		<?php 
        $progress_width = 'style="width:' . $percentage . '"';
        
        if ( 'yes' === $settings['allow_custom_progress_bg'] ) {
            $progress_bg_color = '';
        } else {
            $progress_bg_color = 'style="background-color: #f1f1f1"';
        }
        
        $html = '<div class="le-progress">
			
			<div class="le-progress-bar" ' . $progress_bg_color . '>
				<div class="le-progress-bar-complete" aria-valuenow="' . $percentage . '" aria-valuemin="0" aria-valuemax="100" data-progress="' . $percentage . '" ' . $progress_width . ' ></div>
			</div></div>';
        return $html;
    }
    
    public function le_course_progress_bar_animated(
        $progress,
        $link = false,
        $button = true,
        $echo = true
    )
    {
        $progress = round( $progress, 2 );
        $tag = ( $link ? 'a' : 'span' );
        $href = ( $link ? ' href=" ' . $link . ' "' : '' );
        $html = $this->le_get_progress_bar_html_animated( $progress );
        if ( $button ) {
            $html .= '<' . $tag . ' class="llms-button-primary llms-purchase-button"' . $href . '>' . __( 'Continue', 'lifterlms' ) . '(' . $progress . '%)</' . $tag . '>';
        }
        
        if ( $echo ) {
            echo  $html ;
        } else {
            return $html;
        }
    
    }
    
    public function le_get_progress_bar_html_animated( $percentage )
    {
        $percentage = sprintf( '%s%%', $percentage );
        $settings = $this->get_settings_for_display();
        
        if ( 'yes' === $settings['allow_custom_progress_bg'] ) {
            $progress_bg_color = '';
        } else {
            $progress_bg_color = 'style="background-color: #f1f1f1"';
        }
        
        $html = '<div class="le-progress">
			
			<div class="le-progress-bar" ' . $progress_bg_color . '>
				<div class="le-progress-bar-complete" aria-valuenow="' . $percentage . '" aria-valuemin="0" aria-valuemax="100" data-progress="' . $percentage . '"></div>
			</div></div>';
        ?>
		<script type="text/javascript">
			jQuery(document).ready(function($){
		      //
          	  $(".le-progress-bar-complete").animate({width: "<?php 
        echo  $percentage ;
        ?>"});
		    });
		</script>
		<?php 
        return $html;
    }

}