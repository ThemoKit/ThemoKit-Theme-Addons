<?php
/**
 * The Meta Box functionality of the plugin.
 *
 * @link       https://zeetheme.com/
 * @since      1.0.0
 *
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/admin/partials/meta-box
 */

class Elements_For_Lifterlms_Meta_box
{
	public function register() {
		/* Fire the meta box setup function on the post editor screen. */
		add_action( 'load-post.php', array( $this, 'llmse_course_meta_boxes_setup' ) );
		add_action( 'load-post-new.php', array( $this, 'llmse_course_meta_boxes_setup' ) );
		add_action( 'load-post.php', array( $this, 'llmse_lesson_meta_boxes_setup' ) );
		add_action( 'load-post-new.php', array( $this, 'llmse_lesson_meta_boxes_setup' ) );

		add_action( 'wp', array( $this, 'llmse_remove_single_course_elements' ) );
		add_action( 'wp', array( $this, 'llmse_remove_single_lesson_elements' ) );
	}
	


	/* Meta box setup function - Course */
	public function llmse_course_meta_boxes_setup(){

		/* Add meta boxes on the 'add_meta_boxes' hook. */
		add_action( 'add_meta_boxes', array( $this, 'llmse_add_course_meta_boxes' ) );
		/* Save and update meta boxes */
		add_action( 'save_post', array( $this, 'llmse_save_course_meta_boxes' ), 10, 2 );

	}

	/* Meta box setup function - Lesson */
	public function llmse_lesson_meta_boxes_setup(){

		/* Add meta boxes on the 'add_meta_boxes' hook. */
		add_action( 'add_meta_boxes', array( $this, 'llmse_add_lesson_meta_boxes' ) );
		/* Save and update meta boxes */
		add_action( 'save_post', array( $this, 'llmse_save_lesson_meta_boxes' ), 10, 2 );

	}

	/* Meta boxes - Course*/
	public function llmse_add_course_meta_boxes(){
		add_meta_box(
			'llmse-course-meta-box',
			esc_html__( 'Elements for LifterLMS', 'example' ),
			array( $this, 'llmse_hide_course_elements_meta_box' ),
			'course',
			'side',
			'default'
		);
	}

	/* Meta boxes - Lesson*/
	public function llmse_add_lesson_meta_boxes(){
		add_meta_box(
			'llmse-lesson-meta-box',
			esc_html__( 'Elements for LifterLMS', 'example' ),
			array( $this, 'llmse_hide_lesson_elements_meta_box' ),
			'lesson',
			'side',
			'default'
		);
	}

	/* Display the post meta box. - Course */
	public function llmse_hide_course_elements_meta_box( $post ) { 
		$check = get_post_meta( $post->ID, 'llmse_hide_course_elements', true );
		?>

		<?php wp_nonce_field( basename( __FILE__ ), 'llmse_hide_course_elements_nonce' ); ?>

		<p>
			<input type="checkbox" name="llmse-hide-course-elements-checkbox" value="1" <?php checked( $check, '1' ); ?> /><label for="llmse-hide-course-elements-checkbox"><b><?php _e( 'Hide Default Course Elements', 'elements-for-lifterlms' ); ?></b></label> <br /><br />
			<span style="font-size: 12px; color: #777;"><?php _e( 'This option will hide all elements added by default from the Course page, so that you get a blank canvas to design your own course page with Elementor.', 'elements-for-lifterlms' ); ?></span>
		</p>
		<?php 
	}

	/* Display the post meta box. - Lesson */
	public function llmse_hide_lesson_elements_meta_box( $post ) { 
		$check = get_post_meta( $post->ID, 'llmse_hide_lesson_elements', true );
		?>

		<?php wp_nonce_field( basename( __FILE__ ), 'llmse_hide_lesson_elements_nonce' ); ?>

		<p>
			<input type="checkbox" name="llmse-hide-lesson-elements-checkbox" value="1" <?php checked( $check, '1' ); ?> /><label for="llmse-hide-lesson-elements-checkbox"><b><?php _e( 'Hide Default Lesson Elements', 'elements-for-lifterlms' ); ?></b></label> <br /><br />
			<span style="font-size: 12px; color: #777;"><?php _e( 'This option will hide all elements added by default from the Lesson page, so that you get a blank canvas to design your own lesson page with Elementor.', 'elements-for-lifterlms' ); ?></span>
		</p>
		<?php 
	}

	//Saving or Updating meta box - Course
	public function llmse_save_course_meta_boxes( $post_id, $post ) {

		/* Verify the nonce before proceeding. */
		if ( ! isset( $_POST['llmse_hide_course_elements_nonce'] ) || ! wp_verify_nonce( $_POST['llmse_hide_course_elements_nonce'], basename( __FILE__ ) ) ) {
			return;
		}

		/* Get the post type object. */
		$post_type = get_post_type_object( $post->post_type );

		/* Check if the current user has permission to edit the post. */
		if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) ) {
			return;
		}

		$course_checkbox_input = intval( $_POST['llmse-hide-course-elements-checkbox'] );

		/* Get the posted data and sanitize it for use as an HTML class. */
		$form_data = ( isset( $course_checkbox_input ) ? $course_checkbox_input : '0' );
		update_post_meta( $post_id, 'llmse_hide_course_elements', $form_data );
	}

	//Saving or Updating meta box - Lesson
	public function llmse_save_lesson_meta_boxes( $post_id, $post ) {

		/* Verify the nonce before proceeding. */
		if ( ! isset( $_POST['llmse_hide_lesson_elements_nonce'] ) || ! wp_verify_nonce( $_POST['llmse_hide_lesson_elements_nonce'], basename( __FILE__ ) ) ) {
			return;
		}

		/* Get the post type object. */
		$post_type = get_post_type_object( $post->post_type );

		/* Check if the current user has permission to edit the post. */
		if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) ) {
			return;
		}

		$lesson_checkbox_input = intval( $_POST['llmse-hide-lesson-elements-checkbox'] );

		/* Get the posted data and sanitize it for use as an HTML class. */
		$form_data = ( isset( $lesson_checkbox_input ) ? $lesson_checkbox_input : '0' );
		update_post_meta( $post_id, 'llmse_hide_lesson_elements', $form_data );
	}

	public function llmse_remove_single_course_elements() {

		$post_id = get_the_ID();
		$elements_disabled = get_post_meta( $post_id, 'llmse_hide_course_elements', true );

		$theme = wp_get_theme();

		if ( !empty( $post_id ) ) {
			if ( $elements_disabled == 1 ) {

				remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_featured_image', 10 );
				remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_video', 20 );
				remove_action( 'lifterlms_single_course_before_summary', 'lifterlms_template_single_audio', 30 );

				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_meta_wrapper_start', 5 );
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_length', 10 );
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_difficulty', 20 );
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_tracks', 25 );
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_categories', 30 );
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_tags', 35 );
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_meta_wrapper_end', 50 );

				// Remove Course Progress.
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_course_progress', 60 );

				// Course Syllabus.
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_syllabus', 90 );

				// Instructors.
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_course_author', 40 );

				// Pricing Table.
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_pricing_table', 60 );
				// remove_action( 'lifterlms_single_membership_after_summary', 'lifterlms_template_pricing_table', 10 );

				// Prerequisites
				remove_action( 'lifterlms_single_course_after_summary', 'lifterlms_template_single_prerequisites', 55 );

				// Reviews
				remove_action('lifterlms_single_course_after_summary','lifterlms_template_single_reviews', 100);


				remove_action( 'lifterlms_single_course_after_summary', 'single_reviews', 100 );

				if ( 'Astra' == $theme->name || 'astra' == $theme->template ) {
					add_action( 'wp_head', array( $this, 'llmse_hide_course_elements_custom_css' ) );
				}

			}

		}
	}

	public function llmse_remove_single_lesson_elements() {

		$post_id = get_the_ID();
		$elements_disabled = get_post_meta( $post_id, 'llmse_hide_lesson_elements', true );

		$theme = wp_get_theme();

		if ( !empty( $post_id ) ) {
			if ( $elements_disabled == 1 ) {

				// Lesson Navigation.
			remove_action( 'lifterlms_single_lesson_after_summary', 'lifterlms_template_lesson_navigation', 20 );
			remove_action( 'astra_entry_after', 'lifterlms_template_lesson_navigation' );

			// Lesson Progression.
			remove_action( 'lifterlms_single_lesson_after_summary', 'lifterlms_template_complete_lesson_link', 10 );

			// Lesson Back to course.
			remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_parent_course', 10 );

			// Lesson Video
			remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_lesson_video', 20 );

			// Lesson Audio
			remove_action( 'lifterlms_single_lesson_before_summary', 'lifterlms_template_single_lesson_audio', 20 );

			}

		}
	}

	public function llmse_hide_course_elements_custom_css(){

		?>
		<style type="text/css">
			#old_reviews, #review_box, #thank_you_box h2{
				display: none;
			}
			.elementor-element #old_reviews, .elementor-element #review_box, .elementor-element #thank_you_box h2{
				display: block;
			}
		</style>
		<?php
	}

}

if (class_exists( 'Elements_For_Lifterlms_Meta_box' ) ) {

	$Elements_For_Lifterlms_Meta_box = new Elements_For_Lifterlms_Meta_box();
	$Elements_For_Lifterlms_Meta_box -> register();
}