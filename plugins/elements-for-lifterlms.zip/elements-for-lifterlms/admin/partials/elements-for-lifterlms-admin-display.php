<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://zeetheme.com/
 * @since      1.0.0
 *
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/admin/partials
 */

class Elements_For_Lifterlms_Admin_Page
{
	public function register() {

		add_action( 'admin_menu', array( $this, 'llmse_admin_page' ) );

	}

	/**
	 * Adding Menu and Submenu Pages
	 */
	public function llmse_admin_page() {

		add_menu_page( 'Elements for LifterLMS', 'Elements for LifterLMS', 'manage_options', 'elements-for-lifterlms', array( $this, 'llmse_setting_index' ), plugin_dir_url( dirname( __FILE__ ) ) . 'img/elements-for-lifterlms.png', 55 );

		add_submenu_page( 'elements-for-lifterlms', 'Elements for LifterLMS', 'Settings', 'manage_options', 'elements-for-lifterlms', array( $this, 'llmse_setting_index' ) );

		// add_submenu_page( 'elements-for-lifterlms', 'Documentation', 'Documentation', 'manage_options', 'elements-for-lifterlms-docs', array( $this, 'llmse_docs_index' ) );

		// add_submenu_page( 'elements-for-lifterlms', 'Video Tutorial', 'Video Tutorial', 'manage_options', 'elements-for-lifterlms-video', array( $this, 'llmse_video_index' ) );

		add_submenu_page( 'elements-for-lifterlms', 'Support', 'Support', 'manage_options', 'elements-for-lifterlms-support', array( $this, 'llmse_support_index' ) );


		add_action( 'admin_init', array( $this, 'llmse_custom_settings' ) );
		
	}

	/**
	 * Registering Settings for the Plugin
	 */
	public function llmse_custom_settings(){

		//Register Settings - Course
		register_setting( 'llmse-course-settings', 'hide-course-elements-radio' );
		register_setting( 'llmse-course-settings', 'hide-course-featured-img-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-featured-video-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-featured-audio-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-info-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-prerequisites-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-pricing-table-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-progress-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-syllabus-checkbox' );
		register_setting( 'llmse-course-settings', 'hide-course-reviews-checkbox' );

		//Register Settings - Lesson
		register_setting( 'llmse-lesson-settings', 'hide-lesson-elements-radio' );
		register_setting( 'llmse-lesson-settings', 'hide-lesson-featured-video-checkbox' );
		register_setting( 'llmse-lesson-settings', 'hide-lesson-featured-audio-checkbox' );
		register_setting( 'llmse-lesson-settings', 'hide-lesson-back-to-course-checkbox' );
		register_setting( 'llmse-lesson-settings', 'hide-lesson-mark-complete-checkbox' );
		register_setting( 'llmse-lesson-settings', 'hide-lesson-nav-checkbox' );

		//Register Settings - Membership
		register_setting( 'llmse-membership-settings', 'hide-membership-elements-checkbox' );




		//Sections - Course
		add_settings_section( 'llmse-course-settings', 'Course Settings', array( $this, 'llmse_course_settings' ), 'elements-for-lifterlms' );

		//Sections - Lesson
		add_settings_section( 'llmse-lesson-settings', 'Lesson Settings', array( $this, 'llmse_lesson_settings' ), 'elements-for-lifterlms' );

		//Sections - Lesson
		add_settings_section( 'llmse-membership-settings', 'Membership Settings', array( $this, 'llmse_membership_settings' ), 'elements-for-lifterlms' );




		//Setting Fields - Course
		add_settings_field( 'hide-course-elements-radio', 'Hide Course Elements', array( $this, 'hide_course_elements_radio' ), 'elements-for-lifterlms', 'llmse-course-settings' );

		add_settings_field( 'hide-course-featured-img-checkbox', 'Hide Featured Image', array( $this, 'hide_course_featured_img_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );

		add_settings_field( 'hide-course-featured-video-checkbox', 'Hide Featured Video', array( $this, 'hide_course_featured_video_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );
		add_settings_field( 'hide-course-featured-audio-checkbox', 'Hide Featured Audio', array( $this, 'hide_course_featured_audio_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );
		add_settings_field( 'hide-course-info-checkbox', 'Hide Course Info', array( $this, 'hide_course_info_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('(Course Length, Category, Tags, author e.t.c)') );
		add_settings_field( 'hide-course-prerequisites-checkbox', 'Hide Prerequisites', array( $this, 'hide_course_prerequisites_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );
		add_settings_field( 'hide-course-pricing-table-checkbox', 'Hide Pricing Table', array( $this, 'hide_course_pricing_table_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );
		add_settings_field( 'hide-course-progress-checkbox', 'Hide Course Progress', array( $this, 'hide_course_progress_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );
		add_settings_field( 'hide-course-syllabus-checkbox', 'Hide Syllabus', array( $this, 'hide_course_syllabus_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );
		add_settings_field( 'hide-course-reviews-checkbox', 'Hide Course Reviews', array( $this, 'hide_course_reviews_checkbox' ), 'elements-for-lifterlms', 'llmse-course-settings', array('') );


		//Setting Fields - Lesson
		add_settings_field( 'hide-lesson-elements-radio', 'Hide Lesson Elements', array( $this, 'hide_lesson_elements_radio' ), 'elements-for-lifterlms', 'llmse-lesson-settings' );

		add_settings_field( 'hide-lesson-featured-video-checkbox', 'Hide Featured Video', array( $this, 'hide_lesson_featured_video_checkbox' ), 'elements-for-lifterlms', 'llmse-lesson-settings', array('') );

		add_settings_field( 'hide-lesson-featured-audio-checkbox', 'Hide Featured Audio', array( $this, 'hide_lesson_featured_audio_checkbox' ), 'elements-for-lifterlms', 'llmse-lesson-settings', array('') );

		add_settings_field( 'hide-lesson-back-to-course-checkbox', 'Hide Back to Course Link', array( $this, 'hide_lesson_back_to_course_checkbox' ), 'elements-for-lifterlms', 'llmse-lesson-settings', array('') );

		add_settings_field( 'hide-lesson-mark-complete-checkbox', 'Hide Mark Complete Button', array( $this, 'hide_lesson_mark_complete_checkbox' ), 'elements-for-lifterlms', 'llmse-lesson-settings', array('') );

		add_settings_field( 'hide-lesson-nav-checkbox', 'Hide Lesson Navigation', array( $this, 'hide_lesson_nav_checkbox' ), 'elements-for-lifterlms', 'llmse-lesson-settings', array('') );


		//Setting Fields - Membership
		add_settings_field( 'hide-membership-elements-checkbox', 'Hide Membership Elements', array( $this, 'hide_membership_elements_checkbox' ), 'elements-for-lifterlms', 'llmse-membership-settings' );
		

	}

	// Membership Setting Fields

	public function hide_membership_elements_checkbox($args){
		$options = get_option('hide-membership-elements-checkbox');
		?>
		<label class="llmse-checkbox-wrap">
			<input type="checkbox" name="hide-membership-elements-checkbox" value="1" <?php checked(1, $options, true); ?> />
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}



	// Lesson Setting Fields
	
	public function hide_lesson_elements_radio($args){

		$options = get_option('hide-lesson-elements-radio');

		?>
		<div class="llmse-radio-switch-wrap lesson-">
			<label class="llmse-radio-switch">
				<input type="radio" id="hide-lesson-elements" name="hide-lesson-elements-radio" checked value="1" <?php checked(1, $options, true); ?>>
				<span><?php _e( 'Hide Individual Elements', 'elements-for-lifterlms' ); ?></span>
			</label>
			<label class="llmse-radio-switch">
				<input type="radio" id="hide-lesson-elements" name="hide-lesson-elements-radio" value="2" <?php checked(2, $options, true); ?>>
				<span><?php _e( 'Hide All Elements', 'elements-for-lifterlms' ); ?></span>
			</label>
		</div>

        <span class="llmse-option-info switch">
        	<i class="fa fa-question-circle" aria-hidden="true"></i>
        	<span class="llmse-option-info-box"><?php _e( 'These options, if checked, will remove the elements from all the lesson pages. If you want to remove elements from individual lesson page, then leave these options unchecked and configure the options in the lesson editor of individual courses.', 'elements-for-lifterlms' ); ?></span>
        </span>
		<?php
	}

	public function hide_lesson_featured_video_checkbox($args){
		$options = get_option('hide-lesson-featured-video-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-lesson-elements-radio') == 2) { echo "lesson-option-hide"; } ?>">
			<input type="checkbox" name="hide-lesson-featured-video-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>

		<?php
	}

	public function hide_lesson_featured_audio_checkbox($args){
		$options = get_option('hide-lesson-featured-audio-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-lesson-elements-radio') == 2) { echo "lesson-option-hide"; } ?>">
			<input type="checkbox" name="hide-lesson-featured-audio-checkbox" value="1" <?php checked(1, $options, true); ?> />
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_lesson_back_to_course_checkbox($args){
		$options = get_option('hide-lesson-back-to-course-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-lesson-elements-radio') == 2) { echo "lesson-option-hide"; } ?>">
			<input type="checkbox" name="hide-lesson-back-to-course-checkbox" value="1" <?php checked(1, $options, true); ?> />
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_lesson_mark_complete_checkbox($args){
		$options = get_option('hide-lesson-mark-complete-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-lesson-elements-radio') == 2) { echo "lesson-option-hide"; } ?>">
			<input type="checkbox" name="hide-lesson-mark-complete-checkbox" value="1" <?php checked(1, $options, true); ?> />
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_lesson_nav_checkbox($args){
		$options = get_option('hide-lesson-nav-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-lesson-elements-radio') == 2) { echo "lesson-option-hide"; } ?>">
			<input type="checkbox" name="hide-lesson-nav-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>

		<?php
	}



	// Course Setting Fields

	public function hide_course_elements_radio($args){

		$options = get_option('hide-course-elements-radio');

		?>
		<div class="llmse-radio-switch-wrap course-">
			<label class="llmse-radio-switch">
				<input type="radio" id="hide-course-elements" name="hide-course-elements-radio" checked value="1" <?php checked(1, $options, true); ?>>
				<span><?php _e( 'Hide Individual Elements', 'elements-for-lifterlms' ); ?></span>
			</label>
			<label class="llmse-radio-switch">
				<input type="radio" id="hide-course-elements" name="hide-course-elements-radio" value="2" <?php checked(2, $options, true); ?>>
				<span><?php _e( 'Hide All Elements', 'elements-for-lifterlms' ); ?></span>
			</label>
		</div>

        <span class="llmse-option-info switch">
        	<i class="fa fa-question-circle" aria-hidden="true"></i>
        	<span class="llmse-option-info-box"><?php _e( 'These options, if checked, will remove the elements from all the course pages. If you want to remove elements from individual course page, then leave these options unchecked and configure the options in the course editor of individual courses.', 'elements-for-lifterlms' ); ?></span>
        </span>
		<?php
	}

	public function hide_course_featured_img_checkbox($args){
		$options = get_option('hide-course-featured-img-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-featured-img-checkbox" value="1" <?php checked(1, $options, true); ?> />
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_course_featured_video_checkbox($args){
		$options = get_option('hide-course-featured-video-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-featured-video-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>

		<?php
	}

	public function hide_course_featured_audio_checkbox($args){
		$options = get_option('hide-course-featured-audio-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-featured-audio-checkbox" value="1" <?php checked(1, $options, true); ?> />
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_course_info_checkbox($args){
		$options = get_option('hide-course-info-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-info-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}


	public function hide_course_prerequisites_checkbox($args){
		$options = get_option('hide-course-prerequisites-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-prerequisites-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_course_pricing_table_checkbox($args){
		$options = get_option('hide-course-pricing-table-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-pricing-table-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_course_progress_checkbox($args){
		$options = get_option('hide-course-progress-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-progress-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_course_syllabus_checkbox($args){
		$options = get_option('hide-course-syllabus-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-syllabus-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}

	public function hide_course_reviews_checkbox($args){
		$options = get_option('hide-course-reviews-checkbox');
		?>
		<label class="llmse-checkbox-wrap <?php if (get_option('hide-course-elements-radio') == 2) { echo "option-hide"; } ?>">
			<input type="checkbox" name="hide-course-reviews-checkbox" value="1" <?php checked(1, $options, true); ?> /> 
			<span class="llmse-checkbox"><i class="fa fa-check" aria-hidden="true"></i></span>
		</label>
		<?php
	}





	







	/**
	 * Course Settings
	 */
	public function llmse_course_settings(){

		?>
		<h3 class="settings-tab-head"><?php _e( 'Course Settings', 'elements-for-lifterlms' ); ?></h3>
		<p><?php _e( 'Configure the settings of Elements for LifterLMS for Course Page.', 'elements-for-lifterlms' ); ?></p>
		<br><br>

		<h3 style="font-size: 18px;"><?php _e( 'Hide Elements', 'elements-for-lifterlms' ); ?></h3>
		<p><?php _e( 'It is important to hide all the elements added by default from the Course page, so that you get a blank canvas to design your own course page.', 'elements-for-lifterlms' ); ?> 
		</p>
		<?php
	}

	/**
	 * Lesson Settings
	 */
	public function llmse_lesson_settings(){

		?>
		</div>
		<div class="llmse-tab-3">
		<h3 class="settings-tab-head"><?php _e( 'Lesson Settings', 'elements-for-lifterlms' ); ?></h3>
		<p><?php _e( 'Configure the settings of Elements for LifterLMS for Lesson Page.', 'elements-for-lifterlms' ); ?></p>
		<br><br>

		<h3 style="font-size: 18px;"><?php _e( 'Hide Elements', 'elements-for-lifterlms' ); ?></h3>
		<p><?php _e( 'It is important to hide all the elements added by default from the Lesson page, so that you get a blank canvas to design your own lesson page.', 'elements-for-lifterlms' ); ?> 
		</p>
		<?php
	}

	/**
	 * Membership Settings
	 */
	public function llmse_membership_settings(){

		?>
		</div>
		<div class="llmse-tab-4">
		<h3 class="settings-tab-head"><?php _e( 'Membership Settings', 'elements-for-lifterlms' ); ?></h3>
		<p><?php _e( 'Configure the settings of Elements for LifterLMS for Membership Page.', 'elements-for-lifterlms' ); ?></p>
		<br><br>

		<h3 style="font-size: 18px;"><?php _e( 'Hide Elements', 'elements-for-lifterlms' ); ?></h3>
		<p><?php _e( 'It is important to hide all the elements added by default from the Membership page, so that you get a blank canvas to design your own membership page.', 'elements-for-lifterlms' ); ?>
		</p>
		<?php
	}

	/**
	 * Settings page
	 */
	public function llmse_setting_index() {

		require_once plugin_dir_path( dirname( __FILE__ ) ) . '/partials/elements-for-lifterlms-admin-settings-page.php';
	}

	/**
	 * Video Tutorial Page
	 */
	public function llmse_video_index() {

		require_once plugin_dir_path( dirname( __FILE__ ) ) . '/partials/elements-for-lifterlms-admin-video-page.php';
	}

	/**
	 * Documentation Page
	 */
	public function llmse_docs_index() {

		require_once plugin_dir_path( dirname( __FILE__ ) ) . '/partials/elements-for-lifterlms-admin-docs-page.php';
	}

	/**
	 * Support Page
	 */
	public function llmse_support_index() {

		require_once plugin_dir_path( dirname( __FILE__ ) ) . '/partials/elements-for-lifterlms-admin-support-page.php';
	}

}

if (class_exists( 'Elements_For_Lifterlms_Admin_Page' ) ) {

	$Elements_For_Lifterlms_Admin_Page = new Elements_For_Lifterlms_Admin_Page();
	$Elements_For_Lifterlms_Admin_Page -> register();
}
