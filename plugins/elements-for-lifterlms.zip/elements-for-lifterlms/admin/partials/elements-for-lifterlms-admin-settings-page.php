<?php

/**
 * Settings page of the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://zeetheme.com/
 * @since      1.0.0
 *
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/admin/partials
 */
if ( !current_user_can( 'manage_options' ) ) {
    wp_die( 'You do nat have permission to access this page' );
}
$account_url = llms_elements()->get_account_url();
?>

<div class="wrap llmse-wrap" >

	<h2></h2>

	<div class="llmse-settings-wrap">

		<div class="llmse-addon-wrap">

			<div class="llmse-settings-sidebar">

				<header class="llmse-settings-header">
					<span class="llmse-settings-logo">
						<img src="<?php echo  plugin_dir_url( dirname( __FILE__ ) ) . 'img/elements-for-lifterlms-logo.png'; ?>">
					</span>
					<span class="llmse-settings-title"><?php 
					_e( 'Elements for LifterLMS', 'elements-for-lifterlms' );
					?></span>
				</header>

				<nav class="llmse-settings-nav">
					<ul>
						<li class="llmse-settings-nav-list"><a class="current" href="?page=elements-for-lifterlms"><i class="fa fa-sliders" style="margin-right: 10px" aria-hidden="true"></i><?php _e( 'Settings', 'elements-for-lifterlms' ); ?></a></li>
						<li class="llmse-settings-nav-list"><a href="<?php echo $account_url ?>"><i class="fa fa-user-o" style="margin-right: 10px" aria-hidden="true"></i><?php _e( 'Account', 'elements-for-lifterlms' ); ?></a></li>
						<!-- <li class="llmse-settings-nav-list"><a href="?page=elements-for-lifterlms-docs"><i class="fa fa-book" style="margin-right: 10px" aria-hidden="true"></i>Documentation</a></li> -->
						<!-- <li class="llmse-settings-nav-list"><a href="?page=elements-for-lifterlms-video"><i class="fa fa-youtube-play" style="margin-right: 10px" aria-hidden="true"></i>Video Tutorials</a></li> -->
						<li class="llmse-settings-nav-list"><a href="?page=elements-for-lifterlms-support"><i class="fa fa-life-ring" style="margin-right: 10px" aria-hidden="true"></i><?php _e( 'Support', 'elements-for-lifterlms' ); ?></a></li>
					</ul>
				</nav>

			</div>

			<div class="llmse-settings-content">

				<div class="llmse-settings-content-wrap">

					<h1 class="llmse-settings-heading">Settings</h1>

					<?php 

					if ( isset( $_GET['tab'] ) ) {
					    $active_tab = esc_attr( $_GET['tab'] );
					} else {
					    $active_tab = 'general_options';
					}

					// end if
					?>

					<div class="nav-tab-wrapper llmse-tab-wrapper">
			            <a href="?page=elements-for-lifterlms&tab=general_options" class="nav-tab llmse_setting_nav <?php if ($active_tab == 'general_options') echo 'nav-tab-active'; ?>"><?php _e( 'General', 'elements-for-lifterlms' ); ?></a>
			            <a href="?page=elements-for-lifterlms&tab=course_settings" class="nav-tab llmse_setting_nav <?php if ($active_tab == 'course_settings') echo 'nav-tab-active'; ?>"><?php _e( 'Course', 'elements-for-lifterlms' ); ?></a>
			            <a href="?page=elements-for-lifterlms&tab=lesson_settings" class="nav-tab llmse_setting_nav <?php if ($active_tab == 'lesson_settings') echo 'nav-tab-active'; ?>"><?php _e( 'Lesson', 'elements-for-lifterlms' ); ?></a>
			            <a href="?page=elements-for-lifterlms&tab=membership_settings" class="nav-tab llmse_setting_nav <?php if ($active_tab == 'membership_settings') echo 'nav-tab-active'; ?>"><?php _e( 'Membership', 'elements-for-lifterlms' ); ?></a>
			        </div>

			        <form method="post" action="options.php">

						<?php 

						if ( $active_tab == 'general_options' ) {
						    $the_active_tab = 'one';
						} elseif ( $active_tab == 'course_settings' ) {
						    $the_active_tab = 'two';
						} elseif ( $active_tab == 'lesson_settings' ) {
						    $the_active_tab = 'three';
						} elseif ( $active_tab == 'membership_settings' ) {
						    $the_active_tab = 'four';
						}

						?>

			        	<div class="llmse-tab-content show-tab-<?php echo $the_active_tab; ?>">

			        			<div class="llmse-tab-1">
			        				<h3 class="settings-tab-head"><?php _e( 'Elements', 'elements-for-lifterlms' ); ?></h3>

			        				<!-- <div class="llmse-license-box">	

									</div> -->

									<div class="llmse-settings-blocks">
					        			<div class="llmse-settings-block docs">
					        				<a target="_blank" href="https://lifterlmselements.com/documentation/">
					        					<img src="https://res.cloudinary.com/zeetheme/image/upload/v1552927701/LifterLMS%20Elements/contract.png">
					        					<span class="llmse-settings-head"><?php _e( 'Read Documentation', 'elements-for-lifterlms' ); ?></span>
					        					<p><?php _e( 'Don\'t know how to use elements for lifterlms? Read the documentaion.', 'elements-for-lifterlms' ); ?></p>
					        				</a>
					        			</div>
					        			<div class="llmse-settings-block templates">
					        				<a target="_blank" href="https://lifterlmselements.com/templates/">
					        					<img src="https://res.cloudinary.com/zeetheme/image/upload/v1552927705/LifterLMS%20Elements/download.png">
					        					<span class="llmse-settings-head"><?php _e( 'Download Premade Templates', 'elements-for-lifterlms' ); ?></span>
					        					<p><?php _e( 'Download Premade Course and Lesson templates and create amazing layouts in no time.', 'elements-for-lifterlms' ); ?></p>
					        				</a>
					        			</div>
					        		</div>



			        			</div>


								<?php 

								if ($active_tab == 'course_settings') {

									settings_fields( 'llmse-course-settings' ); 

								}elseif ($active_tab == 'lesson_settings') {

									settings_fields( 'llmse-lesson-settings' ); 

								}elseif ($active_tab == 'membership_settings') {

									settings_fields( 'llmse-membership-settings' ); 

								}

								?>

								<div class="llmse-tab-2">

								<?php do_settings_sections( 'elements-for-lifterlms' ); ?>

								</div>

							<?php if ($active_tab != 'general_options') { ?>
								<div class="llmse-submit-btn">
									<?php submit_button(); ?>
								</div>
							<?php } ?>

						</div>

					</form>

				</div>

			</div>

		</div>

	</div>

</div>
<style type="text/css">
	#wpfooter{
		position: unset;
	}

	#wpfooter #footer-left{
		display: none;
	}
</style>
