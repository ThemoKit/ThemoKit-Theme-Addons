<?php
/**
 * Support page of the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://zeetheme.com/
 * @since      1.0.0
 *
 * @package    Elements_For_Lifterlms
 * @subpackage Elements_For_Lifterlms/admin/partials
 */

if (!current_user_can('manage_options' )) {
	wp_die('You do nat have permission to access this page' );
}

$account_url = llms_elements()->get_account_url();

?>

<div class="wrap llmse-wrap" >

	<h2></h2>

	<div class="llmse-settings-wrap">

		<div class="llmse-addon-wrap">

			<div class="llmse-settings-sidebar">

				<header class="llmse-settings-header">
					<span class="llmse-settings-logo"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'img/elements-for-lifterlms-logo.png'; ?>"></span>
					<span class="llmse-settings-title"><?php _e( 'Elements for LifterLMS', 'elements-for-lifterlms' ); ?></span>
				</header>

				<nav class="llmse-settings-nav">
					<ul>
						<li class="llmse-settings-nav-list"><a href="?page=elements-for-lifterlms"><i class="fa fa-sliders" style="margin-right: 10px" aria-hidden="true"></i><?php _e( 'Settings', 'elements-for-lifterlms' ); ?></a></li>
						<li class="llmse-settings-nav-list"><a href="<?php echo $account_url ?>"><i class="fa fa-user-o" style="margin-right: 10px" aria-hidden="true"></i><?php _e( 'Account', 'elements-for-lifterlms' ); ?></a></li>
						<!-- <li class="llmse-settings-nav-list"><a href="?page=elements-for-lifterlms-docs"><i class="fa fa-book" style="margin-right: 10px" aria-hidden="true"></i>Documentation</a></li> -->
						<!-- <li class="llmse-settings-nav-list"><a href="?page=elements-for-lifterlms-video"><i class="fa fa-youtube-play" style="margin-right: 10px" aria-hidden="true"></i>Video Tutorials</a></li> -->
						<li class="llmse-settings-nav-list"><a class="current" href="?page=elements-for-lifterlms-support"><i class="fa fa-life-ring" style="margin-right: 10px" aria-hidden="true"></i><?php _e( 'Support', 'elements-for-lifterlms' ); ?></a></li>
					</ul>
				</nav>

			</div>

			<div class="llmse-settings-content">

				<div class="llmse-settings-content-wrap">

					<h2 class="llmse-settings-heading"><?php _e( 'Support', 'elements-for-lifterlms' ); ?></h2>

					<p><?php _e( 'Please visit ony of these links for support.', 'elements-for-lifterlms' ); ?></p>

					<ul class="llmse-support-links">
						<li><a target="_blank" href="https://www.facebook.com/groups/2409753875977922/"><?php _e( 'Elements for LifterLMS Facebook Group', 'elements-for-lifterlms' ); ?></a></li>
						<li><a target="_blank" href="https://lifterlmselements.com/contact"><?php _e( 'Elements for LifterLMS Contact Page', 'elements-for-lifterlms' ); ?></a></li>
						<li><?php _e( 'Email us - ', 'elements-for-lifterlms' ); ?><a target="_blank" href="mailto:support@lifterlmselements.com">support@lifterlmselements.com</a></li>
					</ul>

					

				</div>

			</div>

		</div>

	</div>

</div>
<style type="text/css">
	#wpfooter{
		position: unset;
	}

	#wpfooter #footer-left{
		display: none;
	}
</style>

