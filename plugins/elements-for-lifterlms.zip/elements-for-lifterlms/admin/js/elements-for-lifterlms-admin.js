(function( $ ) {
	'use strict';

	jQuery(document).ready(function($){

		$(".llmse-checkbox-wrap.option-hide").parents('tr').css( { 'display': 'none' } );
		$(".llmse-checkbox-wrap.lesson-option-hide").parents('tr').css( { 'display': 'none' } );

		$("input[name='hide-course-elements-radio']:radio").change(function() {
			$(".llmse-checkbox-wrap").parents('tr').toggle($(this).val() == "1");
			// $(".llmse-checkbox-wrap.option-hide").parents('tr').toggle($(this).val() == "2");
		});

		$("input[name='hide-lesson-elements-radio']:radio").change(function() {
			$(".llmse-checkbox-wrap").parents('tr').toggle($(this).val() == "1");
		});

	});

})( jQuery );
