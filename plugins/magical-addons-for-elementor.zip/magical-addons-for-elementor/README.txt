=== Magical Addons For Elementor ===
Contributors: nalam
Donate link: 
Tags: elementor, elementor page builder, elementor addons, addons, elementor widget, page builder, pricing table, countdown timer, Info Box,
Requires at least: 4.0
Version:  1.0.0
Tested up to: 5.3
Stable tag: Trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
<h4>Create or add elements in your website with the magical way!!</h4> 
Now you can add or update your site elements very easily by Magical Addons For Elementor. Supercharge your Elementor Page Builder with highly customizable Magical Addons For Elementor 

<p>Magical Addons For Elementor is one of the most user friendly Addons For Elementor. You can display your site content magicaly by Magical Addons For Elementor. You can set unlimited options for every widget. You can achieve nearly any design with your imagination. Each widget and addon has been tested on different screen sizes, mobile devices. </p>

<p>Magical Addons For Elementor has a huge collection of premium, easy to use yet highly functional extensions that can be used in a Elementor page builder. This is really a premium plugin that you can get for free.</p>
<h4>Popular widget: </h4>
<ul>
 	<li><strong>Pricing table.</strong></li>
 	<li><strong>Countdown Timer.</strong></li>
 	<li><strong>Progressbar.</strong></li>
 	<li><strong>Info Box.</strong></li>
 	<li><strong>Dual heading.</strong></li>
</ul>

<strong>Note:</strong> This plugin is an addon of Elementor Page Builder. So the plugin only work with Elementor Page Builder plugin.
(https://wordpress.org/plugins/elementor/)

#### Translations

* English

== Installation ==

<h2>This section describes how to install the plugin and get it working.</h2>

e.g.

<h4>First things first, thank you for choosing our Gallery Box lite plugin!</h4>
<h4>You can install the plugin one of two ways:</h4>
<h5 class="short-info">Install using FTP</h5>
<ul>
 	<li>Unzip the <strong>Home-animation-slider.zip</strong> file locally to your machine</li>
 	<li>Connect to your FTP area using your preferred FTP package</li>
 	<li>Upload the <strong>Home-animation-slider.zip</strong> folder that you extracted from the zip file to the plugin folder of your WordPress installation (<strong>wp-content -&gt; plugin</strong>)</li>
 	<li>Go to <strong>plugin </strong> and activate Magical Posts Display.</li>
</ul>
<h5 class="short-info">Install by WordPress (recommended)</h5>
<ul>
 	<li>Login to your WordPress admin area.</li>
 	<li>Navigate to <strong>plugin</strong> and click the <strong>Add New</strong> button at the top.</li>
 	<li>Click the <strong>Upload plugin</strong> button at the top.</li>
 	<li>Click the <strong>Choose File</strong> button and locate the <strong>Home animation-animation-slider.zip</strong> file on your machine and click the <strong>Install Now</strong> button.</li>
 	<li>On the basis the plugin installs correctly, click the <strong>Activate</strong> link.</li>
</ul>

== Frequently Asked Questions  ==

= Does it work with any WordPress theme?  =

 Yes, it will work with any WordPress theme as long as you are using Elementor as a page builder.
= Will this plugin slow down my website speed?  =

 No, the plugin don't slow your website.

= Can I use the plugin without Elementor Page Builder? =

 No. You cannot use without Elementor since it’s an addon for Elementor.


== Screenshots ==
1. Magical Addons For Elementor backend editor.
2. Magical Addons For Elementor front display .


== Changelog ==

= 1.0.0 =
Released version

compatible with WordPress 5.3

