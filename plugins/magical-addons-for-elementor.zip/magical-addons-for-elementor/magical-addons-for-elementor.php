<?php
/**
 * @link              http://wpthemespace.com
 * @since             1.1.0
 * @package           Magical Addons For Elementor
 *
 * @wordpress-plugin
 * Plugin Name:       Magical Addons For Elementor
 * Plugin URI:        
 * Description:       One of the best adons for Elementor page builder
 * Version:           1.0.0
 * Author:            Noor alam
 * Author URI:        https://profiles.wordpress.org/nalam-1
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       magical-addons-for-elementor
 * Domain Path:       /languages
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'MAGICAL_ADDON_URL', plugin_dir_url( __FILE__ ) );
define( 'MAGICAL_ADDON_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Main Magical Addons For Elementor Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class Magical_Addons_Elementor {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Elementor_Test_Extension The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Elementor_Test_Extension An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'init' ] );

	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 *
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function i18n() {

		load_plugin_textdomain( 'magical-addons-for-elementor' );

	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Add Plugin actions
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_new_category' ] );
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'frontend_widget_styles' ] );
		add_action( "elementor/frontend/after_enqueue_scripts", [ $this, 'frontend_assets_scripts' ] );
		add_action( "elementor/frontend/after_enqueue_scripts", [ $this, 'frontend_progressbar_scripts' ] );
	}

		public function register_new_category($manager){
		$manager->add_category('magical',[
			'title' => esc_html__('Magical Elements','magical-addons-for-elementor'),
			'icon' => 'fa fa-magic',
		]);
	}

	/*
	plugin css
	*/
	function frontend_widget_styles(){
		wp_enqueue_style( 'bootstrap',  plugins_url( '/assets/css/bootstrap.min.css', __FILE__ ), array(), '4.3.1', 'all');
		wp_enqueue_style( 'magical-default-style',  plugins_url( '/assets/css/mg-default-style.css', __FILE__ ), array(), '1.0', 'all');
		wp_enqueue_style( 'flipclock',  plugins_url( '/assets/css/flipclock.css', __FILE__ ), array(), '1.0', 'all');
		wp_enqueue_style( 'mg-style',  plugins_url( '/assets/css/mg-style.css', __FILE__ ), array(), time(), 'all');
	}
	/*
	plugin js
	*/
	function frontend_assets_scripts(){
		wp_enqueue_script("flipclock-js",plugins_url("/assets/js/flipclock.min.js",__FILE__),array('jquery'),'1.0',true);
		wp_enqueue_script("mga-script-js",plugins_url("/assets/js/main-scripts.js",__FILE__),array('jquery'),time(),true);
	}
	/*
	progressbar scripts
	*/
	function frontend_progressbar_scripts(){
		wp_enqueue_script("progressbar-js",plugins_url("/assets/js/progressbar/progressbar.min.js",__FILE__),array('jquery'),'1.0',true);
		wp_enqueue_script("progressbar-active-js",plugins_url("/assets/js/progressbar/progressbar-active.js",__FILE__),array('jquery'),time(),true);
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
		/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'magical-addons-for-elementor' ),
			'<strong>' . esc_html__( 'Magical addons for elementor', 'magical-addons-for-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'magical-addons-for-elementor' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
		/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'magical-addons-for-elementor' ),
			'<strong>' . esc_html__( 'Magical addons for elementor', 'magical-addons-for-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'magical-addons-for-elementor' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'magical-addons-for-elementor' ),
			'<strong>' . esc_html__( 'Magical addons for elementor', 'magical-addons-for-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'magical-addons-for-elementor' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {

		// Include Widget files
		require_once( __DIR__ . '/includes/widgets/dual-heading-widget.php' );
		require_once( __DIR__ . '/includes/widgets/pricing-table-widget.php' );
		require_once( __DIR__ . '/includes/widgets/countdown-widget.php' );
		require_once( __DIR__ . '/includes/widgets/progressbar-widget.php' );
		require_once( __DIR__ . '/includes/widgets/infobox-widget.php' );

		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \MgAddon_Dual_Heading() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \MgAddon_Pricing_Table() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \MgCountdown() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \MgProgressbar() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \MgAddon_Info_Box() );

	}

}

Magical_Addons_Elementor::instance();