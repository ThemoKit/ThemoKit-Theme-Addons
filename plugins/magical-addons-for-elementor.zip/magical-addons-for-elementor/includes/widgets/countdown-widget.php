<?php


class MgCountdown extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Blank widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'mgcountdown_widget';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Blank widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Countdown', 'magical-addons-for-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Blank widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'far fa-clock';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Blank widget belongs to.
	 *
	 * @return array Widget categories.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_categories() {
		return [ 'magical' ];
	}

	/**
	 * Register Blank widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->register_content_controls();
		$this->register_style_controls();

	}

	/**
	 * Register Blank widget content ontrols.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	function register_content_controls() {
		$this->start_controls_section(
			'mg_countdown',
			[
				'label' => __( 'Countdown options', 'magical-addons-for-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'display_type',
			[
				'label' => __( 'Display Type', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'timec' => __( 'Time countdown', 'magical-addons-for-elementor' ),
					'genericc' => __( 'Number countdown', 'magical-addons-for-elementor' ),
					'clock' => __( 'Clock', 'magical-addons-for-elementor' ),
				],
				'default' => 'timec',
			]
		);
		$this->add_control(
			'clock_format',
			[
				'label' => __( 'Clock format', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'12' => __( '12 Hour format', 'magical-addons-for-elementor' ),
					'24' => __( '24 Hour format', 'magical-addons-for-elementor' ),
				],
				'default' => '12',
				'condition' => [
					'display_type' => 'clock',
				],
			]
		);
		$this->add_control(
			'target_clock_time',
			[
				'label' => __( 'Set time', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
				'default' => '2021-11-01 23:57',
				'condition' => [
					'display_type' => 'timec',
				],
			]
		);
		$this->add_control(
			'genericc_countdown',
			[
				'label' => __( 'Countdown Form', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'display_type' => 'genericc',
				],
				'default' => '500',

			]
		);
		$this->add_control(
			'countdown_timing',
			[
				'label' => __( 'Countdown timing', 'magical-addons-for-elementor' ),
				'description' => __( 'Set countdown timing by millisecond. default set 1 second (1000)', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'display_type' => 'genericc',
				],
				'default' => '1000',

			]
		);
		$this->add_responsive_control(
			'mgcountdown_align',
			[
				'label' => __( 'Countdown Alignment', 'elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					],
					
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Blank widget style ontrols.
	 *
	 * Adds different input fields in the style tab to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_style_controls() {

		$this->start_controls_section(
			'mg_countdown_style',
			[
				'label' => __( 'Countdown style', 'magical-addons-for-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'num_bgcolor',
			[
				'label'     => __( 'Number background color', 'magical-addons-for-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#222',
				'selectors' => [
					'{{WRAPPER}} .flip-clock-wrapper ul li a div div.inn' => 'background-color: {{VALUE}}'
				]
			]
		);
		$this->add_control(
			'num_color',
			[
				'label'     => __( 'Number color', 'magical-addons-for-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ccc',
				'selectors' => [
					'{{WRAPPER}} .flip-clock-wrapper ul li a div div.inn' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_control(
			'numdiv_color',
			[
				'label'     => __( 'Number divider color', 'magical-addons-for-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .flip-clock-wrapper ul li a div.up:after' => 'background-color: {{VALUE}}'
				]
			]
		);
		$this->add_control(
			'numdot_color',
			[
				'label'     => __( 'Number dot color', 'magical-addons-for-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .flip-clock-dot' => 'background-color: {{VALUE}}'
				]
			]
		);
		$this->add_control(
			'ampm_color',
			[
				'label'     => __( 'Other text color', 'magical-addons-for-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .flip-clock-meridium a,.flip-clock-divider .flip-clock-label' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'label'    => __( 'Typography', 'magical-addons-for-elementor' ),
				'scheme'   => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .flip-clock-wrapper,.flip-clock-wrapper ul,.flip-clock-wrapper ul li a div',
			]
		);

		$this->end_controls_section();


	}

	/**
	 * Render Blank widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings   = $this->get_settings_for_display(); 
		$display_type   = $this->get_settings( 'display_type' ); 
		$clock_format   = $this->get_settings( 'clock_format' ); 
		$target_clock_time   = $this->get_settings( 'target_clock_time' ); 
		$genericc_countdown   = $this->get_settings( 'genericc_countdown' ); 
		$countdown_timing   = $this->get_settings( 'countdown_timing' ); 
		?>
		<div class="mga-clock" data-display-type="<?php echo $display_type; ?>" data-clock-format="<?php echo $clock_format; ?>" data-target-time="<?php echo $target_clock_time; ?>" data-countdown="<?php echo $genericc_countdown; ?>" data-timing="<?php echo $countdown_timing ?>"></div>
		<?php


	}

	/**
	 * Render Blank widget output on the frontend.
	 *
	 * Written in JS and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {


		
	}

}