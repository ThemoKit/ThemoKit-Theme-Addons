<?php

use Elementor\Group_Control_Image_Size;
class MgAddon_Info_Box extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Blank widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'mginfobox_widget';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Blank widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Info Box', 'magical-addons-for-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Blank widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'fas fa-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Blank widget belongs to.
	 *
	 * @return array Widget categories.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_categories() {
		return [ 'magical' ];
	}

	/**
	 * Register Blank widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->register_content_controls();
		$this->register_style_controls();

	}

	/**
	 * Register Blank widget content ontrols.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	function register_content_controls() {
		$this->start_controls_section(
			'icon_section',
			[
				'label' => __( 'Icon or Image', 'magical-addons-for-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'use_icon',
			[
				'label' => __( 'Show Icon or image?', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'magical-addons-for-elementor' ),
				'label_off' => __( 'No', 'magical-addons-for-elementor' ),
				'default' => 'yes',
			]
		);
		$this->add_control(
			'main_icon_position',
			[
				'label' => __( 'Icon position', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'magical-addons-for-elementor' ),
						'icon' => 'fas fa-arrow-left',
					],
					'top' => [
						'title' => __( 'Top', 'magical-addons-for-elementor' ),
						'icon' => 'fas fa-arrow-up',
					],
					'right' => [
						'title' => __( 'Right', 'magical-addons-for-elementor' ),
						'icon' => 'fas fa-arrow-right',
					],
					
				],
				'default' => 'top',
				'toggle' => false,
				'condition' => [
					'use_icon' => 'yes',
				],
			]
		);
		$this->add_control(
			'icon_type',
			[
				'label' => __( 'Icon Type', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'icon' => [
						'title' => __( 'Icon', 'magical-addons-for-elementor' ),
						'icon' => 'fas fa-info',
					],
					'image' => [
						'title' => __( 'Image', 'magical-addons-for-elementor' ),
						'icon' => 'far fa-image',
					],
					
				],
				'default' => 'icon',
				'toggle' => true,
			]
		);
		$this->add_control(
			'type_icon',
			[
				'label' => __( 'Select Icon', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => [
					'icon_type' => 'icon',
				],
			]
		);
		$this->add_control(
			'type_image',
			[
				'label' => __( 'Choose Image', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'icon_type' => 'image',
				],
			]
		);
		
		$this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'none',
                'exclude' => [
                    'full',
                    'custom',
                    'large',
                    'shop_catalog',
                    'shop_single',
                    'shop_thumbnail'
                ],
                'condition' => [
                    'icon_type' => 'image'
                ]
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
			'text_section',
			[
				'label' => __( 'Title and description', 'magical-addons-for-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'magical-addons-for-elementor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'input_type'  => 'text',
				'placeholder' => __( 'Magical info box title', 'magical-addons-for-elementor' ),
				'default'     => __( 'Magical info box title', 'magical-addons-for-elementor' ),
				'label_block' =>true
			]
		);
		$this->add_control(
			'title_tag',
			[
				'label' => __( 'Title HTML Tag', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h2',
			]
		);
		$this->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'magical-addons-for-elementor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'input_type'  => 'text',
				'placeholder' => __( 'Magical info box description goes here.', 'magical-addons-for-elementor' ),
				'default'     => __( 'Magical info box description goes here.', 'magical-addons-for-elementor' ),
			]
		);
		
		$this->add_responsive_control(
			'title_align',
			[
				'label' => __( 'Alignment', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'magical-addons-for-elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'magical-addons-for-elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'magical-addons-for-elementor' ),
						'icon' => 'eicon-text-align-right',
					],
					
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
        $this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button', 'magical-addons-for-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'use_btn',
			[
				'label' => __( 'Use button', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'magical-addons-for-elementor' ),
				'label_off' => __( 'No', 'magical-addons-for-elementor' ),
				'default' => 'no',
			]
		);
		$this->add_control(
			'btntitle',
			[
				'label'       => __( 'Button Title', 'magical-addons-for-elementor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'input_type'  => 'text',
				'placeholder' => __( 'Button Text', 'magical-addons-for-elementor' ),
				'default'     => __( 'Button Text', 'magical-addons-for-elementor' ),
			]
		);
		$this->add_control(
			'btn_link',
			[
				'label' => __( 'Button Link', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'magical-addons-for-elementor' ),
				'default' => [
					'url' => '#',
				],
				'separator' => 'before',
			]
		);
		$this->add_control(
			'usebtn_icon',
			[
				'label' => __( 'Use icon', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'magical-addons-for-elementor' ),
				'label_off' => __( 'No', 'magical-addons-for-elementor' ),
				'default' => 'no',
			]
		);
		$this->add_control(
			'btnicon',
			[
				'label' => __( 'Choose Icon', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-chevron-right',
					'library' => 'solid',
				],
				'condition' => [
					'usebtn_icon' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
			'icon_position',
			[
				'label' => __( 'Button Icon Position', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'magical-addons-for-elementor' ),
						'icon' => 'fas fa-arrow-left',
					],
					'right' => [
						'title' => __( 'Right', 'magical-addons-for-elementor' ),
						'icon' => 'fas fa-arrow-right',
					],
					
				],
				'default' => 'right',
				'condition' => [
					'usebtn_icon' => 'yes',
				],
				
			]
		);
		$this->add_control(
			'iconspace',
			[
				'label' => __( 'Icon Spacing', 'magical-addons-for-elementor' ),
				'type' => Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'condition' => [
					'usebtn_icon' => 'yes',
				],
				'selectors' => [
                    '{{WRAPPER}} .mg-infobox .mg-btn i.left' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .mg-infobox .mg-btn i.right' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Blank widget style ontrols.
	 *
	 * Adds different input fields in the style tab to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_style_controls() {

		
		$this->start_controls_section(
			'icon_style',
			[
				'label' => __( 'Icon Or Image', 'magical-addons-for-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'use_icon' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
            'icon_size',
            [
                'label' => __( 'Icon Size', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 300,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                     'icon_type' => 'icon'
                ]
            ]
        );
        $this->add_responsive_control(
            'image_width',
            [
                'label' => __( 'Image Width', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 400,
                    ],
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-img img' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'icon_type' => 'image'
                ]
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => __( 'Image Height', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-img img' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'icon_type' => 'image'
                ]
            ]
        );
        $this->add_responsive_control(
            'icon_spacing',
            [
                'label' => __( 'Bottom Spacing', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-icon' => 'margin-bottom: {{SIZE}}{{UNIT}} !important;',
                    '{{WRAPPER}} .mg-infobox-img img' => 'margin-bottom: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_padding',
            [
                'label' => __( 'Padding', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-icon i, {{WRAPPER}} .mg-infobox-img img' => 'padding: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );
        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => __( 'Margin', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-img img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .mg-infobox-icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
         $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'icon_border',
                'selector' => '{{WRAPPER}} .mg-infobox-img img, {{WRAPPER}} .mg-infobox-icon i'
                
            ]
        );

        $this->add_responsive_control(
            'icon_border_radius',
            [
                'label' => __( 'Border Radius', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .mg-infobox-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'info_block_shadow',
                'exclude' => [
                    'box_shadow_position',
                ],
                'selector' => '{{WRAPPER}} .mg-infobox-img img, {{WRAPPER}} .mg-infobox-icon i'
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-icon i' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'icon_type' => 'icon'
                ]
            ]
        );

        $this->add_control(
            'icon_bg_color',
            [
                'label' => __( 'Background Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-img img, {{WRAPPER}} .mg-infobox-icon i' => 'background-color: {{VALUE}};',
                ],
                
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'content_style',
			[
				'label' => __( 'Title and description', 'magical-addons-for-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content padding', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __( 'Typography', 'magical-addons-for-elementor' ),
                'selector' => '{{WRAPPER}} .mg-infobox-title',
                'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_2
            ]
        );

        $this->add_control(
            'description_heading',
            [
                'type' => \Elementor\Controls_Manager::HEADING,
                'label' => __( 'Description', 'magical-addons-for-elementor' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-desc' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
         $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mg-infobox-desc p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'label' => __( 'Typography', 'magical-addons-for-elementor' ),
                'selector' => '{{WRAPPER}} .mg-infobox-desc p',
                'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
            'btn_style_section',
            [
                'label' => __( 'Button', 'magical-addons-for-elementor' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'btn_padding',
            [
                'label' => __( 'Padding', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .mg-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'btn_typography',
                'selector' => '{{WRAPPER}} .mg-btn',
                'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_4,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'btn_border',
                'selector' => '{{WRAPPER}} .mg-btn',
            ]
        );

        $this->add_control(
            'btn_border_radius',
            [
                'label' => __( 'Border Radius', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .mg-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'btn_box_shadow',
                'selector' => '{{WRAPPER}} .mg-btn',
            ]
        );
        $this->add_control(
			'button_color',
			[
				'label' => __( 'Button color', 'magical-addons-for-elementor' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs( 'infobox_btn_tabs' );

        $this->start_controls_tab(
            'btn_normal_style',
            [
                'label' => __( 'Normal', 'magical-addons-for-elementor' ),
            ]
        );

        $this->add_control(
            'btn_color',
            [
                'label' => __( 'Text Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .mg-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color',
            [
                'label' => __( 'Background Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mg-btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        

        $this->end_controls_tab();

        $this->start_controls_tab(
            'btn_hover_style',
            [
                'label' => __( 'Hover', 'magical-addons-for-elementor' ),
            ]
        );

        $this->add_control(
            'btn_hcolor',
            [
                'label' => __( 'Text Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mg-btn:hover, {{WRAPPER}} .mg-btn:focus' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_hbg_color',
            [
                'label' => __( 'Background Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mg-btn:hover, {{WRAPPER}} .mg-btn:focus' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_hborder_color',
            [
                'label' => __( 'Border Color', 'magical-addons-for-elementor' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'btn_border_border!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .mg-btn:hover, {{WRAPPER}} .mg-btn:focus' => 'border-color: {{VALUE}};',
                ],
            ]
        );


        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();

	}

	/**
	 * Render Blank widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings   = $this->get_settings_for_display(); 
		$use_icon = $this->get_settings( 'use_icon' );
		$icon_type = $this->get_settings( 'icon_type' );
		$type_icon = $this->get_settings( 'type_icon' );
		/*$type_image = $this->get_settings( 'type_image' );
		$thumbnail = $this->get_settings( 'thumbnail' );*/
		$title = $this->get_settings( 'title' );
		$title_tag = $this->get_settings( 'title_tag' );
		$desc = $this->get_settings( 'desc' );
		$title_align = $this->get_settings( 'title_align' );
		$use_btn = $this->get_settings( 'use_btn' );
		$btntitle = $this->get_settings( 'btntitle' );
		$btn_link = $this->get_settings( 'btn_link' );
		$usebtn_icon = $this->get_settings( 'usebtn_icon' );
		$btnicon = $this->get_settings( 'btnicon' );
		$icon_position = $this->get_settings( 'icon_position' );
		$iconspace = $this->get_settings( 'iconspace' );
		$main_icon_position = $this->get_settings( 'main_icon_position' );
		

		$this->add_inline_editing_attributes( 'title', 'basic' );
        $this->add_render_attribute( 'title', 'class', 'mg-infobox-title' );

        $this->add_inline_editing_attributes( 'desc', 'intermediate' );
        $this->add_render_attribute( 'desc', 'class', 'mg-infobox-desc' );

        $this->add_inline_editing_attributes( 'btntitle', 'none' );
        $this->add_render_attribute( 'btntitle', 'class', 'mg-btn-text' );

        $this->add_render_attribute( 'btntitle', 'class', 'mg-btn' );
        $this->add_render_attribute( 'btntitle', 'href', esc_url( $btn_link['url'] ) );
        if ( ! empty( $btn_link['is_external'] ) ) {
            $this->add_render_attribute( 'btntitle', 'target', '_blank' );
        }
        if ( ! empty( $btn_link['nofollow'] ) ) {
            $this->set_render_attribute( 'btntitle', 'rel', 'nofollow' );
        }
?>
		<div class="mg-infobox">
			<?php if($main_icon_position == 'left'): ?>
			<div class="mgicon-area <?php if($base_style_select == 'style2'): ?>text-right<?php endif; ?>">
			<?php endif; ?>
			<?php if( $use_icon == 'yes' && $main_icon_position != 'right' ): ?>
				<?php if($icon_type == 'image'): ?>
				<figure class="mg-infobox-img">
	                <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'type_image' ); ?>
	            </figure>
	            <?php else: ?>
		            <div class="mg-infobox-icon">
		            	<i class="<?php echo esc_attr($type_icon['value']); ?>" aria-hidden="true"></i>
		            </div>
	            <?php endif; ?>
            <?php endif; ?>
            <?php if($main_icon_position == 'left'): ?>
			</div>
			<?php endif; ?>
			<?php if($main_icon_position != 'top'): ?>
			<div class="mgtext-area">
			<?php endif; ?>
			<div class="mg-infobox-text">
            <?php
            if ( $title ) :
                printf( '<%1$s %2$s>%3$s</%1$s>',
                    tag_escape( $title_tag ),
                    $this->get_render_attribute_string( 'title' ),
                    esc_html($title) );
            endif;
            ?>
            <?php if ( $desc ) : ?>
                <div <?php $this->print_render_attribute_string( 'desc' ); ?>>
                    <p><?php echo wp_kses_post( $desc ); ?></p>
                </div>
            <?php endif; ?>
            <?php if ( $use_btn ) : ?>
            	<?php if( $usebtn_icon == 'yes' ): ?>
                <a <?php echo $this->get_render_attribute_string( 'btntitle' ); ?>>
                	<?php if($icon_position=='left'): ?><i class="left <?php echo esc_attr($btnicon['value']); ?>" aria-hidden="true"></i> <?php endif; ?>
                	<span><?php echo esc_html($btntitle); ?></span>
					<?php if($icon_position=='right'): ?><i class="right <?php echo esc_attr($btnicon['value']); ?>" aria-hidden="true"></i> <?php endif; ?>
                </a>
                <?php else: ?>
                <a <?php echo $this->get_render_attribute_string( 'btntitle' ); ?>><?php echo  esc_html($btntitle); ?></a>
          		<?php endif; ?>
            <?php endif; ?>
        	</div>
        	<?php if($main_icon_position != 'top'): ?>
			</div>
			<?php endif; ?>
			<?php if( $use_icon == 'yes' && $main_icon_position == 'right' ): ?>
			<div class="mgicon-area">
			
				<?php if($icon_type == 'image'): ?>
				<figure class="mg-infobox-img">
	                <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'type_image' ); ?>
	            </figure>
	            <?php else: ?>
		            <div class="mg-infobox-icon">
		            	<i class="<?php echo esc_attr($type_icon['value']); ?>" aria-hidden="true"></i>
		            </div>
	            <?php endif; ?>
			</div>
			<?php endif; ?>

        </div>
<?php
}

	/**
	 * Render Blank widget output on the frontend.
	 *
	 * Written in JS and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {

		

	
	}

}