<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	/* Copyright (C) 2019 AnalogWP
	   This file is distributed under the same license as the Style Kits for Elementor plugin. */

	// Reference: src/js/app/Header.js:108
	// Reference: src/js/app/popup.js:134
	// Reference: languages/ang-translations.php:11
	__( 'Close', 'ang' ),

	// Reference: src/js/app/Header.js:93
	// Reference: languages/ang-translations.php:15
	__( 'Templates library refreshed', 'ang' ),

	// Reference: src/js/app/Header.js:94
	// Reference: languages/ang-translations.php:19
	__( 'Error refreshing templates library, please try again.', 'ang' ),

	// Reference: src/js/app/Header.js:98
	// Reference: languages/ang-translations.php:23
	__( 'Syncing...', 'ang' ),

	// Reference: src/js/app/Header.js:99
	// Reference: languages/ang-translations.php:27
	__( 'Sync Library', 'ang' ),

	// Reference: src/js/app/Nav.js:66
	// Reference: inc/register-settings.php:29
	// Reference: languages/ang-translations.php:32
	__( 'Templates', 'ang' ),

	// Reference: src/js/app/Nav.js:67
	// Reference: inc/elementor/class-ang-action.php:117
	// Reference: inc/elementor/class-finder-shortcuts.php:48
	// Reference: inc/elementor/class-post-type.php:32
	// Reference: inc/elementor/class-post-type.php:41
	// Reference: inc/elementor/class-typography.php:633
	// Reference: inc/register-settings.php:18
	// Reference: inc/register-settings.php:36
	// Reference: inc/register-settings.php:55
	// Reference: languages/ang-translations.php:44
	__( 'Style Kits', 'ang' ),

	// Reference: src/js/app/ProModal.js:37
	// Reference: languages/ang-translations.php:48
	__( 'Template Kits are', 'ang' ),

	// Reference: src/js/app/ProModal.js:37
	// Reference: languages/ang-translations.php:52
	__( 'coming soon with Style Kits Pro.', 'ang' ),

	// Reference: src/js/app/ProModal.js:37
	// Reference: languages/ang-translations.php:56
	__( 'Sign up for an exclusive launch discount.', 'ang' ),

	// Reference: src/js/app/ProModal.js:39
	// Reference: languages/ang-translations.php:60
	__( 'Learn More', 'ang' ),

	// Reference: src/js/app/Template.js:13
	// Reference: languages/ang-translations.php:64
	__( 'New', 'ang' ),

	// Reference: src/js/app/Template.js:20
	// Reference: languages/ang-translations.php:68
	__( 'Preview', 'ang' ),

	// Reference: src/js/app/Template.js:24
	// Reference: src/js/app/stylekits/stylekits.js:233
	// Reference: languages/ang-translations.php:73
	__( 'Import', 'ang' ),

	// Reference: src/js/app/Template.js:51
	// Reference: languages/ang-translations.php:77
	__( 'Pro', 'ang' ),

	// Reference: src/js/app/Templates.js:318
	// Reference: languages/ang-translations.php:81
	__( 'This template requires an updated version, please update your plugin to latest version.', 'ang' ),

	// Reference: src/js/app/collection/Collection.js:152
	// Reference: languages/ang-translations.php:85
	__( 'View Templates', 'ang' ),

	// Reference: src/js/app/filters.js:149
	// Reference: languages/ang-translations.php:89
	__( 'Show All', 'ang' ),

	// Reference: src/js/app/filters.js:154
	// Reference: languages/ang-translations.php:93
	__( 'Latest', 'ang' ),

	// Reference: src/js/app/filters.js:155
	// Reference: languages/ang-translations.php:97
	__( 'Popular', 'ang' ),

	// Reference: src/js/app/filters.js:174
	// Reference: languages/ang-translations.php:101
	__( 'Back to Kits', 'ang' ),

	// Reference: src/js/app/filters.js:176
	// Reference: languages/ang-translations.php:105
	__( 'Template Kit', 'ang' ),

	// Reference: src/js/app/filters.js:189
	// Reference: languages/ang-translations.php:109
	__( 'Back to all', 'ang' ),

	// Reference: src/js/app/filters.js:190
	// Reference: languages/ang-translations.php:113
	__( 'My Favorites', 'ang' ),

	// Reference: src/js/app/filters.js:196
	// Reference: languages/ang-translations.php:117
	__( 'Show Pro Templates', 'ang' ),

	// Reference: src/js/app/filters.js:208
	// Reference: languages/ang-translations.php:121
	__( 'Group by Template Kit', 'ang' ),

	// Reference: src/js/app/filters.js:222
	// Reference: languages/ang-translations.php:125
	__( 'Filter', 'ang' ),

	// Reference: src/js/app/filters.js:234
	// Reference: languages/ang-translations.php:129
	__( 'Sort by', 'ang' ),

	// Reference: src/js/app/filters.js:247
	// Reference: languages/ang-translations.php:133
	__( 'Search templates', 'ang' ),

	// Reference: src/js/app/modal.js:106
	// Reference: languages/ang-translations.php:137
	__( 'Insert Layout', 'ang' ),

	// Reference: src/js/app/modal.js:96
	// Reference: languages/ang-translations.php:141
	__( 'Back to Library', 'ang' ),

	// Reference: src/js/app/modal.js:99
	// Reference: languages/ang-translations.php:145
	__( 'Open Preview in New Tab', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:101
	// Reference: languages/ang-translations.php:149
	__( 'Default', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:105
	// Reference: languages/ang-translations.php:153
	__( 'Installed', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:119
	// Reference: languages/ang-translations.php:157
	__( 'Learn more about this in %s.', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:122
	// Reference: languages/ang-translations.php:161
	__( 'Style Kits Docs', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:140
	// Reference: languages/ang-translations.php:165
	__( 'Choose a Style Kit...', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:157
	// Reference: languages/ang-translations.php:169
	__( 'Next', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:173
	// Reference: languages/ang-translations.php:173
	__( 'Change Style Kit', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:177
	// Reference: languages/ang-translations.php:177
	__( 'Import this template to your library to make it available in your Elementor ', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:178
	// Reference: languages/ang-translations.php:181
	__( 'Saved Templates', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:179
	// Reference: languages/ang-translations.php:185
	__( ' list for future use.', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:192
	// Reference: languages/ang-translations.php:189
	__( 'Import to Library', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:200
	// Reference: languages/ang-translations.php:193
	__( 'Create a new page from this template to make it available as a draft page in your Pages list.', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:204
	// Reference: languages/ang-translations.php:197
	__( 'Enter a Page Name', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:223
	// Reference: languages/ang-translations.php:201
	__( 'Import to page', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:235
	// Reference: languages/ang-translations.php:205
	__( 'All done! The template has been imported.', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:240
	// Reference: languages/ang-translations.php:209
	__( 'Edit Template', 'ang' ),

	// Reference: src/js/app/popups/ImportTemplate.js:80
	// Reference: languages/ang-translations.php:213
	__( 'Select a Style Kit to apply on this layout', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:169
	// Reference: languages/ang-translations.php:217
	__( 'These are some Style Kit presets that you can use as a starting point. Once you import a Style Kit, it will be added to your', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:169
	// Reference: languages/ang-translations.php:221
	__( 'Style Kits list', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:170
	// Reference: languages/ang-translations.php:225
	__( 'You will then be able to apply on any page.', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:171
	// Reference: inc/elementor/class-ang-action.php:114
	// Reference: languages/ang-translations.php:232
	/* translators: translators: %s: Link text
translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text translators: translators: %s: Link text */
	__( 'Learn more', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:202
	// Reference: languages/ang-translations.php:236
	__( 'A Style Kit already exists with the same name. To import it again please enter a new name below:', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:206
	// Reference: languages/ang-translations.php:240
	__( 'Please try a different as a Style Kit with same name already exists.', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:210
	// Reference: languages/ang-translations.php:244
	__( 'Enter a Style Kit Name', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:245
	// Reference: languages/ang-translations.php:247
	__( 'The Style Kit has been imported and is now available in the list of the available Style Kits.', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:259
	// Reference: languages/ang-translations.php:250
	__( 'Ok, thanks', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:267
	// Reference: languages/ang-translations.php:254
	__( 'Importing ', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:90
	// Reference: languages/ang-translations.php:257
	__( '%s in WordPress dashboard.', 'ang' ),

	// Reference: src/js/app/stylekits/stylekits.js:93
	// Reference: languages/ang-translations.php:260
	__( 'Manage your Style Kits', 'ang' ),

	// Reference: inc/register-settings.php:17
	// Reference: languages/ang-translations.php:266
	/* translators: Plugin Name of the plugin
translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin translators: Plugin Name of the plugin */
	__( 'Style Kits for Elementor', 'ang' ),

	// Reference: languages/ang-translations.php:272
	/* translators: Plugin URI of the plugin
Author URI of the plugin
translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin translators: Plugin URI of the plugin Author URI of the plugin */
	__( 'https://analogwp.com/', 'ang' ),

	// Reference: languages/ang-translations.php:277
	/* translators: Description of the plugin
translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin translators: Description of the plugin */
	__( 'Style Kits adds intuitive styling controls in the Elementor editor that power-up your design workflow.', 'ang' ),

	// Reference: languages/ang-translations.php:282
	/* translators: Author of the plugin
translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin translators: Author of the plugin */
	__( 'AnalogWP', 'ang' ),

	// Reference: analogwp-templates.php:71
	// Reference: analogwp-templates.php:81
	// Reference: languages/ang-translations.php:287
	__( 'Cheatin&#8217; huh?', 'ang' ),

	// Reference: analogwp-templates.php:278
	// Reference: inc/elementor/class-finder-shortcuts.php:42
	// Reference: inc/register-settings.php:45
	// Reference: languages/ang-translations.php:293
	__( 'Settings', 'ang' ),

	// Reference: analogwp-templates.php:322
	// Reference: languages/ang-translations.php:297
	__( 'Analog Templates is not working because you need to activate the Elementor plugin.', 'ang' ),

	// Reference: analogwp-templates.php:323
	// Reference: languages/ang-translations.php:301
	__( 'Activate Elementor Now', 'ang' ),

	// Reference: analogwp-templates.php:330
	// Reference: languages/ang-translations.php:305
	__( 'Analog Templates is not working because you need to install the Elementor plugin.', 'ang' ),

	// Reference: analogwp-templates.php:331
	// Reference: languages/ang-translations.php:309
	__( 'Install Elementor Now', 'ang' ),

	// Reference: analogwp-templates.php:345
	// Reference: languages/ang-translations.php:315
	/* translators: translators: %s: WordPress version
translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version translators: translators: %s: WordPress version */
	__( 'Analog Templates requires WordPress version %s+. Because you are using an earlier version, the plugin is currently NOT RUNNING.', 'ang' ),

	// Reference: inc/api/class-local.php:361
	// Reference: languages/ang-translations.php:319
	__( 'Setting updated.', 'ang' ),

	// Reference: inc/api/class-local.php:449
	// Reference: languages/ang-translations.php:323
	__( 'Unable to create a post', 'ang' ),

	// Reference: inc/api/class-local.php:454
	// Reference: languages/ang-translations.php:327
	__( 'Token saved.', 'ang' ),

	// Reference: inc/api/class-local.php:472
	// Reference: inc/api/class-local.php:502
	// Reference: languages/ang-translations.php:332
	__( 'Please provide a valid post ID.', 'ang' ),

	// Reference: inc/api/class-local.php:476
	// Reference: languages/ang-translations.php:336
	__( 'Invalid Post ID', 'ang' ),

	// Reference: inc/api/class-local.php:547
	// Reference: languages/ang-translations.php:340
	__( 'Invalid Style Kit ID.', 'ang' ),

	// Reference: inc/api/class-local.php:567
	// Reference: languages/ang-translations.php:344
	__( 'Error occured while requesting Style Kit data.', 'ang' ),

	// Reference: inc/api/class-local.php:597
	// Reference: languages/ang-translations.php:348
	__( 'Style Kit imported', 'ang' ),

	// Reference: inc/api/class-local.php:633
	// Reference: languages/ang-translations.php:352
	__( 'Invalid token data returned', 'ang' ),

	// Reference: inc/class-admin-settings.php:74
	// Reference: languages/ang-translations.php:356
	__( 'Your settings have been saved.', 'ang' ),

	// Reference: inc/class-admin-settings.php:132
	// Reference: languages/ang-translations.php:360
	__( 'The changes you made will be lost if you navigate away from this page.', 'ang' ),

	// Reference: inc/class-admin-settings.php:495
	// Reference: inc/class-admin-settings.php:559
	// Reference: languages/ang-translations.php:365
	__( 'Toggle', 'ang' ),

	// Reference: inc/class-base.php:41
	// Reference: inc/class-base.php:51
	// Reference: languages/ang-translations.php:370
	__( 'Something went wrong.', 'ang' ),

	// Reference: inc/class-cron.php:41
	// Reference: languages/ang-translations.php:374
	__( 'Once Weekly', 'ang' ),

	// Reference: inc/class-elementor.php:42
	// Reference: languages/ang-translations.php:378
	__( 'AnalogWP Classes', 'ang' ),

	// Reference: inc/class-licensemanager.php:62
	// Reference: languages/ang-translations.php:382
	__( 'Theme License', 'ang' ),

	// Reference: inc/class-licensemanager.php:63
	// Reference: languages/ang-translations.php:386
	__( 'Enter your theme license key received upon purchase from <a target="_blank" href="https://analogwp.com/account/">AnalogWP</a>.', 'ang' ),

	// Reference: inc/class-licensemanager.php:67
	// Reference: languages/ang-translations.php:390
	__( 'License Key', 'ang' ),

	// Reference: inc/class-licensemanager.php:68
	// Reference: inc/settings/class-settings-license.php:59
	// Reference: inc/settings/class-settings-license.php:67
	// Reference: languages/ang-translations.php:396
	__( 'License Action', 'ang' ),

	// Reference: inc/class-licensemanager.php:69
	// Reference: languages/ang-translations.php:400
	__( 'Deactivate License', 'ang' ),

	// Reference: inc/class-licensemanager.php:70
	// Reference: languages/ang-translations.php:404
	__( 'Activate License', 'ang' ),

	// Reference: inc/class-licensemanager.php:71
	// Reference: inc/class-licensemanager.php:90
	// Reference: languages/ang-translations.php:409
	__( 'License status is unknown.', 'ang' ),

	// Reference: inc/class-licensemanager.php:72
	// Reference: languages/ang-translations.php:413
	__( 'Renew?', 'ang' ),

	// Reference: inc/class-licensemanager.php:73
	// Reference: languages/ang-translations.php:417
	__( 'unlimited', 'ang' ),

	// Reference: inc/class-licensemanager.php:74
	// Reference: languages/ang-translations.php:421
	__( 'License key is active.', 'ang' ),

	// Reference: inc/class-licensemanager.php:76
	// Reference: languages/ang-translations.php:427
	/* translators: translators: %s: expiration date
translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date */
	__( 'Expires %s.', 'ang' ),

	// Reference: inc/class-licensemanager.php:77
	// Reference: languages/ang-translations.php:431
	__( 'Lifetime License.', 'ang' ),

	// Reference: inc/class-licensemanager.php:79
	// Reference: languages/ang-translations.php:437
	/* translators: translators: %1$s: active sites, %2$s: sites limit
translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit translators: translators: %1$s: active sites, %2$s: sites limit */
	__( 'You have %1$s / %2$s sites activated.', 'ang' ),

	// Reference: inc/class-licensemanager.php:81
	// Reference: languages/ang-translations.php:443
	/* translators: translators: %s: product name
translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name translators: translators: %s: product name */
	__( 'License key expired %s.', 'ang' ),

	// Reference: inc/class-licensemanager.php:82
	// Reference: languages/ang-translations.php:447
	__( 'License key has expired.', 'ang' ),

	// Reference: inc/class-licensemanager.php:83
	// Reference: languages/ang-translations.php:451
	__( 'License keys do not match. <br> Enter your theme license key received upon purchase from <a target="_blank" href="https://analogwp.com/account/">AnalogWP</a>.', 'ang' ),

	// Reference: inc/class-licensemanager.php:87
	// Reference: languages/ang-translations.php:455
	__( 'License is inactive.', 'ang' ),

	// Reference: inc/class-licensemanager.php:88
	// Reference: languages/ang-translations.php:459
	__( 'License key is disabled.', 'ang' ),

	// Reference: inc/class-licensemanager.php:89
	// Reference: languages/ang-translations.php:463
	__( 'Site is inactive.', 'ang' ),

	// Reference: inc/class-licensemanager.php:91
	// Reference: languages/ang-translations.php:467
	__( 'Updating this theme will lose any customizations you have made. \'Cancel\' to stop, \'OK\' to update.', 'ang' ),

	// Reference: inc/class-licensemanager.php:92
	// Reference: languages/ang-translations.php:471
	__( '<strong>%1$s %2$s</strong> is available. <a href="%3$s" class="thickbox" title="%4$s">Check out what\'s new</a> or <a href="%5$s" %6$s>update now</a>.', 'ang' ),

	// Reference: inc/class-licensemanager.php:356
	// Reference: inc/class-licensemanager.php:394
	// Reference: inc/class-licensemanager.php:453
	// Reference: languages/ang-translations.php:477
	__( 'An error occurred, please try again.', 'ang' ),

	// Reference: inc/class-licensemanager.php:366
	// Reference: languages/ang-translations.php:483
	/* translators: translators: %s: expiration date
translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date translators: translators: %s: expiration date */
	__( 'Your license key expired on %s.', 'ang' ),

	// Reference: inc/class-licensemanager.php:372
	// Reference: languages/ang-translations.php:487
	__( 'Your license key has been disabled.', 'ang' ),

	// Reference: inc/class-licensemanager.php:376
	// Reference: languages/ang-translations.php:491
	__( 'Invalid license.', 'ang' ),

	// Reference: inc/class-licensemanager.php:381
	// Reference: languages/ang-translations.php:495
	__( 'Your license is not active for this URL.', 'ang' ),

	// Reference: inc/class-licensemanager.php:386
	// Reference: languages/ang-translations.php:501
	/* translators: translators: %s: site name/email
translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email translators: translators: %s: site name/email */
	__( 'This appears to be an invalid license key for %s.', 'ang' ),

	// Reference: inc/class-licensemanager.php:390
	// Reference: languages/ang-translations.php:505
	__( 'Your license key has reached its activation limit.', 'ang' ),

	// Reference: inc/class-quick-edit.php:62
	// Reference: inc/class-quick-edit.php:133
	// Reference: inc/elementor/class-post-type.php:33
	// Reference: languages/ang-translations.php:511
	__( 'Style Kit', 'ang' ),

	// Reference: inc/class-utils.php:98
	// Reference: languages/ang-translations.php:517
	/* translators: translators: Global Style Kit post title.
translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. translators: translators: Global Style Kit post title. */
	__( 'Global: %s', 'ang' ),

	// Reference: inc/elementor/class-analog-settings.php:33
	// Reference: languages/ang-translations.php:521
	__( 'Global Stylekit Settings Saved. It\'s recommended to close any open elementor tabs in your browser, and re-open them, for the effect to apply.', 'ang' ),

	// Reference: inc/elementor/class-analog-settings.php:49
	// Reference: inc/elementor/class-ang-action.php:104
	// Reference: languages/ang-translations.php:526
	__( '— Select a Style Kit —', 'ang' ),

	// Reference: inc/elementor/class-analog-settings.php:56
	// Reference: languages/ang-translations.php:530
	__( 'Style Kits for Elementor Settings', 'ang' ),

	// Reference: inc/elementor/class-analog-settings.php:60
	// Reference: languages/ang-translations.php:534
	__( 'Global Style Kit', 'ang' ),

	// Reference: inc/elementor/class-analog-settings.php:66
	// Reference: languages/ang-translations.php:540
	/* translators: translators: %s: Style Kit Documentation link
translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link translators: translators: %s: Style Kit Documentation link */
	__( 'Choosing a Style Kit will make it global and apply site-wide. Learn more about <a href="%s" target="_blank">Style kits</a>.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:96
	// Reference: languages/ang-translations.php:544
	__( 'This will reset all the settings you configured previously under Page Style Settings from Analog Templates.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:97
	// Reference: languages/ang-translations.php:548
	__( 'Are you sure?', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:98
	// Reference: languages/ang-translations.php:552
	__( 'Save Style Kit as', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:99
	// Reference: languages/ang-translations.php:556
	__( 'Save', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:100
	// Reference: languages/ang-translations.php:560
	__( 'Cancel', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:101
	// Reference: languages/ang-translations.php:564
	__( 'Enter a title', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:102
	// Reference: languages/ang-translations.php:568
	__( 'Insert Style Kit', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:103
	// Reference: inc/elementor/class-ang-action.php:106
	// Reference: languages/ang-translations.php:573
	__( 'Please select a Style Kit first.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:105
	// Reference: languages/ang-translations.php:577
	__( 'Style Kit Updated.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:107
	// Reference: inc/elementor/class-typography.php:673
	// Reference: languages/ang-translations.php:582
	__( 'Update Style Kit', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:108
	// Reference: languages/ang-translations.php:586
	__( 'This action will update the Style Kit with the latest changes, and will affect all the pages that the style kit is used on. Do you wish to proceed?', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:109
	// Reference: languages/ang-translations.php:590
	__( 'Meet Style Kits by Style Kits for Elementor', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:112
	// Reference: languages/ang-translations.php:596
	/* translators: translators: %s: Link to Style Kits documentation.
translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. translators: translators: %s: Link to Style Kits documentation. */
	__( 'Take control of your design in the macro level, with local or global settings for typography and spacing. %s.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:116
	// Reference: languages/ang-translations.php:600
	__( 'View Styles', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:118
	// Reference: inc/elementor/class-typography.php:745
	// Reference: languages/ang-translations.php:605
	__( 'Export CSS', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:119
	// Reference: languages/ang-translations.php:609
	__( 'Copy CSS', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:120
	// Reference: languages/ang-translations.php:613
	__( 'Style Kit Update Detected', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:121
	// Reference: languages/ang-translations.php:617
	__( '<p>The Style kit used by this page has been updated, click ‘Apply Changes’ to apply the latest changes.</p><p>Click Discard to keep your current page styles and detach the page from the Style Kit</p>', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:122
	// Reference: languages/ang-translations.php:621
	__( 'Discard', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:123
	// Reference: languages/ang-translations.php:625
	__( 'Apply Changes', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:124
	// Reference: languages/ang-translations.php:629
	__( 'Ok, got it.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:125
	// Reference: languages/ang-translations.php:633
	__( 'Go to Page Style', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:126
	// Reference: languages/ang-translations.php:637
	__( 'This template offers global typography and spacing control, through the Page Style tab.', 'ang' ),

	// Reference: inc/elementor/class-ang-action.php:128
	// Reference: languages/ang-translations.php:641
	__( 'Typography, column gaps and more, are controlled layout-wide at Page Styles Panel, giving you the flexibility you need over the design of this template. You can save the styles and apply them to any other page. <a href="#" target="_blank">Learn More.</a>', 'ang' ),

	// Reference: inc/elementor/class-colors.php:154
	// Reference: languages/ang-translations.php:647
	/* translators: translators: %1$s: Link to documentation, %2$s: Link text.
translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. */
	__( 'Set the colors for Typography, accents and more.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:154
	// Reference: inc/elementor/class-typography.php:242
	// Reference: inc/elementor/class-typography.php:302
	// Reference: inc/elementor/class-typography.php:363
	// Reference: inc/elementor/class-typography.php:423
	// Reference: inc/elementor/class-typography.php:485
	// Reference: languages/ang-translations.php:658
	/* translators: translators: %1$s: Link to documentation, %2$s: Link text.
translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. translators: translators: %1$s: Link to documentation, %2$s: Link text. */
	__( 'Learn more.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:209
	// Reference: languages/ang-translations.php:662
	__( 'Primary Accent', 'ang' ),

	// Reference: inc/elementor/class-colors.php:211
	// Reference: languages/ang-translations.php:666
	__( 'The primary accent color applies on Links.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:220
	// Reference: languages/ang-translations.php:670
	__( 'Secondary Accent', 'ang' ),

	// Reference: inc/elementor/class-colors.php:222
	// Reference: languages/ang-translations.php:674
	__( 'The default Button color. You can also set button colors in the Buttons tab.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:245
	// Reference: languages/ang-translations.php:678
	__( 'Text and Headings Color', 'ang' ),

	// Reference: inc/elementor/class-colors.php:247
	// Reference: languages/ang-translations.php:682
	__( 'Applies on the text and headings in the layout.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:261
	// Reference: inc/elementor/tags/class-light-background.php:13
	// Reference: languages/ang-translations.php:687
	__( 'Light Background', 'ang' ),

	// Reference: inc/elementor/class-colors.php:263
	// Reference: languages/ang-translations.php:691
	__( 'Apply this color to sections or columns, using the <code>sk-light-bg</code>. The text inside will inherit the Text and titles color.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:283
	// Reference: inc/elementor/tags/class-dark-background.php:13
	// Reference: languages/ang-translations.php:696
	__( 'Dark Background', 'ang' ),

	// Reference: inc/elementor/class-colors.php:285
	// Reference: languages/ang-translations.php:700
	__( 'Apply this color to sections or columns, using the <code>sk-dark-bg</code>. The text inside will inherit the <em>Text over Dark Background</em> color that can be set below.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:311
	// Reference: languages/ang-translations.php:704
	__( 'Text over dark background', 'ang' ),

	// Reference: inc/elementor/class-colors.php:313
	// Reference: languages/ang-translations.php:708
	__( 'This color will apply on the text in a section or column with the Dark Background Color, as it has been set above.', 'ang' ),

	// Reference: inc/elementor/class-finder-shortcuts.php:23
	// Reference: languages/ang-translations.php:712
	__( 'Style Kits for Elementor Shortcuts', 'ang' ),

	// Reference: inc/elementor/class-finder-shortcuts.php:36
	// Reference: languages/ang-translations.php:716
	__( 'Templates Library', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:37
	// Reference: languages/ang-translations.php:720
	__( 'Add New Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:38
	// Reference: languages/ang-translations.php:724
	__( 'New Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:39
	// Reference: languages/ang-translations.php:728
	__( 'Edit Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:40
	// Reference: languages/ang-translations.php:732
	__( 'View Style Kit', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:42
	// Reference: languages/ang-translations.php:736
	__( 'Search Style Kits', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:43
	// Reference: languages/ang-translations.php:740
	__( 'Parent Style Kits:', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:44
	// Reference: languages/ang-translations.php:744
	__( 'No Style Kit found.', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:45
	// Reference: languages/ang-translations.php:748
	__( 'No Style Kit found in Trash.', 'ang' ),

	// Reference: inc/elementor/class-tools.php:178
	// Reference: languages/ang-translations.php:752
	__( 'Export Style Kit', 'ang' ),

	// Reference: inc/elementor/class-tools.php:199
	// Reference: languages/ang-translations.php:756
	__( 'Export', 'ang' ),

	// Reference: inc/elementor/class-tools.php:406
	// Reference: languages/ang-translations.php:760
	__( 'Import Style Kits', 'ang' ),

	// Reference: inc/elementor/class-tools.php:409
	// Reference: languages/ang-translations.php:764
	__( 'Choose an Analog template JSON file or a .zip archive of Analog Style Kits, and add them to the list of Style Kits available in your library.', 'ang' ),

	// Reference: inc/elementor/class-tools.php:420
	// Reference: languages/ang-translations.php:768
	__( 'Import Now', 'ang' ),

	// Reference: inc/elementor/class-tools.php:570
	// Reference: languages/ang-translations.php:772
	__( 'Error occurred, the version selected is invalid. Try selecting different version.', 'ang' ),

	// Reference: inc/elementor/class-tools.php:615
	// Reference: languages/ang-translations.php:776
	__( 'Rollback to Previous Version', 'ang' ),

	// Reference: inc/elementor/class-tools.php:645
	// Reference: languages/ang-translations.php:782
	/* translators: translators: %s: Style kit title.
translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. translators: translators: %s: Style kit title. */
	__( 'Style Kit: %s <span style="color:#5C32B6;">&#9679;</span>', 'ang' ),

	// Reference: inc/elementor/class-tools.php:669
	// Reference: languages/ang-translations.php:786
	__( 'Apply Global Style Kit', 'ang' ),

	// Reference: inc/elementor/class-tools.php:710
	// Reference: languages/ang-translations.php:790
	__( 'Invalid/empty Post ID.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:107
	// Reference: languages/ang-translations.php:794
	__( 'Headings Typography', 'ang' ),

	// Reference: inc/elementor/class-typography.php:115
	// Reference: languages/ang-translations.php:798
	__( 'These settings apply to all Headings in your layout. You can still override individual values at each element.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:130
	// Reference: languages/ang-translations.php:802
	__( 'Default Headings Font', 'ang' ),

	// Reference: inc/elementor/class-typography.php:145
	// Reference: languages/ang-translations.php:808
	/* translators: translators: %s: Heading 1-6 type
translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type translators: translators: %s: Heading 1-6 type */
	__( 'Heading %s', 'ang' ),

	// Reference: inc/elementor/class-typography.php:188
	// Reference: inc/elementor/class-typography.php:210
	// Reference: languages/ang-translations.php:813
	__( 'Body Typography', 'ang' ),

	// Reference: inc/elementor/class-typography.php:196
	// Reference: languages/ang-translations.php:817
	__( 'Recently Imported', 'ang' ),

	// Reference: inc/elementor/class-typography.php:234
	// Reference: languages/ang-translations.php:821
	__( 'Heading Sizes', 'ang' ),

	// Reference: inc/elementor/class-typography.php:242
	// Reference: languages/ang-translations.php:825
	__( 'Tweak the size of your Heading elements using these presets.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:249
	// Reference: inc/elementor/class-typography.php:309
	// Reference: languages/ang-translations.php:830
	__( 'XXL', 'ang' ),

	// Reference: inc/elementor/class-typography.php:250
	// Reference: inc/elementor/class-typography.php:310
	// Reference: inc/elementor/class-typography.php:496
	// Reference: languages/ang-translations.php:836
	__( 'XL', 'ang' ),

	// Reference: inc/elementor/class-typography.php:251
	// Reference: inc/elementor/class-typography.php:311
	// Reference: inc/elementor/class-typography.php:348
	// Reference: inc/elementor/class-typography.php:790
	// Reference: languages/ang-translations.php:843
	__( 'Large', 'ang' ),

	// Reference: inc/elementor/class-typography.php:252
	// Reference: inc/elementor/class-typography.php:312
	// Reference: inc/elementor/class-typography.php:347
	// Reference: inc/elementor/class-typography.php:789
	// Reference: languages/ang-translations.php:850
	__( 'Medium', 'ang' ),

	// Reference: inc/elementor/class-typography.php:253
	// Reference: inc/elementor/class-typography.php:313
	// Reference: inc/elementor/class-typography.php:346
	// Reference: inc/elementor/class-typography.php:788
	// Reference: languages/ang-translations.php:857
	__( 'Small', 'ang' ),

	// Reference: inc/elementor/class-typography.php:294
	// Reference: languages/ang-translations.php:861
	__( 'Text Sizes', 'ang' ),

	// Reference: inc/elementor/class-typography.php:302
	// Reference: languages/ang-translations.php:865
	__( 'Tweak the size of text elements using these presets.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:345
	// Reference: inc/elementor/class-typography.php:787
	// Reference: languages/ang-translations.php:870
	__( 'Normal', 'ang' ),

	// Reference: inc/elementor/class-typography.php:349
	// Reference: inc/elementor/class-typography.php:791
	// Reference: languages/ang-translations.php:875
	__( 'Extra Large', 'ang' ),

	// Reference: inc/elementor/class-typography.php:355
	// Reference: inc/elementor/class-typography.php:780
	// Reference: languages/ang-translations.php:880
	__( 'Outer Section Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:363
	// Reference: languages/ang-translations.php:884
	__( 'Add padding to the outer sections of your layouts by using these controls.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:405
	// Reference: languages/ang-translations.php:888
	__( 'Default Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:406
	// Reference: languages/ang-translations.php:892
	__( 'Narrow Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:407
	// Reference: languages/ang-translations.php:896
	__( 'Extended Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:408
	// Reference: languages/ang-translations.php:900
	__( 'Wide Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:409
	// Reference: languages/ang-translations.php:904
	__( 'Wider Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:415
	// Reference: languages/ang-translations.php:908
	__( 'Column Gaps', 'ang' ),

	// Reference: inc/elementor/class-typography.php:423
	// Reference: languages/ang-translations.php:912
	__( 'Column Gap presets add padding to the columns of a section.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:450
	// Reference: languages/ang-translations.php:916
	__( 'Space Between Widgets', 'ang' ),

	// Reference: inc/elementor/class-typography.php:451
	// Reference: languages/ang-translations.php:920
	__( 'Sets the default space between widgets, overrides the default value set in Elementor > Style > Space Between Widgets.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:477
	// Reference: languages/ang-translations.php:924
	__( 'Buttons', 'ang' ),

	// Reference: inc/elementor/class-typography.php:485
	// Reference: languages/ang-translations.php:928
	__( 'Define the default styles for every button size.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:492
	// Reference: languages/ang-translations.php:932
	__( 'XS', 'ang' ),

	// Reference: inc/elementor/class-typography.php:493
	// Reference: languages/ang-translations.php:936
	__( 'S', 'ang' ),

	// Reference: inc/elementor/class-typography.php:494
	// Reference: languages/ang-translations.php:940
	__( 'M', 'ang' ),

	// Reference: inc/elementor/class-typography.php:495
	// Reference: languages/ang-translations.php:944
	__( 'L', 'ang' ),

	// Reference: inc/elementor/class-typography.php:508
	// Reference: languages/ang-translations.php:948
	__( 'Typography', 'ang' ),

	// Reference: inc/elementor/class-typography.php:518
	// Reference: languages/ang-translations.php:952
	__( 'Text Color', 'ang' ),

	// Reference: inc/elementor/class-typography.php:530
	// Reference: languages/ang-translations.php:956
	__( 'Text Hover Color', 'ang' ),

	// Reference: inc/elementor/class-typography.php:542
	// Reference: languages/ang-translations.php:960
	__( 'Background Color', 'ang' ),

	// Reference: inc/elementor/class-typography.php:554
	// Reference: languages/ang-translations.php:964
	__( 'Background Hover Color', 'ang' ),

	// Reference: inc/elementor/class-typography.php:576
	// Reference: languages/ang-translations.php:968
	__( 'Border Radius', 'ang' ),

	// Reference: inc/elementor/class-typography.php:598
	// Reference: languages/ang-translations.php:972
	__( 'Padding', 'ang' ),

	// Reference: inc/elementor/class-typography.php:647
	// Reference: languages/ang-translations.php:976
	__( '<strong>You are editing the style kit that has been set as global.</strong> You can optionally choose a different Style Kit for this page below.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:656
	// Reference: languages/ang-translations.php:980
	__( 'A style kit is a collection of all the custom styles added at page styling settings. Your Style Kit is updated every time you click the Update Style Kit Button below.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:660
	// Reference: languages/ang-translations.php:984
	__( 'Page Style Kit', 'ang' ),

	// Reference: inc/elementor/class-typography.php:670
	// Reference: languages/ang-translations.php:988
	__( 'Update Your Style Kit', 'ang' ),

	// Reference: inc/elementor/class-typography.php:680
	// Reference: languages/ang-translations.php:992
	__( 'Save all the styles as a Style Kit that you can apply on other pages or globally. Please note that only the custom styles added in the styles page are saved with the stylekit.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:684
	// Reference: languages/ang-translations.php:996
	__( 'Save Style Kit as...', 'ang' ),

	// Reference: inc/elementor/class-typography.php:687
	// Reference: languages/ang-translations.php:1000
	__( 'Save as...', 'ang' ),

	// Reference: inc/elementor/class-typography.php:696
	// Reference: languages/ang-translations.php:1006
	/* translators: translators: %s: Link to Style Kits
translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits translators: translators: %s: Link to Style Kits */
	__( 'You can set a Global Style Kit <a href="%s" target="_blank">here</a>.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:722
	// Reference: languages/ang-translations.php:1010
	__( 'Tools', 'ang' ),

	// Reference: inc/elementor/class-typography.php:727
	// Reference: languages/ang-translations.php:1014
	__( 'This will reset all the custom style values added in the Style tab, and detach this page from any Style kits', 'ang' ),

	// Reference: inc/elementor/class-typography.php:731
	// Reference: languages/ang-translations.php:1018
	__( 'Reset all styling', 'ang' ),

	// Reference: inc/elementor/class-typography.php:734
	// Reference: languages/ang-translations.php:1022
	__( 'Reset all', 'ang' ),

	// Reference: inc/elementor/class-typography.php:738
	// Reference: languages/ang-translations.php:1026
	__( 'Export styles as custom CSS text.', 'ang' ),

	// Reference: inc/elementor/class-typography.php:742
	// Reference: languages/ang-translations.php:1030
	__( 'Export Custom CSS', 'ang' ),

	// Reference: inc/elementor/class-typography.php:781
	// Reference: languages/ang-translations.php:1034
	__( 'A Style Kits control that adds padding to your outer sections. You can edit the values', 'ang' ),

	// Reference: inc/elementor/class-typography.php:786
	// Reference: languages/ang-translations.php:1038
	__( 'No Padding', 'ang' ),

	// Reference: inc/register-settings.php:28
	// Reference: languages/ang-translations.php:1042
	__( 'Style Kits Library', 'ang' ),

	// Reference: inc/register-settings.php:37
	// Reference: languages/ang-translations.php:1046
	__( 'Library', 'ang' ),

	// Reference: inc/register-settings.php:44
	// Reference: languages/ang-translations.php:1050
	__( 'Style Kits Settings', 'ang' ),

	// Reference: inc/register-settings.php:56
	// Reference: languages/ang-translations.php:1054
	__( 'Manage Style Kits', 'ang' ),

	// Reference: inc/register-settings.php:179
	// Reference: languages/ang-translations.php:1058
	__( 'Imported Count', 'ang' ),

	// Reference: inc/register-settings.php:191
	// Reference: languages/ang-translations.php:1062
	__( 'Imported templates', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:23
	// Reference: languages/ang-translations.php:1066
	__( 'General', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:39
	// Reference: languages/ang-translations.php:1070
	__( 'Elementor Settings', 'ang' ),

	// Reference: inc/settings/class-settings-general.php:44
	// Reference: languages/ang-translations.php:1074
	__( 'Sync Color Palettes and Style Kit colors by default', 'ang' ),

	// Reference: inc/settings/class-settings-gopro.php:23
	// Reference: languages/ang-translations.php:1078
	__( 'Style Kits Pro', 'ang' ),

	// Reference: inc/settings/class-settings-license.php:26
	// Reference: languages/ang-translations.php:1082
	__( 'License', 'ang' ),

	// Reference: inc/settings/class-settings-license.php:47
	// Reference: languages/ang-translations.php:1086
	__( 'License Status', 'ang' ),

	// Reference: inc/settings/class-settings-license.php:80
	// Reference: languages/ang-translations.php:1090
	__( 'Pro license', 'ang' ),

	// Reference: inc/settings/class-settings-license.php:83
	// Reference: languages/ang-translations.php:1094
	__( 'If you own an AnalogPro License, then please enter your license key here.', 'ang' ),

	// Reference: inc/settings/class-settings-license.php:86
	// Reference: languages/ang-translations.php:1098
	__( 'If you do not have a license key, you can get one from ', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:25
	// Reference: languages/ang-translations.php:1102
	__( 'Misc', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:56
	// Reference: languages/ang-translations.php:1106
	__( 'Usage Data Tracking', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:61
	// Reference: languages/ang-translations.php:1110
	__( 'Opt-in to our anonymous plugin data collection and to updates. We guarantee no sensitive data is collected.', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:66
	// Reference: inc/settings/class-settings-misc.php:107
	// Reference: languages/ang-translations.php:1115
	__( 'More Info', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:73
	// Reference: languages/ang-translations.php:1119
	__( 'Rollback Version', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:76
	// Reference: languages/ang-translations.php:1123
	__( 'If you are having issues with current version of Style Kits for Elementor, you can rollback to a previous stable version.', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:90
	// Reference: languages/ang-translations.php:1127
	__( 'Reinstall this version', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:97
	// Reference: languages/ang-translations.php:1131
	__( 'Template Settings', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:102
	// Reference: languages/ang-translations.php:1135
	__( 'Remove Styling from typographic elements', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:107
	// Reference: languages/ang-translations.php:1139
	__( 'This setting will remove any values that have been manually added in the templates. Existing templates are not affected.', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:114
	// Reference: languages/ang-translations.php:1143
	__( 'Remove Data on Uninstall', 'ang' ),

	// Reference: inc/settings/class-settings-misc.php:119
	// Reference: languages/ang-translations.php:1147
	__( 'Check this box to remove all data stored by Style Kit for Elementor plugin, including license info, user settings, import history etc. Any imported or manually saved Style Kits are not removed.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:14
	// Reference: languages/ang-translations.php:1151
	__( 'An inter-connected collection of Template Kits and advanced design control is <u>coming soon</u> with Style Kits Pro.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:16
	// Reference: languages/ang-translations.php:1155
	__( 'You can <strong>sign up for an exclusive discount</strong> that we will send to your email when we are close to launch. Click the button below to see the Pro features and road map, and sign up for the exclusive discount.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings-gopro.php:18
	// Reference: languages/ang-translations.php:1159
	__( 'More about Style Kits Pro', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:50
	// Reference: languages/ang-translations.php:1163
	__( 'Save changes', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:60
	// Reference: languages/ang-translations.php:1167
	__( 'Documentation', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:61
	// Reference: languages/ang-translations.php:1171
	__( 'Need help setting up? We have a number of handy articles to get you started.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:62
	// Reference: languages/ang-translations.php:1175
	__( 'Read Documentation', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:65
	// Reference: languages/ang-translations.php:1179
	__( 'Join our Facebook group', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:66
	// Reference: languages/ang-translations.php:1183
	__( 'Get insights, tips and updates in our facebook community. Let\'s take Elementor design to a whole new level.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:67
	// Reference: languages/ang-translations.php:1187
	__( 'Join the AnalogWP community', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:70
	// Reference: languages/ang-translations.php:1191
	__( 'Sign up for updates', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:71
	// Reference: languages/ang-translations.php:1195
	__( 'Sign up to Analog Newsletter and get notified about product updates, freebies and more.', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:74
	// Reference: languages/ang-translations.php:1199
	__( 'Subscribe up to newsletter', 'ang' ),

	// Reference: inc/settings/views/html-admin-settings.php:76
	// Reference: languages/ang-translations.php:1203
	__( 'By signing up you agree to our', 'ang' ),

	// Reference: languages/ang-translations.php:1206
	__( 'The Style Kit has been imported to your library.', 'ang' ),

	// Reference: languages/ang-translations.php:1209
	__( '%s has been imported and is now available in the Style Kits dropdown', 'ang' ),

	// Reference: languages/ang-translations.php:1212
	__( 'Do not apply link color on active titles', 'ang' ),

	// Reference: languages/ang-translations.php:1215
	__( 'Blimey! Your template has been imported.', 'ang' ),

	// Reference: languages/ang-translations.php:1218
	__( 'Premium template kits are coming soon with Style Kits Pro. You can only preview these layouts for now but feel free to sign up to our mailing list if you want to learn when they become available.', 'ang' ),

	// Reference: languages/ang-translations.php:1221
	__( 'View Kit', 'ang' ),

	// Reference: languages/ang-translations.php:1224
	__( 'Choose', 'ang' ),

	// Reference: languages/ang-translations.php:1227
	__( 'Global: ', 'ang' ),

	// Reference: languages/ang-translations.php:1230
	__( 'Go Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1233
	__( 'Access an interconnected library of Template Kits, blocks and additional design control with Style kits Pro.', 'ang' ),

	// Reference: languages/ang-translations.php:1236
	__( 'Template Kits with theme builder templates.', 'ang' ),

	// Reference: languages/ang-translations.php:1239
	__( 'Blocks Library.', 'ang' ),

	// Reference: languages/ang-translations.php:1242
	__( 'Global design control.', 'ang' ),

	// Reference: languages/ang-translations.php:1245
	__( 'Advanced Style Kit control.', 'ang' ),

	// Reference: languages/ang-translations.php:1248
	__( 'Explore Style Kits Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1251
	__( 'Back to library', 'ang' ),

	// Reference: languages/ang-translations.php:1254
	__( 'Elevate your Elementor design with Analog Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1257
	__( 'Step up your workflow with unlimited design resources for your Elementor-powered projects.', 'ang' ),

	// Reference: languages/ang-translations.php:1260
	__( 'Why Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1263
	__( 'Access to all template library', 'ang' ),

	// Reference: languages/ang-translations.php:1266
	__( 'Templates for singles, archives, popups and more', 'ang' ),

	// Reference: languages/ang-translations.php:1269
	__( 'Multi-niche, human made design that makes sense', 'ang' ),

	// Reference: languages/ang-translations.php:1272
	__( 'Unlimited license for peace of mind', 'ang' ),

	// Reference: languages/ang-translations.php:1275
	__( '* Requires Elementor Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1278
	__( 'Please update Analog Template plugin to latest version.', 'ang' ),

	// Reference: languages/ang-translations.php:1281
	__( 'Enter your email', 'ang' ),

	// Reference: languages/ang-translations.php:1284
	__( 'Sending...', 'ang' ),

	// Reference: languages/ang-translations.php:1287
	__( 'Sign up to newsletter', 'ang' ),

	// Reference: languages/ang-translations.php:1290
	__( 'Docs', 'ang' ),

	// Reference: languages/ang-translations.php:1293
	__( 'Follow on Social', 'ang' ),

	// Reference: languages/ang-translations.php:1296
	__( 'Elevate to Analog Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1299
	__( 'Do more with Analog Pro, the design library for complete Elementor-powered sites.', 'ang' ),

	// Reference: languages/ang-translations.php:1302
	__( 'Access to all templates', 'ang' ),

	// Reference: languages/ang-translations.php:1305
	__( 'New designs every week', 'ang' ),

	// Reference: languages/ang-translations.php:1308
	__( 'Flexible Licensing', 'ang' ),

	// Reference: languages/ang-translations.php:1311
	__( 'Pro Elements, theme builder layouts', 'ang' ),

	// Reference: languages/ang-translations.php:1314
	__( 'Requires Elementor Pro', 'ang' ),

	// Reference: languages/ang-translations.php:1317
	__( 'More Details', 'ang' ),

	// Reference: languages/ang-translations.php:1320
	__( 'An error occured', 'ang' ),

	// Reference: languages/ang-translations.php:1323
	__( 'Imported ', 'ang' ),

	// Reference: languages/ang-translations.php:1326
	__( 'Settings updated.', 'ang' ),

	// Reference: languages/ang-translations.php:1329
	__( 'Deactivate', 'ang' ),

	// Reference: languages/ang-translations.php:1332
	__( 'Activate', 'ang' ),

	// Reference: languages/ang-translations.php:1335
	__( 'Plugin Settings', 'ang' ),

	// Reference: languages/ang-translations.php:1338
	__( 'Pro License', 'ang' ),

	// Reference: languages/ang-translations.php:1341
	__( 'Connection timeout, please try again.', 'ang' ),

	// Reference: languages/ang-translations.php:1344
	__( 'Processing...', 'ang' ),

	// Reference: languages/ang-translations.php:1347
	__( 'If you do not have a license key, you can get one from', 'ang' ),

	// Reference: languages/ang-translations.php:1350
	__( 'The Elementor color palette will be populated with the Style Kit’s global colors', 'ang' ),

	// Reference: languages/ang-translations.php:1353
	__( 'Reinstall version %s', 'ang' ),

	// Reference: languages/ang-translations.php:1356
	__( 'Style Kits Settings Page', 'ang' ),

	// Reference: languages/ang-translations.php:1359
	__( 'License keys do not match. <br><br> Enter your theme license key received upon purchase from <a target="_blank" href="https://analogwp.com/account/">AnalogWP</a>.', 'ang' ),

	// Reference: languages/ang-translations.php:1362
	__( 'filter', 'ang' ),

	// Reference: languages/ang-translations.php:1365
	__( 'sort by', 'ang' ),

	// Reference: languages/ang-translations.php:1368
	__( 'show only free', 'ang' ),

	// Reference: languages/ang-translations.php:1372
	/* translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: translators: %s: Style kit title. */
	__( 'Style Kit: %s <span style="color:#3152FF;">&#9679;</span>', 'ang' ),

	// Reference: languages/ang-translations.php:1375
	__( 'This padding applies <strong>only on the Outer Sections</strong> of your layout, and not on Inner Section widgets.', 'ang' ),

	// Reference: languages/ang-translations.php:1378
	__( 'Set the default values of the column gaps. Based on Elementor&apos;s default sizes.', 'ang' ),

	// Reference: languages/ang-translations.php:1381
	__( 'Create the styles for each button size', 'ang' ),

	// Reference: languages/ang-translations.php:1384
	__( 'View Library', 'ang' ),

	// Reference: languages/ang-translations.php:1387
	__( 'Kits', 'ang' ),

	// Reference: languages/ang-translations.php:1390
	__( 'Below are the available Style Kits. When you choose to import a Style Kit, it will be added to your available', 'ang' ),

	// Reference: languages/ang-translations.php:1393
	__( 'Importing Style Kit ', 'ang' ),

	// Reference: languages/ang-translations.php:1396
	__( 'Blimey! Your Style Kit has been imported to library.', 'ang' ),

	// Reference: languages/ang-translations.php:1399
	__( 'Normal Padding', 'ang' ),

	// Reference: languages/ang-translations.php:1402
	__( 'Small Padding', 'ang' ),

	// Reference: languages/ang-translations.php:1405
	__( 'Medium Padding', 'ang' ),

	// Reference: languages/ang-translations.php:1408
	__( 'Large Padding', 'ang' ),

	// Reference: languages/ang-translations.php:1411
	__( 'Extra Large Padding', 'ang' ),

	// Reference: languages/ang-translations.php:1414
	__( 'No Gap', 'ang' ),

	// Reference: languages/ang-translations.php:1417
	__( 'Sets the primary brand color, applies on Links.', 'ang' ),

	// Reference: languages/ang-translations.php:1420
	__( 'Sets the default color for Buttons. You can also apply button colors in the Global buttons tab.', 'ang' ),

	// Reference: languages/ang-translations.php:1423
	__( 'Text over light background', 'ang' ),

	// Reference: languages/ang-translations.php:1426
	__( 'Applies on the text and titles over a section or column with light bg', 'ang' ),

	// Reference: languages/ang-translations.php:1429
	__( 'Applies on the text and titles over a section or column with dark bg', 'ang' ),

	// Reference: languages/ang-translations.php:1432
	__( 'Apply the class <strong>sk-light-bg</strong> to a section or column to apply this color as a background. Text will inherit the <strong>Text over Light bg</strong> color.', 'ang' ),

	// Reference: languages/ang-translations.php:1435
	__( 'Apply the class <strong>sk-dark-bg</strong> to a section or column to apply this color as a background. Text will inherit the <strong>Text over Dark bg</strong> color.', 'ang' ),

	// Reference: languages/ang-translations.php:1438
	__( 'Narrow', 'ang' ),

	// Reference: languages/ang-translations.php:1441
	__( 'Extended', 'ang' ),

	// Reference: languages/ang-translations.php:1444
	__( 'Wide', 'ang' ),

	// Reference: languages/ang-translations.php:1447
	__( 'Wider', 'ang' ),

	// Reference: languages/ang-translations.php:1450
	__( 'Outer Section Gaps', 'ang' ),

	// Reference: languages/ang-translations.php:1453
	__( 'A handcrafted design library for Elementor templates.', 'ang' ),

	// Reference: languages/ang-translations.php:1456
	__( 'Outer Section Gap', 'ang' ),

	// Reference: languages/ang-translations.php:1459
	__( 'Set the padding <strong>only for the outer section</strong>, does not apply on inner section widgets, in case you have any. You can tweak the section gap', 'ang' ),

	// Reference: languages/ang-translations.php:1462
	__( 'Set the padding <strong>only for the outer section</strong>, does not apply on inner section widgets, in case you have any. You can tweak the section gap here.', 'ang' ),

	// Reference: languages/ang-translations.php:1465
	__( 'AnalogWP Templates', 'ang' ),

	// Reference: languages/ang-translations.php:1468
	__( 'Analog Templates', 'ang' ),

	// Reference: languages/ang-translations.php:1471
	__( 'AnalogWP Settings', 'ang' ),

	// Reference: languages/ang-translations.php:1474
	__( 'Meet Style Kits by AnalogWP', 'ang' ),

	// Reference: languages/ang-translations.php:1477
	__( 'Page Styles', 'ang' ),

	// Reference: languages/ang-translations.php:1480
	__( 'Font Size', 'ang' ),

	// Reference: languages/ang-translations.php:1483
	__( 'Line Height', 'ang' ),

	// Reference: languages/ang-translations.php:1486
	__( 'AnalogWP Shortcuts', 'ang' ),

	// Reference: languages/ang-translations.php:1489
	__( 'Applies to all links by default', 'ang' ),

	// Reference: languages/ang-translations.php:1492
	__( 'Adds a background color to all buttons on page.', 'ang' ),

	// Reference: languages/ang-translations.php:1495
	__( 'Text and Headings (Dark)', 'ang' ),

	// Reference: languages/ang-translations.php:1498
	__( 'Applies on the text and titles over light bg', 'ang' ),

	// Reference: languages/ang-translations.php:1501
	__( 'Text and Headings (Light)', 'ang' ),

	// Reference: languages/ang-translations.php:1504
	__( 'Applies on the text and titles over dark bg', 'ang' ),

	// Reference: languages/ang-translations.php:1507
	__( 'If you are having issues with current version of Analog Templates, you can rollback to a previous stable version.', 'ang' ),

	// Reference: inc/elementor/class-colors.php:145
	// Reference: languages/ang-translations.php:1511
	_x( 'Global Colors', 'Section Title', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:34
	// Reference: languages/ang-translations.php:1515
	_x( 'Style Kits', 'admin menu', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:35
	// Reference: languages/ang-translations.php:1519
	_x( 'Style Kit', 'add new on admin bar', 'ang' ),

	// Reference: inc/elementor/class-post-type.php:36
	// Reference: languages/ang-translations.php:1523
	_x( 'Add New', 'book', 'ang' )
);
/* THIS IS THE END OF THE GENERATED FILE */
