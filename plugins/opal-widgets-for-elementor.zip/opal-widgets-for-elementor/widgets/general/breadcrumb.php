<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class OSF_Elementor_Breadcrumb_Widget extends Elementor\Widget_Base {

    public function get_name() {
        return 'opal-breadcrumb';
    }

    public function get_title() {
        return __( 'Opal Breadcrumb', 'opalelementor' );
    }

    public function get_icon() {
        return 'eicon-navigation-horizontal';
    }

    public function get_categories() {
        return [ 'opal-addons' ];
    }

    private function get_available_menus() {
        $menus = wp_get_nav_menus();

        $options = [];

        foreach ($menus as $menu) {
            $options[$menu->slug] = $menu->name;
        }

        return $options;
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'account_content',
            [
                'label' => __( 'Account', 'opalelementor' ),
            ]
        );


        $this->add_control(
            'style',
            [
                'label' => __( 'Style to Show Account Form', 'opalelementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'hover' => __( 'Hover', 'opalelementor' ),
                    'popup' => __( 'Popup', 'opalelementor' ),
                ],
                'default' => 'hover',
                'prefix_class' => 'elementor-countdown--label-',
            ]
        );


        $menus = $this->get_available_menus();

        if (!empty($menus)) {
             $this->add_control(
                'enable_custom_menu',
                [
                    'label' => __( 'Use Custom Dashboard Menu', 'elementor' ),
                    'type' => Controls_Manager::SWITCHER,
                ]
            );


            $this->add_control(
                'menu',
                [
                    'label'        => __('Menu', 'opalelementor'),
                    'type'         => Controls_Manager::SELECT,
                    'options'      => $menus,
                    'default'      => 'my-account',
                    'save_default' => true,
                    'separator'    => 'after',
                    'description'  => sprintf(__('Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'opalelementor'), admin_url('nav-menus.php')),
                    'condition'    => array( 'enable_custom_menu' => 'yes' )
                ]
            );
        }

        $this->add_control(
            'icon',
            [
                'label' => __( 'Choose Icon', 'opalelementor' ),
                'type' => Controls_Manager::ICON,
                'default' => 'opal-icon-user',
            ]
        );

        $this->add_control(
            'enable_label',
            [
                'label' => __( 'Enable Label', 'elementor' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );  

        $this->add_control(
            'toggle_align',
            [
                'label' => __( 'Alignment', 'opalelementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'opalelementor' ),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'opalelementor' ),
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'opalelementor' ),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container' => 'text-align: {{VALUE}}',
                ],
                
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_label_style_content',
            [
                'label' => __( 'Label', 'opalelementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'opalelementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .site-header-account .label' => 'color: {{VALUE}};',
                ],
                'scheme' => [
                    'type' => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .site-header-account .label',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_icon_style_content',
            [
                'label' => __( 'Icon', 'opalelementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs( 'tabs_icon_style' );

        $this->start_controls_tab(
            'tab_icon_normal',
            [
                'label' => __( 'Normal', 'opalelementor' ),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Icon Color', 'opalelementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .site-header-account i' => 'color: {{VALUE}};',
                ],
                'scheme' => [
                    'type' => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label' => __( 'Background Color', 'opalelementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .site-header-account i' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_fontsize',
            [
                'label' => __( 'Icon Font Size', 'opalelementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .site-header-account i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icon_border',
                'placeholder' => '1px',
                'default' => '1px',
                'selector' => '{{WRAPPER}} .site-header-account i',
                'separator' => 'before',
                
            ]
        );

        $this->add_control(
            'icon_border_radius',
            [
                'label' => __( 'Border Radius', 'opalelementor' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .site-header-account i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_padding',
            [
                'label' => __( 'Padding', 'opalelementor' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .site-header-account i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_icon_hover',
            [
                'label' => __( 'Hover', 'opalelementor' ),
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => __( 'Icon Color', 'opalelementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .site-header-account i:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'background_color_hover',
            [
                'label' => __( 'Background Color', 'opalelementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .site-header-account i:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icon_border_hover',
                'placeholder' => '1px',
                'default' => '1px',
                'selector' => '{{WRAPPER}} .site-header-account i:hover',
                'separator' => 'before',
                
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings(); 
        if ( function_exists('bcn_display') ) { ?>
          <div class="elementor-breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">  <div class="breadcrumbs">
              <div class="container">
                  <div class="breadcrumbs_title">
                      <?php $this->render_breadcrumb_title(); ?>
                  </div>
                  <?php bcn_display(); ?>
              </div>   </div>
          </div>
      <?php
      }else { ?>
        <div class="elementor-breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
            <div class="breadcrumbs">   
                <div class="container">
                    <div class="breadcrumbs_title">
                        <?php $this->render_breadcrumb_title(); ?>
                    </div>
                    <?php  get_template_part('partials/common/breadcrumb');  ?>
                </div>   
            </div>
        </div>

      <?php }  

    }

    protected function render_breadcrumb_title(  ){ 
        global $post;
        if (class_exists('WooCommerce')) {
            if ( is_shop() ){
                $shop_page_id = wc_get_page_id( 'shop' );
                $wbt_title = get_the_title( $shop_page_id );
            }
        }
        //$wbt_title  = __( 'Blog', 'wpopalbootstrap' );
        if (!is_front_page()){
            if (is_home()){
                $wbt_title  = __( 'Blog', 'opalelementor' );
            }else{
                if (is_single()){
                    $wbt_title = get_the_title();
                }else{
                    if (is_archive() && is_tax() && !is_category() && !is_tag()){
                        $tax_object = get_queried_object();
                        if (!empty( $tax_object )){
                            $wbt_title  = esc_html( $tax_object->name );
                        }
                    }else{
                        if(is_category()){
                            $wbt_title  = single_cat_title( '', false );
                        }else{
                            if (is_page()){
                                $wbt_title  = get_the_title();
                            }
                            if (is_tag()){

                                // Get tag information
                                $wbt_term_id  = get_query_var( 'tag_id' );
                                $wbt_taxonomy = 'post_tag';
                                $wbt_args     = 'include=' . $wbt_term_id;
                                $wbt_terms    = get_terms( $wbt_taxonomy, $otf_args );

                                // Display the tag name
                                if (isset( $wbt_terms[0]->name )){
                                    $wbt_title  = $wbt_terms[0]->name;
                                }
                            }
                            if (is_day()){
                                $wbt_title = __( 'Day', 'opalelementor' );
                            }else{
                                if (is_month()){
                                    $wbt_title = __( 'Month', 'opalelementor' );
                                }else{
                                    if (is_year()){
                                        $wbt_title = __( 'Year', 'opalelementor' );
                                    }else{
                                        if (is_author()){
                                            global $author;
                                            if(!empty($author->ID)){
                                                $wbt_title  = __( 'Author', 'opalelementor' );
                                            }
                                        }else{
                                            if (is_search()){
                                                $wbt_title = __( 'Search', 'opalelementor' );
                                            }elseif (is_404()){
                                                $wbt_title = __( 'Error 404', 'opalelementor' );
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }
                }
            } ?>

            <h1 class="title"><?php  if(!empty($wbt_title) && $wbt_title) { echo esc_html($wbt_title);} ?></h1>
            <?php
        }

    }
}