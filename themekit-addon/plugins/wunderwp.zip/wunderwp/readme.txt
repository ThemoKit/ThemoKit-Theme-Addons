=== WunderWp ===
Contributors: artbees
Author URI: https://artbees.net
Plugin URL: https://wunderwp.com
Tags: presets, elementor, design, elements, readymade, styles
Requires at least: 4.7
Tested up to: 5.3
Stable tag: 1.3.0
Requires PHP: 5.6
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Beautify Elementor widgets with preset styles
Apply preset styling to Elementor widgets


== Description ==

https://www.youtube.com/watch?v=-h85wx6-upc&feature=youtu.be

== [NEW] Introducing Pre-made templates! Now you can use Pre-made templates on Elementor pages. ==

WunderWP now allows you to save and reuse your own styles in Elementor. Simply create your style, save it to the WunderWP Cloud and apply it to your widgets.

Your Elementor widgets won’t look good unless you put a lot of time into stylizing them. WunderWP saves you that time and beautifies your raw Elementor widgets so you can focus your time and energy into more important work.

WunderWP comes with preset styles to start your work regardless of the theme you use. Drag an Elementor widget to your page, select a WunderWP preset style for your widget and start adding your content!

Thanks to the new custom style feature, you can also upload your styles to WunderWP cloud once and use them unlimited times in unlimited Elementor projects.

WunderWP is free and compatible with all Elementor themes, Elementor Free, Elementor Pro and Raven libraries.

Start by creating your own reusable custom styles or choosing one of WunderWP’s preset styles.

== Available Styles ==

134 Element Styles for Elementor Free
139 Element Styles for Elementor Pro
42 Element Styles for Elementor Raven

== Features ==

- Apply preset and alternative styles for different elements in Elementor Free, Elementor Pro and Raven libraries.
- Download the new Elementor styles added to different collection to WunderWP over time.
- Save your styles in the WunderWP cloud and and reuse them in any future Elementor project.
- **[NEW]** Use Pre-made templates to save your time instead building the templates from scratch.

== About ==

A product of Artbees, the team behind the stellar Jupiter X WP theme.

== Follow WunderWP ==

- Follow WunderWP on [Facebook](https://www.facebook.com/wunderwp)
- Follow WunderWP on [Twitter](https://twitter.com/Wunderwp)
- Follow WunderWP on [YouTube](https://www.youtube.com/c/Artbeesofficial)


== Installation ==

1. Install using the WordPress built-in Plugin installer, or Extract the zip file and drop the contents in the `wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Screenshots ==

1. Choose Preset & Apply

== Changelog ==

= 1.0.0 - 2019-09-30 =
* Initial release

= 1.1.0 - 2019-10-21 =
* Fix: Don't override content type settings in all the elements.
* Fix: Rendering issue after applying preset.

= 1.2.0 - 2019-10-30 =
* New: Custom presets.

= 1.3.0 - 2019-11-15 =
* New: Pre made templates.
* Fix: Plugin does not appear in the menu when it's Network Active.
* Fix: WP 5.3 compatibility.

== Upgrade Notice ==

= 1.1.0 =
Fixed bugs in presets feature.

= 1.2.0 =
Gives you ability to save your custom presets on WunderWP cloud and manage your custom presets from one WunderWP cloud account across multiple sites.

= 1.3.0 =
This release introduces new feature i.e. Pre-made templates. Avoid building templates from scratch use Pre-made templates feature to save your time.

