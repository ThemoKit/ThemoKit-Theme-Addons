<?php
/**
 * silence is golden
 */