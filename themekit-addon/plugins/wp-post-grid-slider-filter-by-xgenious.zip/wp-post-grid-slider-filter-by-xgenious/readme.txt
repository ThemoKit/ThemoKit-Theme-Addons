﻿=== Wp Post Grid / Slider / Filter ===
Contributors: xgenious
Donate link: 
Tags: blog design, blog layout, custom blog design, custom blog layout, grid layout, gutenberg, gutenberg post layout block, gutenberg posts, list layout, magazine layout, news layout, post design, post layouts, post list, wordpress blog plugin
Requires at least: 4.3
Tested up to: 5.2.1
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Wp Post Grid / Slider / Filter is a modern Plugin. It’s have 02 header slider style, 02 featured grid style, 02 full width grid style, 02 thumbnail style, 02 post layout style, 02 post layout filter style, 02 thumbnail layout filter style with huge option. You can use this Team Slider on your website easily.

== Description ==
Display post slider / grid . filter  anywhere in your wordpress site using Wp Post Grid / Slider / Filter plugin shortcodes.
<br/>
<strong>CHECK Wp Post Grid / Slider / Filter[FREE] DEMOS</strong> 
<a href="https://plugins.xgenious.com/post-modules/land/">Wp Post Grid / Slider / Filter (Pro/Free) Demo</a>

<strong>AWESOME FEATURES</strong>
<ul>
<li> Add post slider /grid /filter using shortcode as  your requirements</li>
<li> 14 unique design</li>
<li>Unlimited color options</li>
<li>Typography options</li>
<li>Filter options</li>
<li>Slider options</li>
<li>Styling options</li>
<li>Easy to customize with plugin Options</li>
<li>fully responsive</li>
<li>Cross browser support</li>
</ul>

<strong>WP post slider /grid /filter PRO[PAID] FEATURES</strong>
<br/><br/>
<ul>
    <li>75 Unique Layout Styles</li>
    <li>10 Thumbnail Grid</li>
    <li>10 Thumbnail Slider</li>
    <li>10 Thumbnail Filter</li>
    <li>17 Full Width Layout</li>
    <li>10 Header Slider Layout</li>
    <li>17 Featured Column Layout</li>
    <li>21 Post Grid</li>
    <li>21 Post Slider</li>
    <li>21 Post Filter</li>
 <li>05 Filter Menu Style</li>
   <li>Pre Build Elementor Addon</li>
   <li>Pre Build WpBakery Addon</li>
   <li>Gutenberg Support</li>
    <li>Responsive Design</li>
    <li>Smooth hover effect</li>
    <li>Fully Customization</li>
    <li>Unlimited Color Style</li>
    <li>All Browser Supported</li>
    <li>Clean Coding, W3c Validate</li>
    <li>Step by Step Well Documented</li>
    <li>Friendly Support</li>
</ul>


== Installation ==

1. Upload the plugin files to the /wp-content/plugins/wp-post-layout directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Team Slider option and here you see options change the setting as per your need. or leave this and just copy thes shortcode given here it will take default settings.

4. To embed the Wp Post Grid / Slider / Filter in a page or post, use the default shortcode generator to generate shortcodes
5. ONLINE DOCUMENTATION :- <a href="https://plugins.xgenious.com/post-modules/docs">Click Here</a>
5. Video Tutorial :- <a href="https://www.youtube.com/playlist?list=PLJcPEKFQ9gtScy9onmDDEngXl1eOE3mV3">Click Here</a>

== Frequently asked questions ==

= How do I get the wp post slider/grid/filter widget to show up? =

 use the shortcodeand genarator to get the shortcode of Wp Post Grid / Slider / Filter plugin to show slider/grid/filter on your post or page. 

= How do I modify Wp Post Grid / Slider / Filter plugin shortcode ? =
In admin menu you see xg post modules menu. go here and modify using plugin option.

= Something Else? =
If you are having any other issues, please post in the Support Forum and I will respond as soon as possible.

== Screenshots ==
. screenshort-01.png
. screenshort-02.png
. screenshort-03.png
. screenshort-04.png
. screenshort-05.png
. screenshort-06.png
. screenshort-07.png
. screenshort-08.png
. screenshort-09.png
. screenshort-10.png
. screenshort-11.png
. screenshort-12.png
. screenshort-13.png
. screenshort-14.png
. screenshort-15.png


== Changelog ==
1.0.1 – (May 31, 2019)
1.0.0 – (May 28, 2019)
First release. 

