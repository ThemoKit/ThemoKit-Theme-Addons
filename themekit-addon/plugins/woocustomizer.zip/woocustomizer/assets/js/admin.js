/**
 * Plugin Template admin js.
 *
 *  @package WooCustomizer/JS
 */
( function( $ ) {
	jQuery( document ).ready(
		function ( e ) {

		}
	);
} )( jQuery );
